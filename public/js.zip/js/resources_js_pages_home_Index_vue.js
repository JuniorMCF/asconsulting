(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_pages_home_Index_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/global/ChatComponent.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/global/ChatComponent.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  data: function data() {
    return {
      wame: "https://wa.me/51926302115"
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/global/FooterGlobal.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/global/FooterGlobal.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return generator._invoke = function (innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; }(innerFn, self, context), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; this._invoke = function (method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, define(Gp, "constructor", GeneratorFunctionPrototype), define(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (object) { var keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, "catch": function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  data: function data() {
    return {
      heightLogo: 116,
      widthLogo: 112,
      phone_contact: "926 302 115",
      phone_send: "tel:+51926302115",
      wame: "https://wa.me/51926302115",
      email: "reactivatunegocio@asconsulting.pe",
      address: "Av. Alfredo Benavides 3695. Surco."
    };
  },
  methods: {
    openEmail: function openEmail() {
      var _this = this;

      return _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var shareData;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                shareData = {
                  title: 'A&S Consulting Group',
                  text: 'Solicita tu asesoría',
                  url: _this.email
                };
                _context.prev = 1;
                _context.next = 4;
                return navigator.share(shareData);

              case 4:
                console.log("OpenBrowserEmail");
                _context.next = 10;
                break;

              case 7:
                _context.prev = 7;
                _context.t0 = _context["catch"](1);
                console.log(_context.t0);

              case 10:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, null, [[1, 7]]);
      }))();
    },
    goToLocation: function goToLocation() {
      this.$router.push({
        name: 'contacto'
      });
    }
  },
  computed: {
    yearActual: function yearActual() {
      var now = new Date();
      return now.getFullYear();
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/home/Index.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/home/Index.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var vue_flux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-flux */ "./node_modules/vue-flux/dist/vue-flux.umd.min.js");
/* harmony import */ var vue_flux__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vue_flux__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_Comilla_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./utils/Comilla.vue */ "./resources/js/pages/home/utils/Comilla.vue");
/* harmony import */ var _components_global_FooterGlobal_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../components/global/FooterGlobal.vue */ "./resources/js/components/global/FooterGlobal.vue");
/* harmony import */ var _components_global_ChatComponent_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../components/global/ChatComponent.vue */ "./resources/js/components/global/ChatComponent.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    VueFlux: vue_flux__WEBPACK_IMPORTED_MODULE_0__.VueFlux,
    FluxCaption: vue_flux__WEBPACK_IMPORTED_MODULE_0__.FluxCaption,
    FluxControls: vue_flux__WEBPACK_IMPORTED_MODULE_0__.FluxControls,
    FluxIndex: vue_flux__WEBPACK_IMPORTED_MODULE_0__.FluxIndex,
    FluxPagination: vue_flux__WEBPACK_IMPORTED_MODULE_0__.FluxPagination,
    FluxPreloader: vue_flux__WEBPACK_IMPORTED_MODULE_0__.FluxPreloader,
    Comilla: _utils_Comilla_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    FooterGlobal: _components_global_FooterGlobal_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
    ChatComponent: _components_global_ChatComponent_vue__WEBPACK_IMPORTED_MODULE_3__["default"]
  },
  data: function data() {
    return {
      form: {
        nombres: '',
        email: '',
        telefono: '',
        servicio: '',
        comentario: ''
      },
      servicio: {
        nombre: ''
      },
      loadAsesoria: false,
      vfOptions: {
        autoplay: true,
        allowToSkipTransition: true,
        delay: 4000
      },
      vfImages: ["/app/file1.webp", "/app/file2.webp"],
      vfTransitions: ["fade", "fade"],
      vfCaptions: [{
        image: "/app/logo_home.png",
        subtitle_image: "Consulting Group",
        title: null,
        subtitle: [{
          text: "Empresa",
          type: "normal"
        }, {
          text: " peruana ",
          type: "strong"
        }, {
          text: " que brinda servicios de ",
          type: "normal"
        }, {
          text: "consultoría",
          type: "strong"
        }, {
          text: " especializada.",
          type: "normal"
        }],
        actions: null
      }, {
        image: null,
        subtitle_image: null,
        title: [{
          text: "REACTIVA TU",
          type: "normal"
        }, {
          text: "PYME",
          type: "underline"
        }],
        subtitle: [{
          text: "Conoce como reactivar",
          type: "normal"
        }, {
          text: " tu negocio y llevarlo al siguiente nivel",
          type: "salto_linea"
        }],
        actions: [{
          title: "Reactiva",
          route: "/"
        }, {
          title: "Carta digital",
          route: "/"
        }]
      }],

      /**for services */
      vfOptions_services: {
        autoplay: true,
        allowToSkipTransition: true,
        delay: 3000
      },
      vfImages_services: ["/app/tecnologia.webp", "/app/finanzas.webp", "/app/procesos.webp", "/app/pyme_digital.webp"],
      vfTransitions_services: ["slide", "slide", "slide", "slide"],
      vfCaptions_services: [{
        title: "Tecnología",
        subtitle: "Nuestros principales servicios:",
        detalles: ["Software a medida (web / app).", "Soporte técnico computacional (outsourcing).", "Proyectos de TI (ágiles y tradicionales).", "Tableros de control en línea.", "Gestión integral de proveedores."],
        link: "/tecnologia"
      }, {
        title: "Finanzas y Contabilidad",
        subtitle: "Nuestros principales servicios:",
        detalles: ["Outsourcing contable.", "Outsourcing de planillas.", "Auditorías especializadas.", "Reestructuración financiera.", "Consultoría tributaria y legal."],
        link: "/finanzas"
      }, {
        title: "Procesos",
        subtitle: "Nuestros principales servicios:",
        detalles: ["Diseño y optimización de procesos.", "Inventario de activos (metodología ágil).", "Programa de reducción de costos.", "​Reingeniería organizacional.", "Gestión de riesgos."],
        link: "/procesos"
      }, {
        title: "Pyme Digital",
        subtitle: "Nuestros principales servicios:",
        detalles: ["Reactiva tu empresa.", "Mi carta digital."],
        link: "/"
      }],

      /**data */
      servicios: [{
        id: 1,
        nombre: "Tecnología"
      }, {
        id: 2,
        nombre: "Finanzas y Contabilidad"
      }, {
        id: 3,
        nombre: "Procesos"
      }]
    };
  },
  mounted: function mounted() {
    this.getPath();
    this.$store.dispatch("app/changeTitlePage", "Empresa Consultora Peruana | A&S Consulting Group | Santiago de Surco");
    document.title = this.$store.state.app.title_page;
    this.$store.dispatch("app/openPage", {
      page: window.location.pathname,
      link: window.location.host + window.location.pathname
    });
  },
  destroyed: function destroyed() {
    this.$store.dispatch("app/closePage", {
      visita_id: this.$store.state.app.visita_id
    });
  },
  methods: {
    getPath: function getPath() {
      var path = window.location.pathname + window.location.search;
      this.$store.dispatch("app/setPath", path);
    },
    sendRequest: function sendRequest() {
      var _this = this;

      this.form.servicio = this.servicio.nombre;
      this.loadAsesoria = true;

      if (this.form.nombres != '' && this.form.email != '' && this.form.telefono != '' && this.form.servicio != '' && this.form.comentario != '') {
        //let data = new FormData(this.form)
        axios.post("/api/asesoria", this.form).then(function (res) {
          Vue.$toast.success("Su solicitud de asesoría ha sido enviada, nos comunicaremos con ud");
          _this.loadAsesoria = false;
          _this.form = {
            nombres: '',
            email: '',
            telefono: '',
            servicio: '',
            comentario: ''
          };
          _this.servicio = {
            nombre: ''
          };
          _this.loadAsesoria = false;
        })["catch"](function (err) {
          _this.loadAsesoria = false;
          Vue.$toast.error("Error de conexión");
        });
        return;
      }

      Vue.$toast.warning("Llene todos los campos del formulario");
      this.loadAsesoria = false;
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/home/utils/Comilla.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/home/utils/Comilla.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({});

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/global/FooterGlobal.vue?vue&type=style&index=0&lang=css&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/global/FooterGlobal.vue?vue&type=style&index=0&lang=css& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\n.as-footer_text {\n    font-size: 0.8rem;\n}\n.footer-logo {\n    height: 116px !important;\n    width: 112px !important;\n}\n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/home/Index.vue?vue&type=style&index=0&lang=css&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/home/Index.vue?vue&type=style&index=0&lang=css& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\n.fixed-top {\n    position: absolute;\n    top: -87px;\n    z-index: 1;\n    margin-left: auto;\n    margin-right: auto;\n    left: 0;\n    right: 0;\n    width: 1480px;\n}\n.vue-flux .flux-caption {\n    margin: 0 auto;\n    color: white;\n    background-color: transparent;\n}\n.flux-caption {\n    width: 400px;\n    height: 25%;\n    /* centrar vertical y horizontalmente */\n    position: absolute;\n    top: 30%;\n}\n.flux-overlap {\n    position: absolute;\n    z-index: 5;\n    height: 100%;\n    width: 1480px;\n    background-color: rgba(0, 0, 102, 0.38) !important;\n}\n.flux-overlap-servicios {\n    position: absolute;\n    z-index: 5;\n    height: 500px;\n    width: 1480px;\n    background-color: rgba(0, 0, 102, 0.38) !important;\n}\n.flux-content {\n    z-index: 6;\n}\n.flux-pagination li {\n    color: white;\n    margin: 0px 4.5px 0px 4.5px !important;\n    background-color: white;\n    padding: 0px !important;\n    width: 12px !important;\n    height: 12px !important;\n    border-radius: 1.6rem;\n}\n.current {\n    color: rgba(255, 255, 255, 0.8);\n}\n.image-as {\n    height: 124px;\n    width: 240px;\n}\n.flux-container {\n    height: 817px !important;\n}\n.flux-servicios {\n    height: 500px !important;\n}\n.main-content {\n    position: absolute;\n    top: calc(817px - 87px);\n}\n\n/*.container-different {\n  position: relative;\n  top: -300px;\n}*/\n.text-line-card {\n    line-height: 1.3;\n}\n.container-card {\n    max-width: 442px;\n    background-color: #ededed !important;\n}\n@media screen and (max-width: 992px) {\n.image-as {\n        height: 4rem;\n        width: 8rem;\n}\n.flux-container {\n        height: 500px !important;\n}\n.flux-overlap {\n        position: absolute;\n        z-index: 5;\n        height: 100%;\n        width: 100%;\n        background-color: rgba(0, 0, 102, 0.38) !important;\n}\n.flux-content {\n        z-index: 2;\n}\n.main-content {\n        position: absolute;\n        top: calc(500px - 87px);\n}\n.flux-servicios {\n        height: 400px !important;\n}\n.flux-overlap-servicios {\n        position: absolute;\n        z-index: 5;\n        height: 400px;\n        width: 100%;\n        background-color: rgba(0, 0, 102, 0.38) !important;\n}\n}\n\n/**flux controls */\n.flux-controls .play {\n    display: none !important;\n}\n.flux-controls .pause {\n    display: none !important;\n}\n.flux-button svg circle {\n    fill: transparent;\n    color: white;\n}\n.flux-button:hover svg svg polyline {\n    stroke: white !important;\n}\n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/home/utils/Comilla.vue?vue&type=style&index=0&lang=css&":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/home/utils/Comilla.vue?vue&type=style&index=0&lang=css& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\n.container-comillas {\r\n  display: flex;\r\n  flex-flow: column wrap;\r\n  align-content: flex-end;\r\n  margin: 0 auto;\r\n  max-width: 442px;\n}\n.content-comillas {\r\n  width: 3rem;\r\n  height: 2.1rem;\r\n  transform: rotate(180deg)  translate(-20%,-40%);\r\n  z-index: 4;\n}\n.align-comillas {\n}\r\n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/global/FooterGlobal.vue?vue&type=style&index=0&lang=css&":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/global/FooterGlobal.vue?vue&type=style&index=0&lang=css& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_FooterGlobal_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./FooterGlobal.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/global/FooterGlobal.vue?vue&type=style&index=0&lang=css&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_FooterGlobal_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_FooterGlobal_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/home/Index.vue?vue&type=style&index=0&lang=css&":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/home/Index.vue?vue&type=style&index=0&lang=css& ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Index.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/home/Index.vue?vue&type=style&index=0&lang=css&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/home/utils/Comilla.vue?vue&type=style&index=0&lang=css&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/home/utils/Comilla.vue?vue&type=style&index=0&lang=css& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Comilla_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Comilla.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/home/utils/Comilla.vue?vue&type=style&index=0&lang=css&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Comilla_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Comilla_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/vue-flux/dist/vue-flux.umd.min.js":
/*!********************************************************!*\
  !*** ./node_modules/vue-flux/dist/vue-flux.umd.min.js ***!
  \********************************************************/
/***/ (function(module) {

(function(t,e){ true?module.exports=e():0})("undefined"!==typeof self?self:this,(function(){return function(t){var e={};function n(i){if(e[i])return e[i].exports;var r=e[i]={i:i,l:!1,exports:{}};return t[i].call(r.exports,r,r.exports,n),r.l=!0,r.exports}return n.m=t,n.c=e,n.d=function(t,e,i){n.o(t,e)||Object.defineProperty(t,e,{enumerable:!0,get:i})},n.r=function(t){"undefined"!==typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(t,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(t,"__esModule",{value:!0})},n.t=function(t,e){if(1&e&&(t=n(t)),8&e)return t;if(4&e&&"object"===typeof t&&t&&t.__esModule)return t;var i=Object.create(null);if(n.r(i),Object.defineProperty(i,"default",{enumerable:!0,value:t}),2&e&&"string"!=typeof t)for(var r in t)n.d(i,r,function(e){return t[e]}.bind(null,r));return i},n.n=function(t){var e=t&&t.__esModule?function(){return t["default"]}:function(){return t};return n.d(e,"a",e),e},n.o=function(t,e){return Object.prototype.hasOwnProperty.call(t,e)},n.p="",n(n.s="fae3")}({"00ee":function(t,e,n){var i=n("b622"),r=i("toStringTag"),o={};o[r]="z",t.exports="[object z]"===String(o)},"02eb":function(t,e,n){var i=n("0301");"string"===typeof i&&(i=[[t.i,i,""]]),i.locals&&(t.exports=i.locals);var r=n("499e").default;r("1365bb3f",i,!0,{sourceMap:!1,shadowMode:!1})},"0301":function(t,e,n){var i=n("24fb");e=i(!1),e.push([t.i,".vue-flux .preloader{position:absolute;top:0;right:0;bottom:0;left:0;z-index:-1}.vue-flux .preloader .spinner{position:absolute;top:50%;left:50%;margin-top:-40px;margin-left:-40px;width:80px;height:80px;z-index:14}.vue-flux .preloader .spinner .pct{position:absolute;right:0;left:0;height:80px;line-height:80px;text-align:center;font-weight:700;z-index:1}.vue-flux .preloader .spinner .border{box-sizing:border-box;width:100%;height:100%;border:14px solid #f3f3f3;border-top-color:#3498db;border-bottom-color:#3498db;border-radius:50%;background-color:#f3f3f3;-webkit-animation:spin 2s linear infinite;animation:spin 2s linear infinite}@-webkit-keyframes spin{0%{transform:rotate(0deg)}to{transform:rotate(1turn)}}@keyframes spin{0%{transform:rotate(0deg)}to{transform:rotate(1turn)}}",""]),t.exports=e},"0366":function(t,e,n){var i=n("1c0b");t.exports=function(t,e,n){if(i(t),void 0===e)return t;switch(n){case 0:return function(){return t.call(e)};case 1:return function(n){return t.call(e,n)};case 2:return function(n,i){return t.call(e,n,i)};case 3:return function(n,i,r){return t.call(e,n,i,r)}}return function(){return t.apply(e,arguments)}}},"057f":function(t,e,n){var i=n("fc6a"),r=n("241c").f,o={}.toString,s="object"==typeof window&&window&&Object.getOwnPropertyNames?Object.getOwnPropertyNames(window):[],a=function(t){try{return r(t)}catch(e){return s.slice()}};t.exports.f=function(t){return s&&"[object Window]"==o.call(t)?a(t):r(i(t))}},"06cf":function(t,e,n){var i=n("83ab"),r=n("d1e7"),o=n("5c6c"),s=n("fc6a"),a=n("c04e"),c=n("5135"),u=n("0cfb"),l=Object.getOwnPropertyDescriptor;e.f=i?l:function(t,e){if(t=s(t),e=a(e,!0),u)try{return l(t,e)}catch(n){}if(c(t,e))return o(!r.f.call(t,e),t[e])}},"0cdd":function(t,e,n){var i=n("24fb");e=i(!1),e.push([t.i,".flux-parallax img{position:absolute;visibility:hidden}.flux-parallax :not(.image){z-index:1}",""]),t.exports=e},"0cfb":function(t,e,n){var i=n("83ab"),r=n("d039"),o=n("cc12");t.exports=!i&&!r((function(){return 7!=Object.defineProperty(o("div"),"a",{get:function(){return 7}}).a}))},1148:function(t,e,n){"use strict";var i=n("a691"),r=n("1d80");t.exports="".repeat||function(t){var e=String(r(this)),n="",o=i(t);if(o<0||o==1/0)throw RangeError("Wrong number of repetitions");for(;o>0;(o>>>=1)&&(e+=e))1&o&&(n+=e);return n}},1276:function(t,e,n){"use strict";var i=n("d784"),r=n("44e7"),o=n("825a"),s=n("1d80"),a=n("4840"),c=n("8aa5"),u=n("50c4"),l=n("14c3"),f=n("9263"),h=n("d039"),d=[].push,p=Math.min,g=4294967295,v=!h((function(){return!RegExp(g,"y")}));i("split",2,(function(t,e,n){var i;return i="c"=="abbc".split(/(b)*/)[1]||4!="test".split(/(?:)/,-1).length||2!="ab".split(/(?:ab)*/).length||4!=".".split(/(.?)(.?)/).length||".".split(/()()/).length>1||"".split(/.?/).length?function(t,n){var i=String(s(this)),o=void 0===n?g:n>>>0;if(0===o)return[];if(void 0===t)return[i];if(!r(t))return e.call(i,t,o);var a,c,u,l=[],h=(t.ignoreCase?"i":"")+(t.multiline?"m":"")+(t.unicode?"u":"")+(t.sticky?"y":""),p=0,v=new RegExp(t.source,h+"g");while(a=f.call(v,i)){if(c=v.lastIndex,c>p&&(l.push(i.slice(p,a.index)),a.length>1&&a.index<i.length&&d.apply(l,a.slice(1)),u=a[0].length,p=c,l.length>=o))break;v.lastIndex===a.index&&v.lastIndex++}return p===i.length?!u&&v.test("")||l.push(""):l.push(i.slice(p)),l.length>o?l.slice(0,o):l}:"0".split(void 0,0).length?function(t,n){return void 0===t&&0===n?[]:e.call(this,t,n)}:e,[function(e,n){var r=s(this),o=void 0==e?void 0:e[t];return void 0!==o?o.call(e,r,n):i.call(String(r),e,n)},function(t,r){var s=n(i,t,this,r,i!==e);if(s.done)return s.value;var f=o(t),h=String(this),d=a(f,RegExp),m=f.unicode,y=(f.ignoreCase?"i":"")+(f.multiline?"m":"")+(f.unicode?"u":"")+(v?"y":"g"),x=new d(v?f:"^(?:"+f.source+")",y),b=void 0===r?g:r>>>0;if(0===b)return[];if(0===h.length)return null===l(x,h)?[h]:[];var w=0,S=0,T=[];while(S<h.length){x.lastIndex=v?S:0;var z,k=l(x,v?h:h.slice(S));if(null===k||(z=p(u(x.lastIndex+(v?0:S)),h.length))===w)S=c(h,S,m);else{if(T.push(h.slice(w,S)),T.length===b)return T;for(var C=1;C<=k.length-1;C++)if(T.push(k[C]),T.length===b)return T;S=w=z}}return T.push(h.slice(w)),T}]}),!v)},"14c3":function(t,e,n){var i=n("c6b6"),r=n("9263");t.exports=function(t,e){var n=t.exec;if("function"===typeof n){var o=n.call(t,e);if("object"!==typeof o)throw TypeError("RegExp exec method returned something other than an Object or null");return o}if("RegExp"!==i(t))throw TypeError("RegExp#exec called on incompatible receiver");return r.call(t,e)}},"159b":function(t,e,n){var i=n("da84"),r=n("fdbc"),o=n("17c2"),s=n("9112");for(var a in r){var c=i[a],u=c&&c.prototype;if(u&&u.forEach!==o)try{s(u,"forEach",o)}catch(l){u.forEach=o}}},"17c2":function(t,e,n){"use strict";var i=n("b727").forEach,r=n("a640"),o=n("ae40"),s=r("forEach"),a=o("forEach");t.exports=s&&a?[].forEach:function(t){return i(this,t,arguments.length>1?arguments[1]:void 0)}},"19aa":function(t,e){t.exports=function(t,e,n){if(!(t instanceof e))throw TypeError("Incorrect "+(n?n+" ":"")+"invocation");return t}},"1be4":function(t,e,n){var i=n("d066");t.exports=i("document","documentElement")},"1c0b":function(t,e){t.exports=function(t){if("function"!=typeof t)throw TypeError(String(t)+" is not a function");return t}},"1c7e":function(t,e,n){var i=n("b622"),r=i("iterator"),o=!1;try{var s=0,a={next:function(){return{done:!!s++}},return:function(){o=!0}};a[r]=function(){return this},Array.from(a,(function(){throw 2}))}catch(c){}t.exports=function(t,e){if(!e&&!o)return!1;var n=!1;try{var i={};i[r]=function(){return{next:function(){return{done:n=!0}}}},t(i)}catch(c){}return n}},"1cdc":function(t,e,n){var i=n("342f");t.exports=/(iphone|ipod|ipad).*applewebkit/i.test(i)},"1d36":function(t,e,n){"use strict";n("91c3")},"1d80":function(t,e){t.exports=function(t){if(void 0==t)throw TypeError("Can't call method on "+t);return t}},"1dde":function(t,e,n){var i=n("d039"),r=n("b622"),o=n("2d00"),s=r("species");t.exports=function(t){return o>=51||!i((function(){var e=[],n=e.constructor={};return n[s]=function(){return{foo:1}},1!==e[t](Boolean).foo}))}},"1dec":function(t,e,n){"use strict";n("02eb")},2266:function(t,e,n){var i=n("825a"),r=n("e95a"),o=n("50c4"),s=n("0366"),a=n("35a1"),c=n("2a62"),u=function(t,e){this.stopped=t,this.result=e};t.exports=function(t,e,n){var l,f,h,d,p,g,v,m=n&&n.that,y=!(!n||!n.AS_ENTRIES),x=!(!n||!n.IS_ITERATOR),b=!(!n||!n.INTERRUPTED),w=s(e,m,1+y+b),S=function(t){return l&&c(l),new u(!0,t)},T=function(t){return y?(i(t),b?w(t[0],t[1],S):w(t[0],t[1])):b?w(t,S):w(t)};if(x)l=t;else{if(f=a(t),"function"!=typeof f)throw TypeError("Target is not iterable");if(r(f)){for(h=0,d=o(t.length);d>h;h++)if(p=T(t[h]),p&&p instanceof u)return p;return new u(!1)}l=f.call(t)}g=l.next;while(!(v=g.call(l)).done){try{p=T(v.value)}catch(z){throw c(l),z}if("object"==typeof p&&p&&p instanceof u)return p}return new u(!1)}},"23cb":function(t,e,n){var i=n("a691"),r=Math.max,o=Math.min;t.exports=function(t,e){var n=i(t);return n<0?r(n+e,0):o(n,e)}},"23e7":function(t,e,n){var i=n("da84"),r=n("06cf").f,o=n("9112"),s=n("6eeb"),a=n("ce4e"),c=n("e893"),u=n("94ca");t.exports=function(t,e){var n,l,f,h,d,p,g=t.target,v=t.global,m=t.stat;if(l=v?i:m?i[g]||a(g,{}):(i[g]||{}).prototype,l)for(f in e){if(d=e[f],t.noTargetGet?(p=r(l,f),h=p&&p.value):h=l[f],n=u(v?f:g+(m?".":"#")+f,t.forced),!n&&void 0!==h){if(typeof d===typeof h)continue;c(d,h)}(t.sham||h&&h.sham)&&o(d,"sham",!0),s(l,f,d,t)}}},"241c":function(t,e,n){var i=n("ca84"),r=n("7839"),o=r.concat("length","prototype");e.f=Object.getOwnPropertyNames||function(t){return i(t,o)}},"24fb":function(t,e,n){"use strict";function i(t,e){var n=t[1]||"",i=t[3];if(!i)return n;if(e&&"function"===typeof btoa){var o=r(i),s=i.sources.map((function(t){return"/*# sourceURL=".concat(i.sourceRoot||"").concat(t," */")}));return[n].concat(s).concat([o]).join("\n")}return[n].join("\n")}function r(t){var e=btoa(unescape(encodeURIComponent(JSON.stringify(t)))),n="sourceMappingURL=data:application/json;charset=utf-8;base64,".concat(e);return"/*# ".concat(n," */")}t.exports=function(t){var e=[];return e.toString=function(){return this.map((function(e){var n=i(e,t);return e[2]?"@media ".concat(e[2]," {").concat(n,"}"):n})).join("")},e.i=function(t,n,i){"string"===typeof t&&(t=[[null,t,""]]);var r={};if(i)for(var o=0;o<this.length;o++){var s=this[o][0];null!=s&&(r[s]=!0)}for(var a=0;a<t.length;a++){var c=[].concat(t[a]);i&&r[c[0]]||(n&&(c[2]?c[2]="".concat(n," and ").concat(c[2]):c[2]=n),e.push(c))}},e}},"25f0":function(t,e,n){"use strict";var i=n("6eeb"),r=n("825a"),o=n("d039"),s=n("ad6d"),a="toString",c=RegExp.prototype,u=c[a],l=o((function(){return"/a/b"!=u.call({source:"a",flags:"b"})})),f=u.name!=a;(l||f)&&i(RegExp.prototype,a,(function(){var t=r(this),e=String(t.source),n=t.flags,i=String(void 0===n&&t instanceof RegExp&&!("flags"in c)?s.call(t):n);return"/"+e+"/"+i}),{unsafe:!0})},2626:function(t,e,n){"use strict";var i=n("d066"),r=n("9bf2"),o=n("b622"),s=n("83ab"),a=o("species");t.exports=function(t){var e=i(t),n=r.f;s&&e&&!e[a]&&n(e,a,{configurable:!0,get:function(){return this}})}},"281b":function(t,e,n){"use strict";n("e3c4")},"2a62":function(t,e,n){var i=n("825a");t.exports=function(t){var e=t["return"];if(void 0!==e)return i(e.call(t)).value}},"2ae5":function(t,e,n){var i=n("24fb");e=i(!1),e.push([t.i,".vue-flux{position:relative}.vue-flux .flux-transition{position:absolute}.vue-flux .complements,.vue-flux>.flux-image{position:absolute;top:0;left:0}.vue-flux .complements{right:0;bottom:0;display:flex;flex-direction:column;justify-content:space-between;z-index:45}.vue-flux .complements .remainder{flex-basis:50%}",""]),t.exports=e},"2c75":function(t,e,n){var i=n("24fb");e=i(!1),e.push([t.i,".vue-flux .flux-button{padding:0;width:6%;min-width:26px;min-height:26px;max-width:40px;max-height:40px}.flux-button{border:0;cursor:pointer;background-color:transparent}.flux-button:hover>svg line,.flux-button:hover>svg polyline{stroke:#ff0}.flux-button:hover>svg polygon,.flux-button:hover>svg rect{fill:#ff0}.flux-button>svg{width:100%}.flux-button>svg *{cursor:pointer}.flux-button>svg>circle{fill:rgba(0,0,0,.7)}.flux-button>svg line,.flux-button>svg polygon,.flux-button>svg polyline,.flux-button>svg rect{stroke-linecap:round;stroke-linejoin:round;stroke:#fff;stroke-width:14;fill:none}.flux-button>svg polygon,.flux-button>svg rect{fill:#fff;stroke-width:0}",""]),t.exports=e},"2cf4":function(t,e,n){var i,r,o,s=n("da84"),a=n("d039"),c=n("0366"),u=n("1be4"),l=n("cc12"),f=n("1cdc"),h=n("605d"),d=s.location,p=s.setImmediate,g=s.clearImmediate,v=s.process,m=s.MessageChannel,y=s.Dispatch,x=0,b={},w="onreadystatechange",S=function(t){if(b.hasOwnProperty(t)){var e=b[t];delete b[t],e()}},T=function(t){return function(){S(t)}},z=function(t){S(t.data)},k=function(t){s.postMessage(t+"",d.protocol+"//"+d.host)};p&&g||(p=function(t){var e=[],n=1;while(arguments.length>n)e.push(arguments[n++]);return b[++x]=function(){("function"==typeof t?t:Function(t)).apply(void 0,e)},i(x),x},g=function(t){delete b[t]},h?i=function(t){v.nextTick(T(t))}:y&&y.now?i=function(t){y.now(T(t))}:m&&!f?(r=new m,o=r.port2,r.port1.onmessage=z,i=c(o.postMessage,o,1)):s.addEventListener&&"function"==typeof postMessage&&!s.importScripts&&d&&"file:"!==d.protocol&&!a(k)?(i=k,s.addEventListener("message",z,!1)):i=w in l("script")?function(t){u.appendChild(l("script"))[w]=function(){u.removeChild(this),S(t)}}:function(t){setTimeout(T(t),0)}),t.exports={set:p,clear:g}},"2d00":function(t,e,n){var i,r,o=n("da84"),s=n("342f"),a=o.process,c=a&&a.versions,u=c&&c.v8;u?(i=u.split("."),r=i[0]+i[1]):s&&(i=s.match(/Edge\/(\d+)/),(!i||i[1]>=74)&&(i=s.match(/Chrome\/(\d+)/),i&&(r=i[1]))),t.exports=r&&+r},"342f":function(t,e,n){var i=n("d066");t.exports=i("navigator","userAgent")||""},"34fa":function(t,e,n){var i=n("24fb");e=i(!1),e.push([t.i,".vue-flux .flux-pagination{flex:none;margin-bottom:.5%}.vue-flux .flux-pagination ul{display:flex;flex-wrap:wrap;justify-content:center;margin:0;padding:0;list-style-type:none;text-align:center;position:relative}.vue-flux .flux-pagination li{display:block;margin:0 1% 1.5% 1%;cursor:pointer;width:2%;height:0;min-width:10px;min-height:10px;padding-bottom:2%;position:relative;box-sizing:border-box}.vue-flux .flux-pagination .pagination-item{position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;border:2px solid #fff;border-radius:50%;background-color:rgba(0,0,0,.7);transition:background-color .2s ease-in,border .2s ease-in}.vue-flux .flux-pagination .pagination-item:hover{border-color:#000;background-color:#fff}.vue-flux .flux-pagination .pagination-item.active{border-color:#fff;background-color:#fff}",""]),t.exports=e},"35a1":function(t,e,n){var i=n("f5df"),r=n("3f8c"),o=n("b622"),s=o("iterator");t.exports=function(t){if(void 0!=t)return t[s]||t["@@iterator"]||r[i(t)]}},"37e8":function(t,e,n){var i=n("83ab"),r=n("9bf2"),o=n("825a"),s=n("df75");t.exports=i?Object.defineProperties:function(t,e){o(t);var n,i=s(e),a=i.length,c=0;while(a>c)r.f(t,n=i[c++],e[n]);return t}},"3bbe":function(t,e,n){var i=n("861d");t.exports=function(t){if(!i(t)&&null!==t)throw TypeError("Can't set "+String(t)+" as a prototype");return t}},"3ca3":function(t,e,n){"use strict";var i=n("6547").charAt,r=n("69f3"),o=n("7dd0"),s="String Iterator",a=r.set,c=r.getterFor(s);o(String,"String",(function(t){a(this,{type:s,string:String(t),index:0})}),(function(){var t,e=c(this),n=e.string,r=e.index;return r>=n.length?{value:void 0,done:!0}:(t=i(n,r),e.index+=t.length,{value:t,done:!1})}))},"3f8c":function(t,e){t.exports={}},"402f":function(t,e,n){var i=n("9281");"string"===typeof i&&(i=[[t.i,i,""]]),i.locals&&(t.exports=i.locals);var r=n("499e").default;r("ab409638",i,!0,{sourceMap:!1,shadowMode:!1})},"408a":function(t,e,n){var i=n("c6b6");t.exports=function(t){if("number"!=typeof t&&"Number"!=i(t))throw TypeError("Incorrect invocation");return+t}},4160:function(t,e,n){"use strict";var i=n("23e7"),r=n("17c2");i({target:"Array",proto:!0,forced:[].forEach!=r},{forEach:r})},"428f":function(t,e,n){var i=n("da84");t.exports=i},"44ad":function(t,e,n){var i=n("d039"),r=n("c6b6"),o="".split;t.exports=i((function(){return!Object("z").propertyIsEnumerable(0)}))?function(t){return"String"==r(t)?o.call(t,""):Object(t)}:Object},"44d2":function(t,e,n){var i=n("b622"),r=n("7c73"),o=n("9bf2"),s=i("unscopables"),a=Array.prototype;void 0==a[s]&&o.f(a,s,{configurable:!0,value:r(null)}),t.exports=function(t){a[s][t]=!0}},"44de":function(t,e,n){var i=n("da84");t.exports=function(t,e){var n=i.console;n&&n.error&&(1===arguments.length?n.error(t):n.error(t,e))}},"44e7":function(t,e,n){var i=n("861d"),r=n("c6b6"),o=n("b622"),s=o("match");t.exports=function(t){var e;return i(t)&&(void 0!==(e=t[s])?!!e:"RegExp"==r(t))}},4840:function(t,e,n){var i=n("825a"),r=n("1c0b"),o=n("b622"),s=o("species");t.exports=function(t,e){var n,o=i(t).constructor;return void 0===o||void 0==(n=i(o)[s])?e:r(n)}},4930:function(t,e,n){var i=n("d039");t.exports=!!Object.getOwnPropertySymbols&&!i((function(){return!String(Symbol())}))},"499e":function(t,e,n){"use strict";function i(t,e){for(var n=[],i={},r=0;r<e.length;r++){var o=e[r],s=o[0],a=o[1],c=o[2],u=o[3],l={id:t+":"+r,css:a,media:c,sourceMap:u};i[s]?i[s].parts.push(l):n.push(i[s]={id:s,parts:[l]})}return n}n.r(e),n.d(e,"default",(function(){return p}));var r="undefined"!==typeof document;if("undefined"!==typeof DEBUG&&DEBUG&&!r)throw new Error("vue-style-loader cannot be used in a non-browser environment. Use { target: 'node' } in your Webpack config to indicate a server-rendering environment.");var o={},s=r&&(document.head||document.getElementsByTagName("head")[0]),a=null,c=0,u=!1,l=function(){},f=null,h="data-vue-ssr-id",d="undefined"!==typeof navigator&&/msie [6-9]\b/.test(navigator.userAgent.toLowerCase());function p(t,e,n,r){u=n,f=r||{};var s=i(t,e);return g(s),function(e){for(var n=[],r=0;r<s.length;r++){var a=s[r],c=o[a.id];c.refs--,n.push(c)}e?(s=i(t,e),g(s)):s=[];for(r=0;r<n.length;r++){c=n[r];if(0===c.refs){for(var u=0;u<c.parts.length;u++)c.parts[u]();delete o[c.id]}}}}function g(t){for(var e=0;e<t.length;e++){var n=t[e],i=o[n.id];if(i){i.refs++;for(var r=0;r<i.parts.length;r++)i.parts[r](n.parts[r]);for(;r<n.parts.length;r++)i.parts.push(m(n.parts[r]));i.parts.length>n.parts.length&&(i.parts.length=n.parts.length)}else{var s=[];for(r=0;r<n.parts.length;r++)s.push(m(n.parts[r]));o[n.id]={id:n.id,refs:1,parts:s}}}}function v(){var t=document.createElement("style");return t.type="text/css",s.appendChild(t),t}function m(t){var e,n,i=document.querySelector("style["+h+'~="'+t.id+'"]');if(i){if(u)return l;i.parentNode.removeChild(i)}if(d){var r=c++;i=a||(a=v()),e=x.bind(null,i,r,!1),n=x.bind(null,i,r,!0)}else i=v(),e=b.bind(null,i),n=function(){i.parentNode.removeChild(i)};return e(t),function(i){if(i){if(i.css===t.css&&i.media===t.media&&i.sourceMap===t.sourceMap)return;e(t=i)}else n()}}var y=function(){var t=[];return function(e,n){return t[e]=n,t.filter(Boolean).join("\n")}}();function x(t,e,n,i){var r=n?"":i.css;if(t.styleSheet)t.styleSheet.cssText=y(e,r);else{var o=document.createTextNode(r),s=t.childNodes;s[e]&&t.removeChild(s[e]),s.length?t.insertBefore(o,s[e]):t.appendChild(o)}}function b(t,e){var n=e.css,i=e.media,r=e.sourceMap;if(i&&t.setAttribute("media",i),f.ssrId&&t.setAttribute(h,e.id),r&&(n+="\n/*# sourceURL="+r.sources[0]+" */",n+="\n/*# sourceMappingURL=data:application/json;base64,"+btoa(unescape(encodeURIComponent(JSON.stringify(r))))+" */"),t.styleSheet)t.styleSheet.cssText=n;else{while(t.firstChild)t.removeChild(t.firstChild);t.appendChild(document.createTextNode(n))}}},"4d64":function(t,e,n){var i=n("fc6a"),r=n("50c4"),o=n("23cb"),s=function(t){return function(e,n,s){var a,c=i(e),u=r(c.length),l=o(s,u);if(t&&n!=n){while(u>l)if(a=c[l++],a!=a)return!0}else for(;u>l;l++)if((t||l in c)&&c[l]===n)return t||l||0;return!t&&-1}};t.exports={includes:s(!0),indexOf:s(!1)}},"4de4":function(t,e,n){"use strict";var i=n("23e7"),r=n("b727").filter,o=n("1dde"),s=n("ae40"),a=o("filter"),c=s("filter");i({target:"Array",proto:!0,forced:!a||!c},{filter:function(t){return r(this,t,arguments.length>1?arguments[1]:void 0)}})},"4df4":function(t,e,n){"use strict";var i=n("0366"),r=n("7b0b"),o=n("9bdd"),s=n("e95a"),a=n("50c4"),c=n("8418"),u=n("35a1");t.exports=function(t){var e,n,l,f,h,d,p=r(t),g="function"==typeof this?this:Array,v=arguments.length,m=v>1?arguments[1]:void 0,y=void 0!==m,x=u(p),b=0;if(y&&(m=i(m,v>2?arguments[2]:void 0,2)),void 0==x||g==Array&&s(x))for(e=a(p.length),n=new g(e);e>b;b++)d=y?m(p[b],b):p[b],c(n,b,d);else for(f=x.call(p),h=f.next,n=new g;!(l=h.call(f)).done;b++)d=y?o(f,m,[l.value,b],!0):l.value,c(n,b,d);return n.length=b,n}},"50c4":function(t,e,n){var i=n("a691"),r=Math.min;t.exports=function(t){return t>0?r(i(t),9007199254740991):0}},5135:function(t,e){var n={}.hasOwnProperty;t.exports=function(t,e){return n.call(t,e)}},5692:function(t,e,n){var i=n("c430"),r=n("c6cd");(t.exports=function(t,e){return r[t]||(r[t]=void 0!==e?e:{})})("versions",[]).push({version:"3.8.3",mode:i?"pure":"global",copyright:"© 2021 Denis Pushkarev (zloirock.ru)"})},"56ef":function(t,e,n){var i=n("d066"),r=n("241c"),o=n("7418"),s=n("825a");t.exports=i("Reflect","ownKeys")||function(t){var e=r.f(s(t)),n=o.f;return n?e.concat(n(t)):e}},5899:function(t,e){t.exports="\t\n\v\f\r                　\u2028\u2029\ufeff"},"58a8":function(t,e,n){var i=n("1d80"),r=n("5899"),o="["+r+"]",s=RegExp("^"+o+o+"*"),a=RegExp(o+o+"*$"),c=function(t){return function(e){var n=String(i(e));return 1&t&&(n=n.replace(s,"")),2&t&&(n=n.replace(a,"")),n}};t.exports={start:c(1),end:c(2),trim:c(3)}},"5a88":function(t,e,n){"use strict";n("71c9")},"5c6c":function(t,e){t.exports=function(t,e){return{enumerable:!(1&t),configurable:!(2&t),writable:!(4&t),value:e}}},"605d":function(t,e,n){var i=n("c6b6"),r=n("da84");t.exports="process"==i(r.process)},"60da":function(t,e,n){"use strict";var i=n("83ab"),r=n("d039"),o=n("df75"),s=n("7418"),a=n("d1e7"),c=n("7b0b"),u=n("44ad"),l=Object.assign,f=Object.defineProperty;t.exports=!l||r((function(){if(i&&1!==l({b:1},l(f({},"a",{enumerable:!0,get:function(){f(this,"b",{value:3,enumerable:!1})}}),{b:2})).b)return!0;var t={},e={},n=Symbol(),r="abcdefghijklmnopqrst";return t[n]=7,r.split("").forEach((function(t){e[t]=t})),7!=l({},t)[n]||o(l({},e)).join("")!=r}))?function(t,e){var n=c(t),r=arguments.length,l=1,f=s.f,h=a.f;while(r>l){var d,p=u(arguments[l++]),g=f?o(p).concat(f(p)):o(p),v=g.length,m=0;while(v>m)d=g[m++],i&&!h.call(p,d)||(n[d]=p[d])}return n}:l},6547:function(t,e,n){var i=n("a691"),r=n("1d80"),o=function(t){return function(e,n){var o,s,a=String(r(e)),c=i(n),u=a.length;return c<0||c>=u?t?"":void 0:(o=a.charCodeAt(c),o<55296||o>56319||c+1===u||(s=a.charCodeAt(c+1))<56320||s>57343?t?a.charAt(c):o:t?a.slice(c,c+2):s-56320+(o-55296<<10)+65536)}};t.exports={codeAt:o(!1),charAt:o(!0)}},"65f0":function(t,e,n){var i=n("861d"),r=n("e8b5"),o=n("b622"),s=o("species");t.exports=function(t,e){var n;return r(t)&&(n=t.constructor,"function"!=typeof n||n!==Array&&!r(n.prototype)?i(n)&&(n=n[s],null===n&&(n=void 0)):n=void 0),new(void 0===n?Array:n)(0===e?0:e)}},"69f3":function(t,e,n){var i,r,o,s=n("7f9a"),a=n("da84"),c=n("861d"),u=n("9112"),l=n("5135"),f=n("c6cd"),h=n("f772"),d=n("d012"),p=a.WeakMap,g=function(t){return o(t)?r(t):i(t,{})},v=function(t){return function(e){var n;if(!c(e)||(n=r(e)).type!==t)throw TypeError("Incompatible receiver, "+t+" required");return n}};if(s){var m=f.state||(f.state=new p),y=m.get,x=m.has,b=m.set;i=function(t,e){return e.facade=t,b.call(m,t,e),e},r=function(t){return y.call(m,t)||{}},o=function(t){return x.call(m,t)}}else{var w=h("state");d[w]=!0,i=function(t,e){return e.facade=t,u(t,w,e),e},r=function(t){return l(t,w)?t[w]:{}},o=function(t){return l(t,w)}}t.exports={set:i,get:r,has:o,enforce:g,getterFor:v}},"6eeb":function(t,e,n){var i=n("da84"),r=n("9112"),o=n("5135"),s=n("ce4e"),a=n("8925"),c=n("69f3"),u=c.get,l=c.enforce,f=String(String).split("String");(t.exports=function(t,e,n,a){var c,u=!!a&&!!a.unsafe,h=!!a&&!!a.enumerable,d=!!a&&!!a.noTargetGet;"function"==typeof n&&("string"!=typeof e||o(n,"name")||r(n,"name",e),c=l(n),c.source||(c.source=f.join("string"==typeof e?e:""))),t!==i?(u?!d&&t[e]&&(h=!0):delete t[e],h?t[e]=n:r(t,e,n)):h?t[e]=n:s(e,n)})(Function.prototype,"toString",(function(){return"function"==typeof this&&u(this).source||a(this)}))},"6fc2":function(t,e,n){"use strict";n("c084")},7156:function(t,e,n){var i=n("861d"),r=n("d2bb");t.exports=function(t,e,n){var o,s;return r&&"function"==typeof(o=e.constructor)&&o!==n&&i(s=o.prototype)&&s!==n.prototype&&r(t,s),t}},"71c9":function(t,e,n){var i=n("86b3");"string"===typeof i&&(i=[[t.i,i,""]]),i.locals&&(t.exports=i.locals);var r=n("499e").default;r("3b7dfa82",i,!0,{sourceMap:!1,shadowMode:!1})},7418:function(t,e){e.f=Object.getOwnPropertySymbols},"746f":function(t,e,n){var i=n("428f"),r=n("5135"),o=n("e538"),s=n("9bf2").f;t.exports=function(t){var e=i.Symbol||(i.Symbol={});r(e,t)||s(e,t,{value:o.f(t)})}},7839:function(t,e){t.exports=["constructor","hasOwnProperty","isPrototypeOf","propertyIsEnumerable","toLocaleString","toString","valueOf"]},"7b0b":function(t,e,n){var i=n("1d80");t.exports=function(t){return Object(i(t))}},"7b93":function(t,e,n){var i=n("24fb");e=i(!1),e.push([t.i,".vue-flux .flux-caption{flex:none;width:100%;font-size:.8rem;line-height:1.1rem;padding:6px;box-sizing:border-box;color:#fff;text-align:center;background-color:rgba(0,0,0,.65);opacity:0}.vue-flux .flux-caption.visible{opacity:1;transition:opacity .3s ease-in}",""]),t.exports=e},"7c73":function(t,e,n){var i,r=n("825a"),o=n("37e8"),s=n("7839"),a=n("d012"),c=n("1be4"),u=n("cc12"),l=n("f772"),f=">",h="<",d="prototype",p="script",g=l("IE_PROTO"),v=function(){},m=function(t){return h+p+f+t+h+"/"+p+f},y=function(t){t.write(m("")),t.close();var e=t.parentWindow.Object;return t=null,e},x=function(){var t,e=u("iframe"),n="java"+p+":";return e.style.display="none",c.appendChild(e),e.src=String(n),t=e.contentWindow.document,t.open(),t.write(m("document.F=Object")),t.close(),t.F},b=function(){try{i=document.domain&&new ActiveXObject("htmlfile")}catch(e){}b=i?y(i):x();var t=s.length;while(t--)delete b[d][s[t]];return b()};a[g]=!0,t.exports=Object.create||function(t,e){var n;return null!==t?(v[d]=r(t),n=new v,v[d]=null,n[g]=t):n=b(),void 0===e?n:o(n,e)}},"7db0":function(t,e,n){"use strict";var i=n("23e7"),r=n("b727").find,o=n("44d2"),s=n("ae40"),a="find",c=!0,u=s(a);a in[]&&Array(1)[a]((function(){c=!1})),i({target:"Array",proto:!0,forced:c||!u},{find:function(t){return r(this,t,arguments.length>1?arguments[1]:void 0)}}),o(a)},"7dd0":function(t,e,n){"use strict";var i=n("23e7"),r=n("9ed3"),o=n("e163"),s=n("d2bb"),a=n("d44e"),c=n("9112"),u=n("6eeb"),l=n("b622"),f=n("c430"),h=n("3f8c"),d=n("ae93"),p=d.IteratorPrototype,g=d.BUGGY_SAFARI_ITERATORS,v=l("iterator"),m="keys",y="values",x="entries",b=function(){return this};t.exports=function(t,e,n,l,d,w,S){r(n,e,l);var T,z,k,C=function(t){if(t===d&&_)return _;if(!g&&t in D)return D[t];switch(t){case m:return function(){return new n(this,t)};case y:return function(){return new n(this,t)};case x:return function(){return new n(this,t)}}return function(){return new n(this)}},E=e+" Iterator",O=!1,D=t.prototype,I=D[v]||D["@@iterator"]||d&&D[d],_=!g&&I||C(d),j="Array"==e&&D.entries||I;if(j&&(T=o(j.call(new t)),p!==Object.prototype&&T.next&&(f||o(T)===p||(s?s(T,p):"function"!=typeof T[v]&&c(T,v,b)),a(T,E,!0,!0),f&&(h[E]=b))),d==y&&I&&I.name!==y&&(O=!0,_=function(){return I.call(this)}),f&&!S||D[v]===_||c(D,v,_),h[e]=_,d)if(z={values:C(y),keys:w?_:C(m),entries:C(x)},S)for(k in z)(g||O||!(k in D))&&u(D,k,z[k]);else i({target:e,proto:!0,forced:g||O},z);return z}},"7f9a":function(t,e,n){var i=n("da84"),r=n("8925"),o=i.WeakMap;t.exports="function"===typeof o&&/native code/.test(r(o))},"825a":function(t,e,n){var i=n("861d");t.exports=function(t){if(!i(t))throw TypeError(String(t)+" is not an object");return t}},"83ab":function(t,e,n){var i=n("d039");t.exports=!i((function(){return 7!=Object.defineProperty({},1,{get:function(){return 7}})[1]}))},8418:function(t,e,n){"use strict";var i=n("c04e"),r=n("9bf2"),o=n("5c6c");t.exports=function(t,e,n){var s=i(e);s in t?r.f(t,s,o(0,n)):t[s]=n}},"861d":function(t,e){t.exports=function(t){return"object"===typeof t?null!==t:"function"===typeof t}},"86b3":function(t,e,n){var i=n("24fb");e=i(!1),e.push([t.i,".vue-flux .flux-index{flex:none;margin-bottom:2%;font-size:0;text-align:center}.vue-flux .flux-index .fade-enter,.vue-flux .flux-index .fade-leave-to{opacity:0}.vue-flux .flux-index .fade-enter-active,.vue-flux .flux-index .fade-leave-active{transition:opacity .3s ease-in}.vue-flux .flux-index nav{position:absolute;top:0;left:0;right:0;bottom:0;display:block;margin:0;overflow:hidden;visibility:hidden}.vue-flux .flux-index nav.visible{z-index:101;visibility:visible}.vue-flux .flux-index ul{display:block;height:100%;margin:0;margin-top:100%;padding:24px 0 0 24px;list-style-type:none;text-align:center;overflow-y:auto;background-color:#000;transition:all .5s linear;font-size:0}.vue-flux .flux-index li{position:relative;display:inline-block;box-sizing:content-box;margin:0 24px 24px 0;cursor:pointer;transition:all .3s ease}.vue-flux .flux-index li:hover{box-shadow:0 0 3px 2px hsla(0,0%,100%,.6)}.vue-flux .flux-index li.current{cursor:auto;border:1px solid #fff;box-shadow:none}",""]),t.exports=e},"87af":function(t,e,n){"use strict";n("b2bc")},8875:function(t,e,n){var i,r,o;(function(n,s){r=[],i=s,o="function"===typeof i?i.apply(e,r):i,void 0===o||(t.exports=o)})("undefined"!==typeof self&&self,(function(){function t(){var e=Object.getOwnPropertyDescriptor(document,"currentScript");if(!e&&"currentScript"in document&&document.currentScript)return document.currentScript;if(e&&e.get!==t&&document.currentScript)return document.currentScript;try{throw new Error}catch(d){var n,i,r,o=/.*at [^(]*\((.*):(.+):(.+)\)$/gi,s=/@([^@]*):(\d+):(\d+)\s*$/gi,a=o.exec(d.stack)||s.exec(d.stack),c=a&&a[1]||!1,u=a&&a[2]||!1,l=document.location.href.replace(document.location.hash,""),f=document.getElementsByTagName("script");c===l&&(n=document.documentElement.outerHTML,i=new RegExp("(?:[^\\n]+?\\n){0,"+(u-2)+"}[^<]*<script>([\\d\\D]*?)<\\/script>[\\d\\D]*","i"),r=n.replace(i,"$1").trim());for(var h=0;h<f.length;h++){if("interactive"===f[h].readyState)return f[h];if(f[h].src===c)return f[h];if(c===l&&f[h].innerHTML&&f[h].innerHTML.trim()===r)return f[h]}return null}}return t}))},8925:function(t,e,n){var i=n("c6cd"),r=Function.toString;"function"!=typeof i.inspectSource&&(i.inspectSource=function(t){return r.call(t)}),t.exports=i.inspectSource},"8aa5":function(t,e,n){"use strict";var i=n("6547").charAt;t.exports=function(t,e,n){return e+(n?i(t,e).length:1)}},"8ca2":function(t,e,n){"use strict";n("af58")},"90e3":function(t,e){var n=0,i=Math.random();t.exports=function(t){return"Symbol("+String(void 0===t?"":t)+")_"+(++n+i).toString(36)}},9112:function(t,e,n){var i=n("83ab"),r=n("9bf2"),o=n("5c6c");t.exports=i?function(t,e,n){return r.f(t,e,o(1,n))}:function(t,e,n){return t[e]=n,t}},"91c3":function(t,e,n){var i=n("2ae5");"string"===typeof i&&(i=[[t.i,i,""]]),i.locals&&(t.exports=i.locals);var r=n("499e").default;r("133e195e",i,!0,{sourceMap:!1,shadowMode:!1})},9263:function(t,e,n){"use strict";var i=n("ad6d"),r=n("9f7f"),o=RegExp.prototype.exec,s=String.prototype.replace,a=o,c=function(){var t=/a/,e=/b*/g;return o.call(t,"a"),o.call(e,"a"),0!==t.lastIndex||0!==e.lastIndex}(),u=r.UNSUPPORTED_Y||r.BROKEN_CARET,l=void 0!==/()??/.exec("")[1],f=c||l||u;f&&(a=function(t){var e,n,r,a,f=this,h=u&&f.sticky,d=i.call(f),p=f.source,g=0,v=t;return h&&(d=d.replace("y",""),-1===d.indexOf("g")&&(d+="g"),v=String(t).slice(f.lastIndex),f.lastIndex>0&&(!f.multiline||f.multiline&&"\n"!==t[f.lastIndex-1])&&(p="(?: "+p+")",v=" "+v,g++),n=new RegExp("^(?:"+p+")",d)),l&&(n=new RegExp("^"+p+"$(?!\\s)",d)),c&&(e=f.lastIndex),r=o.call(h?n:f,v),h?r?(r.input=r.input.slice(g),r[0]=r[0].slice(g),r.index=f.lastIndex,f.lastIndex+=r[0].length):f.lastIndex=0:c&&r&&(f.lastIndex=f.global?r.index+r[0].length:e),l&&r&&r.length>1&&s.call(r[0],n,(function(){for(a=1;a<arguments.length-2;a++)void 0===arguments[a]&&(r[a]=void 0)})),r}),t.exports=a},9281:function(t,e,n){var i=n("24fb");e=i(!1),e.push([t.i,".flux-transition{position:relative}",""]),t.exports=e},"939f":function(t,e,n){var i=n("24fb");e=i(!1),e.push([t.i,".vue-flux .flux-controls{flex:none;display:flex;justify-content:space-between}.vue-flux .flux-controls.fade-enter,.vue-flux .flux-controls.fade-leave-to{opacity:0}.vue-flux .flux-controls.fade-enter-active,.vue-flux .flux-controls.fade-leave-active{transition:opacity .3s ease-in}.vue-flux .flux-controls .prev{margin-left:4%}.vue-flux .flux-controls .next{margin-right:4%}",""]),t.exports=e},"94ca":function(t,e,n){var i=n("d039"),r=/#|\.prototype\./,o=function(t,e){var n=a[s(t)];return n==u||n!=c&&("function"==typeof e?i(e):!!e)},s=o.normalize=function(t){return String(t).replace(r,".").toLowerCase()},a=o.data={},c=o.NATIVE="N",u=o.POLYFILL="P";t.exports=o},"96cf":function(t,e,n){var i=function(t){"use strict";var e,n=Object.prototype,i=n.hasOwnProperty,r="function"===typeof Symbol?Symbol:{},o=r.iterator||"@@iterator",s=r.asyncIterator||"@@asyncIterator",a=r.toStringTag||"@@toStringTag";function c(t,e,n){return Object.defineProperty(t,e,{value:n,enumerable:!0,configurable:!0,writable:!0}),t[e]}try{c({},"")}catch(j){c=function(t,e,n){return t[e]=n}}function u(t,e,n,i){var r=e&&e.prototype instanceof v?e:v,o=Object.create(r.prototype),s=new D(i||[]);return o._invoke=k(t,n,s),o}function l(t,e,n){try{return{type:"normal",arg:t.call(e,n)}}catch(j){return{type:"throw",arg:j}}}t.wrap=u;var f="suspendedStart",h="suspendedYield",d="executing",p="completed",g={};function v(){}function m(){}function y(){}var x={};x[o]=function(){return this};var b=Object.getPrototypeOf,w=b&&b(b(I([])));w&&w!==n&&i.call(w,o)&&(x=w);var S=y.prototype=v.prototype=Object.create(x);function T(t){["next","throw","return"].forEach((function(e){c(t,e,(function(t){return this._invoke(e,t)}))}))}function z(t,e){function n(r,o,s,a){var c=l(t[r],t,o);if("throw"!==c.type){var u=c.arg,f=u.value;return f&&"object"===typeof f&&i.call(f,"__await")?e.resolve(f.__await).then((function(t){n("next",t,s,a)}),(function(t){n("throw",t,s,a)})):e.resolve(f).then((function(t){u.value=t,s(u)}),(function(t){return n("throw",t,s,a)}))}a(c.arg)}var r;function o(t,i){function o(){return new e((function(e,r){n(t,i,e,r)}))}return r=r?r.then(o,o):o()}this._invoke=o}function k(t,e,n){var i=f;return function(r,o){if(i===d)throw new Error("Generator is already running");if(i===p){if("throw"===r)throw o;return _()}n.method=r,n.arg=o;while(1){var s=n.delegate;if(s){var a=C(s,n);if(a){if(a===g)continue;return a}}if("next"===n.method)n.sent=n._sent=n.arg;else if("throw"===n.method){if(i===f)throw i=p,n.arg;n.dispatchException(n.arg)}else"return"===n.method&&n.abrupt("return",n.arg);i=d;var c=l(t,e,n);if("normal"===c.type){if(i=n.done?p:h,c.arg===g)continue;return{value:c.arg,done:n.done}}"throw"===c.type&&(i=p,n.method="throw",n.arg=c.arg)}}}function C(t,n){var i=t.iterator[n.method];if(i===e){if(n.delegate=null,"throw"===n.method){if(t.iterator["return"]&&(n.method="return",n.arg=e,C(t,n),"throw"===n.method))return g;n.method="throw",n.arg=new TypeError("The iterator does not provide a 'throw' method")}return g}var r=l(i,t.iterator,n.arg);if("throw"===r.type)return n.method="throw",n.arg=r.arg,n.delegate=null,g;var o=r.arg;return o?o.done?(n[t.resultName]=o.value,n.next=t.nextLoc,"return"!==n.method&&(n.method="next",n.arg=e),n.delegate=null,g):o:(n.method="throw",n.arg=new TypeError("iterator result is not an object"),n.delegate=null,g)}function E(t){var e={tryLoc:t[0]};1 in t&&(e.catchLoc=t[1]),2 in t&&(e.finallyLoc=t[2],e.afterLoc=t[3]),this.tryEntries.push(e)}function O(t){var e=t.completion||{};e.type="normal",delete e.arg,t.completion=e}function D(t){this.tryEntries=[{tryLoc:"root"}],t.forEach(E,this),this.reset(!0)}function I(t){if(t){var n=t[o];if(n)return n.call(t);if("function"===typeof t.next)return t;if(!isNaN(t.length)){var r=-1,s=function n(){while(++r<t.length)if(i.call(t,r))return n.value=t[r],n.done=!1,n;return n.value=e,n.done=!0,n};return s.next=s}}return{next:_}}function _(){return{value:e,done:!0}}return m.prototype=S.constructor=y,y.constructor=m,m.displayName=c(y,a,"GeneratorFunction"),t.isGeneratorFunction=function(t){var e="function"===typeof t&&t.constructor;return!!e&&(e===m||"GeneratorFunction"===(e.displayName||e.name))},t.mark=function(t){return Object.setPrototypeOf?Object.setPrototypeOf(t,y):(t.__proto__=y,c(t,a,"GeneratorFunction")),t.prototype=Object.create(S),t},t.awrap=function(t){return{__await:t}},T(z.prototype),z.prototype[s]=function(){return this},t.AsyncIterator=z,t.async=function(e,n,i,r,o){void 0===o&&(o=Promise);var s=new z(u(e,n,i,r),o);return t.isGeneratorFunction(n)?s:s.next().then((function(t){return t.done?t.value:s.next()}))},T(S),c(S,a,"Generator"),S[o]=function(){return this},S.toString=function(){return"[object Generator]"},t.keys=function(t){var e=[];for(var n in t)e.push(n);return e.reverse(),function n(){while(e.length){var i=e.pop();if(i in t)return n.value=i,n.done=!1,n}return n.done=!0,n}},t.values=I,D.prototype={constructor:D,reset:function(t){if(this.prev=0,this.next=0,this.sent=this._sent=e,this.done=!1,this.delegate=null,this.method="next",this.arg=e,this.tryEntries.forEach(O),!t)for(var n in this)"t"===n.charAt(0)&&i.call(this,n)&&!isNaN(+n.slice(1))&&(this[n]=e)},stop:function(){this.done=!0;var t=this.tryEntries[0],e=t.completion;if("throw"===e.type)throw e.arg;return this.rval},dispatchException:function(t){if(this.done)throw t;var n=this;function r(i,r){return a.type="throw",a.arg=t,n.next=i,r&&(n.method="next",n.arg=e),!!r}for(var o=this.tryEntries.length-1;o>=0;--o){var s=this.tryEntries[o],a=s.completion;if("root"===s.tryLoc)return r("end");if(s.tryLoc<=this.prev){var c=i.call(s,"catchLoc"),u=i.call(s,"finallyLoc");if(c&&u){if(this.prev<s.catchLoc)return r(s.catchLoc,!0);if(this.prev<s.finallyLoc)return r(s.finallyLoc)}else if(c){if(this.prev<s.catchLoc)return r(s.catchLoc,!0)}else{if(!u)throw new Error("try statement without catch or finally");if(this.prev<s.finallyLoc)return r(s.finallyLoc)}}}},abrupt:function(t,e){for(var n=this.tryEntries.length-1;n>=0;--n){var r=this.tryEntries[n];if(r.tryLoc<=this.prev&&i.call(r,"finallyLoc")&&this.prev<r.finallyLoc){var o=r;break}}o&&("break"===t||"continue"===t)&&o.tryLoc<=e&&e<=o.finallyLoc&&(o=null);var s=o?o.completion:{};return s.type=t,s.arg=e,o?(this.method="next",this.next=o.finallyLoc,g):this.complete(s)},complete:function(t,e){if("throw"===t.type)throw t.arg;return"break"===t.type||"continue"===t.type?this.next=t.arg:"return"===t.type?(this.rval=this.arg=t.arg,this.method="return",this.next="end"):"normal"===t.type&&e&&(this.next=e),g},finish:function(t){for(var e=this.tryEntries.length-1;e>=0;--e){var n=this.tryEntries[e];if(n.finallyLoc===t)return this.complete(n.completion,n.afterLoc),O(n),g}},catch:function(t){for(var e=this.tryEntries.length-1;e>=0;--e){var n=this.tryEntries[e];if(n.tryLoc===t){var i=n.completion;if("throw"===i.type){var r=i.arg;O(n)}return r}}throw new Error("illegal catch attempt")},delegateYield:function(t,n,i){return this.delegate={iterator:I(t),resultName:n,nextLoc:i},"next"===this.method&&(this.arg=e),g}},t}(t.exports);try{regeneratorRuntime=i}catch(r){Function("r","regeneratorRuntime = r")(i)}},"99af":function(t,e,n){"use strict";var i=n("23e7"),r=n("d039"),o=n("e8b5"),s=n("861d"),a=n("7b0b"),c=n("50c4"),u=n("8418"),l=n("65f0"),f=n("1dde"),h=n("b622"),d=n("2d00"),p=h("isConcatSpreadable"),g=9007199254740991,v="Maximum allowed index exceeded",m=d>=51||!r((function(){var t=[];return t[p]=!1,t.concat()[0]!==t})),y=f("concat"),x=function(t){if(!s(t))return!1;var e=t[p];return void 0!==e?!!e:o(t)},b=!m||!y;i({target:"Array",proto:!0,forced:b},{concat:function(t){var e,n,i,r,o,s=a(this),f=l(s,0),h=0;for(e=-1,i=arguments.length;e<i;e++)if(o=-1===e?s:arguments[e],x(o)){if(r=c(o.length),h+r>g)throw TypeError(v);for(n=0;n<r;n++,h++)n in o&&u(f,h,o[n])}else{if(h>=g)throw TypeError(v);u(f,h++,o)}return f.length=h,f}})},"9bdd":function(t,e,n){var i=n("825a"),r=n("2a62");t.exports=function(t,e,n,o){try{return o?e(i(n)[0],n[1]):e(n)}catch(s){throw r(t),s}}},"9bf2":function(t,e,n){var i=n("83ab"),r=n("0cfb"),o=n("825a"),s=n("c04e"),a=Object.defineProperty;e.f=i?a:function(t,e,n){if(o(t),e=s(e,!0),o(n),r)try{return a(t,e,n)}catch(i){}if("get"in n||"set"in n)throw TypeError("Accessors not supported");return"value"in n&&(t[e]=n.value),t}},"9ed3":function(t,e,n){"use strict";var i=n("ae93").IteratorPrototype,r=n("7c73"),o=n("5c6c"),s=n("d44e"),a=n("3f8c"),c=function(){return this};t.exports=function(t,e,n){var u=e+" Iterator";return t.prototype=r(i,{next:o(1,n)}),s(t,u,!1,!0),a[u]=c,t}},"9f7f":function(t,e,n){"use strict";var i=n("d039");function r(t,e){return RegExp(t,e)}e.UNSUPPORTED_Y=i((function(){var t=r("a","y");return t.lastIndex=2,null!=t.exec("abcd")})),e.BROKEN_CARET=i((function(){var t=r("^r","gy");return t.lastIndex=2,null!=t.exec("str")}))},a4b4:function(t,e,n){var i=n("342f");t.exports=/web0s(?!.*chrome)/i.test(i)},a4d3:function(t,e,n){"use strict";var i=n("23e7"),r=n("da84"),o=n("d066"),s=n("c430"),a=n("83ab"),c=n("4930"),u=n("fdbf"),l=n("d039"),f=n("5135"),h=n("e8b5"),d=n("861d"),p=n("825a"),g=n("7b0b"),v=n("fc6a"),m=n("c04e"),y=n("5c6c"),x=n("7c73"),b=n("df75"),w=n("241c"),S=n("057f"),T=n("7418"),z=n("06cf"),k=n("9bf2"),C=n("d1e7"),E=n("9112"),O=n("6eeb"),D=n("5692"),I=n("f772"),_=n("d012"),j=n("90e3"),$=n("b622"),F=n("e538"),P=n("746f"),R=n("d44e"),N=n("69f3"),M=n("b727").forEach,L=I("hidden"),A="Symbol",B="prototype",G=$("toPrimitive"),W=N.set,Y=N.getterFor(A),U=Object[B],X=r.Symbol,H=o("JSON","stringify"),V=z.f,q=k.f,K=S.f,J=C.f,Z=D("symbols"),Q=D("op-symbols"),tt=D("string-to-symbol-registry"),et=D("symbol-to-string-registry"),nt=D("wks"),it=r.QObject,rt=!it||!it[B]||!it[B].findChild,ot=a&&l((function(){return 7!=x(q({},"a",{get:function(){return q(this,"a",{value:7}).a}})).a}))?function(t,e,n){var i=V(U,e);i&&delete U[e],q(t,e,n),i&&t!==U&&q(U,e,i)}:q,st=function(t,e){var n=Z[t]=x(X[B]);return W(n,{type:A,tag:t,description:e}),a||(n.description=e),n},at=u?function(t){return"symbol"==typeof t}:function(t){return Object(t)instanceof X},ct=function(t,e,n){t===U&&ct(Q,e,n),p(t);var i=m(e,!0);return p(n),f(Z,i)?(n.enumerable?(f(t,L)&&t[L][i]&&(t[L][i]=!1),n=x(n,{enumerable:y(0,!1)})):(f(t,L)||q(t,L,y(1,{})),t[L][i]=!0),ot(t,i,n)):q(t,i,n)},ut=function(t,e){p(t);var n=v(e),i=b(n).concat(pt(n));return M(i,(function(e){a&&!ft.call(n,e)||ct(t,e,n[e])})),t},lt=function(t,e){return void 0===e?x(t):ut(x(t),e)},ft=function(t){var e=m(t,!0),n=J.call(this,e);return!(this===U&&f(Z,e)&&!f(Q,e))&&(!(n||!f(this,e)||!f(Z,e)||f(this,L)&&this[L][e])||n)},ht=function(t,e){var n=v(t),i=m(e,!0);if(n!==U||!f(Z,i)||f(Q,i)){var r=V(n,i);return!r||!f(Z,i)||f(n,L)&&n[L][i]||(r.enumerable=!0),r}},dt=function(t){var e=K(v(t)),n=[];return M(e,(function(t){f(Z,t)||f(_,t)||n.push(t)})),n},pt=function(t){var e=t===U,n=K(e?Q:v(t)),i=[];return M(n,(function(t){!f(Z,t)||e&&!f(U,t)||i.push(Z[t])})),i};if(c||(X=function(){if(this instanceof X)throw TypeError("Symbol is not a constructor");var t=arguments.length&&void 0!==arguments[0]?String(arguments[0]):void 0,e=j(t),n=function(t){this===U&&n.call(Q,t),f(this,L)&&f(this[L],e)&&(this[L][e]=!1),ot(this,e,y(1,t))};return a&&rt&&ot(U,e,{configurable:!0,set:n}),st(e,t)},O(X[B],"toString",(function(){return Y(this).tag})),O(X,"withoutSetter",(function(t){return st(j(t),t)})),C.f=ft,k.f=ct,z.f=ht,w.f=S.f=dt,T.f=pt,F.f=function(t){return st($(t),t)},a&&(q(X[B],"description",{configurable:!0,get:function(){return Y(this).description}}),s||O(U,"propertyIsEnumerable",ft,{unsafe:!0}))),i({global:!0,wrap:!0,forced:!c,sham:!c},{Symbol:X}),M(b(nt),(function(t){P(t)})),i({target:A,stat:!0,forced:!c},{for:function(t){var e=String(t);if(f(tt,e))return tt[e];var n=X(e);return tt[e]=n,et[n]=e,n},keyFor:function(t){if(!at(t))throw TypeError(t+" is not a symbol");if(f(et,t))return et[t]},useSetter:function(){rt=!0},useSimple:function(){rt=!1}}),i({target:"Object",stat:!0,forced:!c,sham:!a},{create:lt,defineProperty:ct,defineProperties:ut,getOwnPropertyDescriptor:ht}),i({target:"Object",stat:!0,forced:!c},{getOwnPropertyNames:dt,getOwnPropertySymbols:pt}),i({target:"Object",stat:!0,forced:l((function(){T.f(1)}))},{getOwnPropertySymbols:function(t){return T.f(g(t))}}),H){var gt=!c||l((function(){var t=X();return"[null]"!=H([t])||"{}"!=H({a:t})||"{}"!=H(Object(t))}));i({target:"JSON",stat:!0,forced:gt},{stringify:function(t,e,n){var i,r=[t],o=1;while(arguments.length>o)r.push(arguments[o++]);if(i=e,(d(e)||void 0!==t)&&!at(t))return h(e)||(e=function(t,e){if("function"==typeof i&&(e=i.call(this,t,e)),!at(e))return e}),r[1]=e,H.apply(null,r)}})}X[B][G]||E(X[B],G,X[B].valueOf),R(X,A),_[L]=!0},a53f:function(t,e,n){var i=n("939f");"string"===typeof i&&(i=[[t.i,i,""]]),i.locals&&(t.exports=i.locals);var r=n("499e").default;r("513619ea",i,!0,{sourceMap:!1,shadowMode:!1})},a630:function(t,e,n){var i=n("23e7"),r=n("4df4"),o=n("1c7e"),s=!o((function(t){Array.from(t)}));i({target:"Array",stat:!0,forced:s},{from:r})},a640:function(t,e,n){"use strict";var i=n("d039");t.exports=function(t,e){var n=[][t];return!!n&&i((function(){n.call(null,e||function(){throw 1},1)}))}},a691:function(t,e){var n=Math.ceil,i=Math.floor;t.exports=function(t){return isNaN(t=+t)?0:(t>0?i:n)(t)}},a79d:function(t,e,n){"use strict";var i=n("23e7"),r=n("c430"),o=n("fea9"),s=n("d039"),a=n("d066"),c=n("4840"),u=n("cdf9"),l=n("6eeb"),f=!!o&&s((function(){o.prototype["finally"].call({then:function(){}},(function(){}))}));i({target:"Promise",proto:!0,real:!0,forced:f},{finally:function(t){var e=c(this,a("Promise")),n="function"==typeof t;return this.then(n?function(n){return u(e,t()).then((function(){return n}))}:t,n?function(n){return u(e,t()).then((function(){throw n}))}:t)}}),r||"function"!=typeof o||o.prototype["finally"]||l(o.prototype,"finally",a("Promise").prototype["finally"])},a9e3:function(t,e,n){"use strict";var i=n("83ab"),r=n("da84"),o=n("94ca"),s=n("6eeb"),a=n("5135"),c=n("c6b6"),u=n("7156"),l=n("c04e"),f=n("d039"),h=n("7c73"),d=n("241c").f,p=n("06cf").f,g=n("9bf2").f,v=n("58a8").trim,m="Number",y=r[m],x=y.prototype,b=c(h(x))==m,w=function(t){var e,n,i,r,o,s,a,c,u=l(t,!1);if("string"==typeof u&&u.length>2)if(u=v(u),e=u.charCodeAt(0),43===e||45===e){if(n=u.charCodeAt(2),88===n||120===n)return NaN}else if(48===e){switch(u.charCodeAt(1)){case 66:case 98:i=2,r=49;break;case 79:case 111:i=8,r=55;break;default:return+u}for(o=u.slice(2),s=o.length,a=0;a<s;a++)if(c=o.charCodeAt(a),c<48||c>r)return NaN;return parseInt(o,i)}return+u};if(o(m,!y(" 0o1")||!y("0b1")||y("+0x1"))){for(var S,T=function(t){var e=arguments.length<1?0:t,n=this;return n instanceof T&&(b?f((function(){x.valueOf.call(n)})):c(n)!=m)?u(new y(w(e)),n,T):w(e)},z=i?d(y):"MAX_VALUE,MIN_VALUE,NaN,NEGATIVE_INFINITY,POSITIVE_INFINITY,EPSILON,isFinite,isInteger,isNaN,isSafeInteger,MAX_SAFE_INTEGER,MIN_SAFE_INTEGER,parseFloat,parseInt,isInteger,fromString,range".split(","),k=0;z.length>k;k++)a(y,S=z[k])&&!a(T,S)&&g(T,S,p(y,S));T.prototype=x,x.constructor=T,s(r,m,T)}},ac1f:function(t,e,n){"use strict";var i=n("23e7"),r=n("9263");i({target:"RegExp",proto:!0,forced:/./.exec!==r},{exec:r})},ad6d:function(t,e,n){"use strict";var i=n("825a");t.exports=function(){var t=i(this),e="";return t.global&&(e+="g"),t.ignoreCase&&(e+="i"),t.multiline&&(e+="m"),t.dotAll&&(e+="s"),t.unicode&&(e+="u"),t.sticky&&(e+="y"),e}},ae40:function(t,e,n){var i=n("83ab"),r=n("d039"),o=n("5135"),s=Object.defineProperty,a={},c=function(t){throw t};t.exports=function(t,e){if(o(a,t))return a[t];e||(e={});var n=[][t],u=!!o(e,"ACCESSORS")&&e.ACCESSORS,l=o(e,0)?e[0]:c,f=o(e,1)?e[1]:void 0;return a[t]=!!n&&!r((function(){if(u&&!i)return!0;var t={length:-1};u?s(t,1,{enumerable:!0,get:c}):t[1]=1,n.call(t,l,f)}))}},ae93:function(t,e,n){"use strict";var i,r,o,s=n("d039"),a=n("e163"),c=n("9112"),u=n("5135"),l=n("b622"),f=n("c430"),h=l("iterator"),d=!1,p=function(){return this};[].keys&&(o=[].keys(),"next"in o?(r=a(a(o)),r!==Object.prototype&&(i=r)):d=!0);var g=void 0==i||s((function(){var t={};return i[h].call(t)!==t}));g&&(i={}),f&&!g||u(i,h)||c(i,h,p),t.exports={IteratorPrototype:i,BUGGY_SAFARI_ITERATORS:d}},af58:function(t,e,n){var i=n("2c75");"string"===typeof i&&(i=[[t.i,i,""]]),i.locals&&(t.exports=i.locals);var r=n("499e").default;r("d6caf144",i,!0,{sourceMap:!1,shadowMode:!1})},b041:function(t,e,n){"use strict";var i=n("00ee"),r=n("f5df");t.exports=i?{}.toString:function(){return"[object "+r(this)+"]"}},b0c0:function(t,e,n){var i=n("83ab"),r=n("9bf2").f,o=Function.prototype,s=o.toString,a=/^\s*function ([^ (]*)/,c="name";i&&!(c in o)&&r(o,c,{configurable:!0,get:function(){try{return s.call(this).match(a)[1]}catch(t){return""}}})},b2bc:function(t,e,n){var i=n("7b93");"string"===typeof i&&(i=[[t.i,i,""]]),i.locals&&(t.exports=i.locals);var r=n("499e").default;r("3113e73f",i,!0,{sourceMap:!1,shadowMode:!1})},b575:function(t,e,n){var i,r,o,s,a,c,u,l,f=n("da84"),h=n("06cf").f,d=n("2cf4").set,p=n("1cdc"),g=n("a4b4"),v=n("605d"),m=f.MutationObserver||f.WebKitMutationObserver,y=f.document,x=f.process,b=f.Promise,w=h(f,"queueMicrotask"),S=w&&w.value;S||(i=function(){var t,e;v&&(t=x.domain)&&t.exit();while(r){e=r.fn,r=r.next;try{e()}catch(n){throw r?s():o=void 0,n}}o=void 0,t&&t.enter()},p||v||g||!m||!y?b&&b.resolve?(u=b.resolve(void 0),l=u.then,s=function(){l.call(u,i)}):s=v?function(){x.nextTick(i)}:function(){d.call(f,i)}:(a=!0,c=y.createTextNode(""),new m(i).observe(c,{characterData:!0}),s=function(){c.data=a=!a})),t.exports=S||function(t){var e={fn:t,next:void 0};o&&(o.next=e),r||(r=e,s()),o=e}},b622:function(t,e,n){var i=n("da84"),r=n("5692"),o=n("5135"),s=n("90e3"),a=n("4930"),c=n("fdbf"),u=r("wks"),l=i.Symbol,f=c?l:l&&l.withoutSetter||s;t.exports=function(t){return o(u,t)||(a&&o(l,t)?u[t]=l[t]:u[t]=f("Symbol."+t)),u[t]}},b64b:function(t,e,n){var i=n("23e7"),r=n("7b0b"),o=n("df75"),s=n("d039"),a=s((function(){o(1)}));i({target:"Object",stat:!0,forced:a},{keys:function(t){return o(r(t))}})},b680:function(t,e,n){"use strict";var i=n("23e7"),r=n("a691"),o=n("408a"),s=n("1148"),a=n("d039"),c=1..toFixed,u=Math.floor,l=function(t,e,n){return 0===e?n:e%2===1?l(t,e-1,n*t):l(t*t,e/2,n)},f=function(t){var e=0,n=t;while(n>=4096)e+=12,n/=4096;while(n>=2)e+=1,n/=2;return e},h=c&&("0.000"!==8e-5.toFixed(3)||"1"!==.9.toFixed(0)||"1.25"!==1.255.toFixed(2)||"1000000000000000128"!==(0xde0b6b3a7640080).toFixed(0))||!a((function(){c.call({})}));i({target:"Number",proto:!0,forced:h},{toFixed:function(t){var e,n,i,a,c=o(this),h=r(t),d=[0,0,0,0,0,0],p="",g="0",v=function(t,e){var n=-1,i=e;while(++n<6)i+=t*d[n],d[n]=i%1e7,i=u(i/1e7)},m=function(t){var e=6,n=0;while(--e>=0)n+=d[e],d[e]=u(n/t),n=n%t*1e7},y=function(){var t=6,e="";while(--t>=0)if(""!==e||0===t||0!==d[t]){var n=String(d[t]);e=""===e?n:e+s.call("0",7-n.length)+n}return e};if(h<0||h>20)throw RangeError("Incorrect fraction digits");if(c!=c)return"NaN";if(c<=-1e21||c>=1e21)return String(c);if(c<0&&(p="-",c=-c),c>1e-21)if(e=f(c*l(2,69,1))-69,n=e<0?c*l(2,-e,1):c/l(2,e,1),n*=4503599627370496,e=52-e,e>0){v(0,n),i=h;while(i>=7)v(1e7,0),i-=7;v(l(10,i,1),0),i=e-1;while(i>=23)m(1<<23),i-=23;m(1<<i),v(1,1),m(2),g=y()}else v(0,n),v(1<<-e,0),g=y()+s.call("0",h);return h>0?(a=g.length,g=p+(a<=h?"0."+s.call("0",h-a)+g:g.slice(0,a-h)+"."+g.slice(a-h))):g=p+g,g}})},b727:function(t,e,n){var i=n("0366"),r=n("44ad"),o=n("7b0b"),s=n("50c4"),a=n("65f0"),c=[].push,u=function(t){var e=1==t,n=2==t,u=3==t,l=4==t,f=6==t,h=7==t,d=5==t||f;return function(p,g,v,m){for(var y,x,b=o(p),w=r(b),S=i(g,v,3),T=s(w.length),z=0,k=m||a,C=e?k(p,T):n||h?k(p,0):void 0;T>z;z++)if((d||z in w)&&(y=w[z],x=S(y,z,b),t))if(e)C[z]=x;else if(x)switch(t){case 3:return!0;case 5:return y;case 6:return z;case 2:c.call(C,y)}else switch(t){case 4:return!1;case 7:c.call(C,y)}return f?-1:u||l?l:C}};t.exports={forEach:u(0),map:u(1),filter:u(2),some:u(3),every:u(4),find:u(5),findIndex:u(6),filterOut:u(7)}},c04e:function(t,e,n){var i=n("861d");t.exports=function(t,e){if(!i(t))return t;var n,r;if(e&&"function"==typeof(n=t.toString)&&!i(r=n.call(t)))return r;if("function"==typeof(n=t.valueOf)&&!i(r=n.call(t)))return r;if(!e&&"function"==typeof(n=t.toString)&&!i(r=n.call(t)))return r;throw TypeError("Can't convert object to primitive value")}},c084:function(t,e,n){var i=n("34fa");"string"===typeof i&&(i=[[t.i,i,""]]),i.locals&&(t.exports=i.locals);var r=n("499e").default;r("2aa56e5a",i,!0,{sourceMap:!1,shadowMode:!1})},c430:function(t,e){t.exports=!1},c6b6:function(t,e){var n={}.toString;t.exports=function(t){return n.call(t).slice(8,-1)}},c6cd:function(t,e,n){var i=n("da84"),r=n("ce4e"),o="__core-js_shared__",s=i[o]||r(o,{});t.exports=s},c8ba:function(t,e){var n;n=function(){return this}();try{n=n||new Function("return this")()}catch(i){"object"===typeof window&&(n=window)}t.exports=n},ca84:function(t,e,n){var i=n("5135"),r=n("fc6a"),o=n("4d64").indexOf,s=n("d012");t.exports=function(t,e){var n,a=r(t),c=0,u=[];for(n in a)!i(s,n)&&i(a,n)&&u.push(n);while(e.length>c)i(a,n=e[c++])&&(~o(u,n)||u.push(n));return u}},caad:function(t,e,n){"use strict";var i=n("23e7"),r=n("4d64").includes,o=n("44d2"),s=n("ae40"),a=s("indexOf",{ACCESSORS:!0,1:0});i({target:"Array",proto:!0,forced:!a},{includes:function(t){return r(this,t,arguments.length>1?arguments[1]:void 0)}}),o("includes")},cc12:function(t,e,n){var i=n("da84"),r=n("861d"),o=i.document,s=r(o)&&r(o.createElement);t.exports=function(t){return s?o.createElement(t):{}}},cca6:function(t,e,n){var i=n("23e7"),r=n("60da");i({target:"Object",stat:!0,forced:Object.assign!==r},{assign:r})},cdf9:function(t,e,n){var i=n("825a"),r=n("861d"),o=n("f069");t.exports=function(t,e){if(i(t),r(e)&&e.constructor===t)return e;var n=o.f(t),s=n.resolve;return s(e),n.promise}},ce4e:function(t,e,n){var i=n("da84"),r=n("9112");t.exports=function(t,e){try{r(i,t,e)}catch(n){i[t]=e}return e}},d012:function(t,e){t.exports={}},d039:function(t,e){t.exports=function(t){try{return!!t()}catch(e){return!0}}},d066:function(t,e,n){var i=n("428f"),r=n("da84"),o=function(t){return"function"==typeof t?t:void 0};t.exports=function(t,e){return arguments.length<2?o(i[t])||o(r[t]):i[t]&&i[t][e]||r[t]&&r[t][e]}},d1e7:function(t,e,n){"use strict";var i={}.propertyIsEnumerable,r=Object.getOwnPropertyDescriptor,o=r&&!i.call({1:2},1);e.f=o?function(t){var e=r(this,t);return!!e&&e.enumerable}:i},d28b:function(t,e,n){var i=n("746f");i("iterator")},d2bb:function(t,e,n){var i=n("825a"),r=n("3bbe");t.exports=Object.setPrototypeOf||("__proto__"in{}?function(){var t,e=!1,n={};try{t=Object.getOwnPropertyDescriptor(Object.prototype,"__proto__").set,t.call(n,[]),e=n instanceof Array}catch(o){}return function(n,o){return i(n),r(o),e?t.call(n,o):n.__proto__=o,n}}():void 0)},d3b7:function(t,e,n){var i=n("00ee"),r=n("6eeb"),o=n("b041");i||r(Object.prototype,"toString",o,{unsafe:!0})},d44e:function(t,e,n){var i=n("9bf2").f,r=n("5135"),o=n("b622"),s=o("toStringTag");t.exports=function(t,e,n){t&&!r(t=n?t:t.prototype,s)&&i(t,s,{configurable:!0,value:e})}},d784:function(t,e,n){"use strict";n("ac1f");var i=n("6eeb"),r=n("d039"),o=n("b622"),s=n("9263"),a=n("9112"),c=o("species"),u=!r((function(){var t=/./;return t.exec=function(){var t=[];return t.groups={a:"7"},t},"7"!=="".replace(t,"$<a>")})),l=function(){return"$0"==="a".replace(/./,"$0")}(),f=o("replace"),h=function(){return!!/./[f]&&""===/./[f]("a","$0")}(),d=!r((function(){var t=/(?:)/,e=t.exec;t.exec=function(){return e.apply(this,arguments)};var n="ab".split(t);return 2!==n.length||"a"!==n[0]||"b"!==n[1]}));t.exports=function(t,e,n,f){var p=o(t),g=!r((function(){var e={};return e[p]=function(){return 7},7!=""[t](e)})),v=g&&!r((function(){var e=!1,n=/a/;return"split"===t&&(n={},n.constructor={},n.constructor[c]=function(){return n},n.flags="",n[p]=/./[p]),n.exec=function(){return e=!0,null},n[p](""),!e}));if(!g||!v||"replace"===t&&(!u||!l||h)||"split"===t&&!d){var m=/./[p],y=n(p,""[t],(function(t,e,n,i,r){return e.exec===s?g&&!r?{done:!0,value:m.call(e,n,i)}:{done:!0,value:t.call(n,e,i)}:{done:!1}}),{REPLACE_KEEPS_$0:l,REGEXP_REPLACE_SUBSTITUTES_UNDEFINED_CAPTURE:h}),x=y[0],b=y[1];i(String.prototype,t,x),i(RegExp.prototype,p,2==e?function(t,e){return b.call(t,this,e)}:function(t){return b.call(t,this)})}f&&a(RegExp.prototype[p],"sham",!0)}},d81d:function(t,e,n){"use strict";var i=n("23e7"),r=n("b727").map,o=n("1dde"),s=n("ae40"),a=o("map"),c=s("map");i({target:"Array",proto:!0,forced:!a||!c},{map:function(t){return r(this,t,arguments.length>1?arguments[1]:void 0)}})},da84:function(t,e,n){(function(e){var n=function(t){return t&&t.Math==Math&&t};t.exports=n("object"==typeof globalThis&&globalThis)||n("object"==typeof window&&window)||n("object"==typeof self&&self)||n("object"==typeof e&&e)||function(){return this}()||Function("return this")()}).call(this,n("c8ba"))},dbb4:function(t,e,n){var i=n("23e7"),r=n("83ab"),o=n("56ef"),s=n("fc6a"),a=n("06cf"),c=n("8418");i({target:"Object",stat:!0,sham:!r},{getOwnPropertyDescriptors:function(t){var e,n,i=s(t),r=a.f,u=o(i),l={},f=0;while(u.length>f)n=r(i,e=u[f++]),void 0!==n&&c(l,e,n);return l}})},ddb0:function(t,e,n){var i=n("da84"),r=n("fdbc"),o=n("e260"),s=n("9112"),a=n("b622"),c=a("iterator"),u=a("toStringTag"),l=o.values;for(var f in r){var h=i[f],d=h&&h.prototype;if(d){if(d[c]!==l)try{s(d,c,l)}catch(g){d[c]=l}if(d[u]||s(d,u,f),r[f])for(var p in o)if(d[p]!==o[p])try{s(d,p,o[p])}catch(g){d[p]=o[p]}}}},df75:function(t,e,n){var i=n("ca84"),r=n("7839");t.exports=Object.keys||function(t){return i(t,r)}},e01a:function(t,e,n){"use strict";var i=n("23e7"),r=n("83ab"),o=n("da84"),s=n("5135"),a=n("861d"),c=n("9bf2").f,u=n("e893"),l=o.Symbol;if(r&&"function"==typeof l&&(!("description"in l.prototype)||void 0!==l().description)){var f={},h=function(){var t=arguments.length<1||void 0===arguments[0]?void 0:String(arguments[0]),e=this instanceof h?new l(t):void 0===t?l():l(t);return""===t&&(f[e]=!0),e};u(h,l);var d=h.prototype=l.prototype;d.constructor=h;var p=d.toString,g="Symbol(test)"==String(l("test")),v=/^Symbol\((.*)\)[^)]+$/;c(d,"description",{configurable:!0,get:function(){var t=a(this)?this.valueOf():this,e=p.call(t);if(s(f,t))return"";var n=g?e.slice(7,-1):e.replace(v,"$1");return""===n?void 0:n}}),i({global:!0,forced:!0},{Symbol:h})}},e163:function(t,e,n){var i=n("5135"),r=n("7b0b"),o=n("f772"),s=n("e177"),a=o("IE_PROTO"),c=Object.prototype;t.exports=s?Object.getPrototypeOf:function(t){return t=r(t),i(t,a)?t[a]:"function"==typeof t.constructor&&t instanceof t.constructor?t.constructor.prototype:t instanceof Object?c:null}},e177:function(t,e,n){var i=n("d039");t.exports=!i((function(){function t(){}return t.prototype.constructor=null,Object.getPrototypeOf(new t)!==t.prototype}))},e260:function(t,e,n){"use strict";var i=n("fc6a"),r=n("44d2"),o=n("3f8c"),s=n("69f3"),a=n("7dd0"),c="Array Iterator",u=s.set,l=s.getterFor(c);t.exports=a(Array,"Array",(function(t,e){u(this,{type:c,target:i(t),index:0,kind:e})}),(function(){var t=l(this),e=t.target,n=t.kind,i=t.index++;return!e||i>=e.length?(t.target=void 0,{value:void 0,done:!0}):"keys"==n?{value:i,done:!1}:"values"==n?{value:e[i],done:!1}:{value:[i,e[i]],done:!1}}),"values"),o.Arguments=o.Array,r("keys"),r("values"),r("entries")},e2cc:function(t,e,n){var i=n("6eeb");t.exports=function(t,e,n){for(var r in e)i(t,r,e[r],n);return t}},e3c4:function(t,e,n){var i=n("0cdd");"string"===typeof i&&(i=[[t.i,i,""]]),i.locals&&(t.exports=i.locals);var r=n("499e").default;r("f8a77fb0",i,!0,{sourceMap:!1,shadowMode:!1})},e439:function(t,e,n){var i=n("23e7"),r=n("d039"),o=n("fc6a"),s=n("06cf").f,a=n("83ab"),c=r((function(){s(1)})),u=!a||c;i({target:"Object",stat:!0,forced:u,sham:!a},{getOwnPropertyDescriptor:function(t,e){return s(o(t),e)}})},e538:function(t,e,n){var i=n("b622");e.f=i},e667:function(t,e){t.exports=function(t){try{return{error:!1,value:t()}}catch(e){return{error:!0,value:e}}}},e671:function(t,e,n){"use strict";n("402f")},e6cf:function(t,e,n){"use strict";var i,r,o,s,a=n("23e7"),c=n("c430"),u=n("da84"),l=n("d066"),f=n("fea9"),h=n("6eeb"),d=n("e2cc"),p=n("d44e"),g=n("2626"),v=n("861d"),m=n("1c0b"),y=n("19aa"),x=n("8925"),b=n("2266"),w=n("1c7e"),S=n("4840"),T=n("2cf4").set,z=n("b575"),k=n("cdf9"),C=n("44de"),E=n("f069"),O=n("e667"),D=n("69f3"),I=n("94ca"),_=n("b622"),j=n("605d"),$=n("2d00"),F=_("species"),P="Promise",R=D.get,N=D.set,M=D.getterFor(P),L=f,A=u.TypeError,B=u.document,G=u.process,W=l("fetch"),Y=E.f,U=Y,X=!!(B&&B.createEvent&&u.dispatchEvent),H="function"==typeof PromiseRejectionEvent,V="unhandledrejection",q="rejectionhandled",K=0,J=1,Z=2,Q=1,tt=2,et=I(P,(function(){var t=x(L)!==String(L);if(!t){if(66===$)return!0;if(!j&&!H)return!0}if(c&&!L.prototype["finally"])return!0;if($>=51&&/native code/.test(L))return!1;var e=L.resolve(1),n=function(t){t((function(){}),(function(){}))},i=e.constructor={};return i[F]=n,!(e.then((function(){}))instanceof n)})),nt=et||!w((function(t){L.all(t)["catch"]((function(){}))})),it=function(t){var e;return!(!v(t)||"function"!=typeof(e=t.then))&&e},rt=function(t,e){if(!t.notified){t.notified=!0;var n=t.reactions;z((function(){var i=t.value,r=t.state==J,o=0;while(n.length>o){var s,a,c,u=n[o++],l=r?u.ok:u.fail,f=u.resolve,h=u.reject,d=u.domain;try{l?(r||(t.rejection===tt&&ct(t),t.rejection=Q),!0===l?s=i:(d&&d.enter(),s=l(i),d&&(d.exit(),c=!0)),s===u.promise?h(A("Promise-chain cycle")):(a=it(s))?a.call(s,f,h):f(s)):h(i)}catch(p){d&&!c&&d.exit(),h(p)}}t.reactions=[],t.notified=!1,e&&!t.rejection&&st(t)}))}},ot=function(t,e,n){var i,r;X?(i=B.createEvent("Event"),i.promise=e,i.reason=n,i.initEvent(t,!1,!0),u.dispatchEvent(i)):i={promise:e,reason:n},!H&&(r=u["on"+t])?r(i):t===V&&C("Unhandled promise rejection",n)},st=function(t){T.call(u,(function(){var e,n=t.facade,i=t.value,r=at(t);if(r&&(e=O((function(){j?G.emit("unhandledRejection",i,n):ot(V,n,i)})),t.rejection=j||at(t)?tt:Q,e.error))throw e.value}))},at=function(t){return t.rejection!==Q&&!t.parent},ct=function(t){T.call(u,(function(){var e=t.facade;j?G.emit("rejectionHandled",e):ot(q,e,t.value)}))},ut=function(t,e,n){return function(i){t(e,i,n)}},lt=function(t,e,n){t.done||(t.done=!0,n&&(t=n),t.value=e,t.state=Z,rt(t,!0))},ft=function(t,e,n){if(!t.done){t.done=!0,n&&(t=n);try{if(t.facade===e)throw A("Promise can't be resolved itself");var i=it(e);i?z((function(){var n={done:!1};try{i.call(e,ut(ft,n,t),ut(lt,n,t))}catch(r){lt(n,r,t)}})):(t.value=e,t.state=J,rt(t,!1))}catch(r){lt({done:!1},r,t)}}};et&&(L=function(t){y(this,L,P),m(t),i.call(this);var e=R(this);try{t(ut(ft,e),ut(lt,e))}catch(n){lt(e,n)}},i=function(t){N(this,{type:P,done:!1,notified:!1,parent:!1,reactions:[],rejection:!1,state:K,value:void 0})},i.prototype=d(L.prototype,{then:function(t,e){var n=M(this),i=Y(S(this,L));return i.ok="function"!=typeof t||t,i.fail="function"==typeof e&&e,i.domain=j?G.domain:void 0,n.parent=!0,n.reactions.push(i),n.state!=K&&rt(n,!1),i.promise},catch:function(t){return this.then(void 0,t)}}),r=function(){var t=new i,e=R(t);this.promise=t,this.resolve=ut(ft,e),this.reject=ut(lt,e)},E.f=Y=function(t){return t===L||t===o?new r(t):U(t)},c||"function"!=typeof f||(s=f.prototype.then,h(f.prototype,"then",(function(t,e){var n=this;return new L((function(t,e){s.call(n,t,e)})).then(t,e)}),{unsafe:!0}),"function"==typeof W&&a({global:!0,enumerable:!0,forced:!0},{fetch:function(t){return k(L,W.apply(u,arguments))}}))),a({global:!0,wrap:!0,forced:et},{Promise:L}),p(L,P,!1,!0),g(P),o=l(P),a({target:P,stat:!0,forced:et},{reject:function(t){var e=Y(this);return e.reject.call(void 0,t),e.promise}}),a({target:P,stat:!0,forced:c||et},{resolve:function(t){return k(c&&this===o?L:this,t)}}),a({target:P,stat:!0,forced:nt},{all:function(t){var e=this,n=Y(e),i=n.resolve,r=n.reject,o=O((function(){var n=m(e.resolve),o=[],s=0,a=1;b(t,(function(t){var c=s++,u=!1;o.push(void 0),a++,n.call(e,t).then((function(t){u||(u=!0,o[c]=t,--a||i(o))}),r)})),--a||i(o)}));return o.error&&r(o.value),n.promise},race:function(t){var e=this,n=Y(e),i=n.reject,r=O((function(){var r=m(e.resolve);b(t,(function(t){r.call(e,t).then(n.resolve,i)}))}));return r.error&&i(r.value),n.promise}})},e893:function(t,e,n){var i=n("5135"),r=n("56ef"),o=n("06cf"),s=n("9bf2");t.exports=function(t,e){for(var n=r(e),a=s.f,c=o.f,u=0;u<n.length;u++){var l=n[u];i(t,l)||a(t,l,c(e,l))}}},e8b5:function(t,e,n){var i=n("c6b6");t.exports=Array.isArray||function(t){return"Array"==i(t)}},e95a:function(t,e,n){var i=n("b622"),r=n("3f8c"),o=i("iterator"),s=Array.prototype;t.exports=function(t){return void 0!==t&&(r.Array===t||s[o]===t)}},f069:function(t,e,n){"use strict";var i=n("1c0b"),r=function(t){var e,n;this.promise=new t((function(t,i){if(void 0!==e||void 0!==n)throw TypeError("Bad Promise constructor");e=t,n=i})),this.resolve=i(e),this.reject=i(n)};t.exports.f=function(t){return new r(t)}},f5df:function(t,e,n){var i=n("00ee"),r=n("c6b6"),o=n("b622"),s=o("toStringTag"),a="Arguments"==r(function(){return arguments}()),c=function(t,e){try{return t[e]}catch(n){}};t.exports=i?r:function(t){var e,n,i;return void 0===t?"Undefined":null===t?"Null":"string"==typeof(n=c(e=Object(t),s))?n:a?r(e):"Object"==(i=r(e))&&"function"==typeof e.callee?"Arguments":i}},f772:function(t,e,n){var i=n("5692"),r=n("90e3"),o=i("keys");t.exports=function(t){return o[t]||(o[t]=r(t))}},f83b:function(t,e,n){"use strict";n("a53f")},fae3:function(t,e,n){"use strict";n.r(e),n.d(e,"FluxButton",(function(){return d})),n.d(e,"FluxCube",(function(){return L})),n.d(e,"FluxGrid",(function(){return U})),n.d(e,"FluxImage",(function(){return $})),n.d(e,"FluxParallax",(function(){return J})),n.d(e,"FluxTransition",(function(){return Dn})),n.d(e,"FluxVortex",(function(){return pe})),n.d(e,"FluxWrapper",(function(){return bt})),n.d(e,"VueFlux",(function(){return Kn})),n.d(e,"FluxCaption",(function(){return ii})),n.d(e,"FluxControls",(function(){return ui})),n.d(e,"FluxIndex",(function(){return gi})),n.d(e,"FluxPagination",(function(){return wi})),n.d(e,"FluxPreloader",(function(){return Ei})),n.d(e,"BaseComplement",(function(){return Qn})),n.d(e,"BaseComponent",(function(){return D})),n.d(e,"BaseTransition",(function(){return nt}));var i={};if(n.r(i),n.d(i,"TransitionFade",(function(){return st})),n.d(i,"TransitionKenburn",(function(){return ht})),n.d(i,"TransitionSwipe",(function(){return zt})),n.d(i,"TransitionSlide",(function(){return It})),n.d(i,"TransitionWaterfall",(function(){return Rt})),n.d(i,"TransitionZip",(function(){return Gt})),n.d(i,"TransitionBlinds2d",(function(){return Vt})),n.d(i,"TransitionBlocks1",(function(){return te})),n.d(i,"TransitionBlocks2",(function(){return se})),n.d(i,"TransitionConcentric",(function(){return ye})),n.d(i,"TransitionWarp",(function(){return ze})),n.d(i,"TransitionCamera",(function(){return Ie})),n.d(i,"TransitionCube",(function(){return Re})),n.d(i,"TransitionBook",(function(){return Ge})),n.d(i,"TransitionFall",(function(){return Ve})),n.d(i,"TransitionWave",(function(){return tn})),n.d(i,"TransitionBlinds3d",(function(){return an})),n.d(i,"TransitionRound1",(function(){return dn})),n.d(i,"TransitionRound2",(function(){return xn})),n.d(i,"TransitionExplode",(function(){return kn})),"undefined"!==typeof window){var r=window.document.currentScript,o=n("8875");r=o(),"currentScript"in document||Object.defineProperty(document,"currentScript",{get:o});var s=r&&r.src.match(/(.+\/)[^/]+\.js(\?.*)?$/);s&&(n.p=s[1])}var a=function(){var t=this,e=t.$createElement,n=t._self._c||e;return n("button",{staticClass:"flux-button",staticStyle:{outline:"0"},attrs:{type:"button"},on:{click:function(e){return t.$emit("click")}}},[n("svg",{attrs:{viewBox:"0 0 100 100",xmlns:"http://www.w3.org/2000/svg",version:"1.1"}},[n("circle",{attrs:{cx:"50",cy:"50",r:"49"}}),n("svg",{attrs:{viewBox:"-20 -20 140 140"}},[t._t("default")],2)])])},c=[],u={name:"FluxButton"},l=u;n("8ca2");function f(t,e,n,i,r,o,s,a){var c,u="function"===typeof t?t.options:t;if(e&&(u.render=e,u.staticRenderFns=n,u._compiled=!0),i&&(u.functional=!0),o&&(u._scopeId="data-v-"+o),s?(c=function(t){t=t||this.$vnode&&this.$vnode.ssrContext||this.parent&&this.parent.$vnode&&this.parent.$vnode.ssrContext,t||"undefined"===typeof __VUE_SSR_CONTEXT__||(t=__VUE_SSR_CONTEXT__),r&&r.call(this,t),t&&t._registeredComponents&&t._registeredComponents.add(s)},u._ssrRegister=c):r&&(c=a?function(){r.call(this,(u.functional?this.parent:this).$root.$options.shadowRoot)}:r),c)if(u.functional){u._injectStyles=c;var l=u.render;u.render=function(t,e){return c.call(e),l(t,e)}}else{var f=u.beforeCreate;u.beforeCreate=f?[].concat(f,c):[c]}return{exports:t,options:u}}var h=f(l,a,c,!1,null,null,null),d=h.exports,p=function(){var t=this,e=t.$createElement,n=t._self._c||e;return n("div",{ref:"cube",style:t.style},t._l(t.sides,(function(t){return n("flux-image",{key:t.name,ref:t.name,refInFor:!0,style:t.style,attrs:{size:t.size,"view-size":t.viewSize,image:t.img,color:t.color,offset:t.offset}})})),1)},g=[];n("99af"),n("4de4"),n("caad"),n("a9e3"),n("a4d3"),n("4160"),n("e439"),n("dbb4"),n("b64b"),n("159b");function v(t,e,n){return e in t?Object.defineProperty(t,e,{value:n,enumerable:!0,configurable:!0,writable:!0}):t[e]=n,t}function m(t,e){var n=Object.keys(t);if(Object.getOwnPropertySymbols){var i=Object.getOwnPropertySymbols(t);e&&(i=i.filter((function(e){return Object.getOwnPropertyDescriptor(t,e).enumerable}))),n.push.apply(n,i)}return n}function y(t){for(var e=1;e<arguments.length;e++){var n=null!=arguments[e]?arguments[e]:{};e%2?m(Object(n),!0).forEach((function(e){v(t,e,n[e])})):Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):m(Object(n)).forEach((function(e){Object.defineProperty(t,e,Object.getOwnPropertyDescriptor(n,e))}))}return t}n("e01a"),n("d28b"),n("e260"),n("d3b7"),n("3ca3"),n("ddb0"),n("a630"),n("fb6a"),n("b0c0"),n("25f0");function x(t,e){(null==e||e>t.length)&&(e=t.length);for(var n=0,i=new Array(e);n<e;n++)i[n]=t[n];return i}function b(t,e){if(t){if("string"===typeof t)return x(t,e);var n=Object.prototype.toString.call(t).slice(8,-1);return"Object"===n&&t.constructor&&(n=t.constructor.name),"Map"===n||"Set"===n?Array.from(t):"Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)?x(t,e):void 0}}function w(t,e){var n;if("undefined"===typeof Symbol||null==t[Symbol.iterator]){if(Array.isArray(t)||(n=b(t))||e&&t&&"number"===typeof t.length){n&&(t=n);var i=0,r=function(){};return{s:r,n:function(){return i>=t.length?{done:!0}:{done:!1,value:t[i++]}},e:function(t){throw t},f:r}}throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}var o,s=!0,a=!1;return{s:function(){n=t[Symbol.iterator]()},n:function(){var t=n.next();return s=t.done,t},e:function(t){a=!0,o=t},f:function(){try{s||null==n["return"]||n["return"]()}finally{if(a)throw o}}}}var S=function(){var t=this,e=t.$createElement,n=t._self._c||e;return n("div",{staticClass:"flux-image",style:t.style})},T=[];function z(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}function k(t,e){for(var n=0;n<e.length;n++){var i=e[n];i.enumerable=i.enumerable||!1,i.configurable=!0,"value"in i&&(i.writable=!0),Object.defineProperty(t,i.key,i)}}function C(t,e,n){return e&&k(t.prototype,e),n&&k(t,n),t}var E=function(){function t(e){z(this,t),this.node=e}return C(t,[{key:"getWidth",value:function(){var t=getComputedStyle(this.node).width;return parseFloat(t)}},{key:"getHeight",value:function(){var t=getComputedStyle(this.node).height;return parseFloat(t)}},{key:"size",get:function(){return{width:this.getWidth(),height:this.getHeight()}}}],[{key:"sizeFrom",value:function(e){return new t(e).size}}]),t}(),O=(n("e6cf"),function(){function t(e,n){z(this,t),v(this,"status",void 0),v(this,"initIndex",void 0),v(this,"index",void 0),v(this,"aspectRatio",void 0),v(this,"size",void 0),this.src=e,this.initIndex=n}return C(t,[{key:"load",value:function(){var t=this;return new Promise((function(e,n){if(t.status)return"loaded"===t.status?e():n("Image ".concat(t.src," could not be loaded"));var i=new Image;i.onload=function(){t.size={width:i.naturalWidth||i.width,height:i.naturalHeight||i.height},t.aspectRatio=t.size.width/t.size.height,t.status="loaded",e()},i.onerror=function(){t.status="error",n("Image ".concat(t.src," could not be loaded"))},i.src=t.src}))}},{key:"getCoverProps",value:function(t){if(t&&"loaded"===this.status){var e={size:t,aspectRatio:t.width/t.height},n={size:this.getCoverSize(e)};return n.position=this.getCoverPosition(e,n.size),n}}},{key:"getCoverSize",value:function(t){return this.aspectRatio<=t.aspectRatio?{width:t.size.width,height:t.size.width/this.aspectRatio}:{width:this.aspectRatio*t.size.height,height:t.size.height}}},{key:"getCoverPosition",value:function(t,e){return this.aspectRatio<=t.aspectRatio?{top:(t.size.height-e.height)/2,left:0}:{top:0,left:(t.size.width-e.width)/2}}}]),t}()),D={props:{color:String,colors:{type:Object,default:function(){return{}}},image:[String,Object],images:Object,size:{type:Object},viewSize:{type:Object,default:function(){return{}}},offset:Object,offsets:{type:Object,default:function(){return{}}},css:Object},data:function(){return{img:void 0,imgs:void 0,baseStyle:{}}},computed:{domSize:function(){return E.sizeFrom(this.$el)},sizeStyle:function(){if(!this.size)return{};var t=this.size,e=this.viewSize,n=e.width,i=void 0===n?t.width:n,r=e.height,o=void 0===r?t.height:r;return{width:i+"px",height:o+"px"}},style:function(){return y(y(y(y(y({},this.sizeStyle),this.colorStyle),this.imageStyle),this.css),this.baseStyle)}},watch:{image:function(){this.initImg()},images:function(){this.initImgs()}},created:function(){this.initImg(),this.initImgs()},methods:{initImg:function(){return this.image?this.image.src?this.img=this.image:(this.img=new O(this.image),void this.img.load()):this.img=void 0},initImgs:function(){if(!this.images)return this.imgs=void 0;var t,e={};for(var n in this.images)t=this.images[n],t.src||(t=new O(t),t.load()),e[n]=t;this.imgs=e},setCss:function(t){this.baseStyle=y(y({},this.baseStyle),t)},transform:function(t){this.$el.clientHeight,this.setCss(t)},show:function(){this.setCss({visibility:"visible"})},hide:function(){this.setCss({visibility:"hidden"})}}},I={name:"FluxImage",mixins:[D],data:function(){return{baseStyle:{overflow:"hidden"}}},computed:{colorStyle:function(){return this.color?{backgroundColor:this.color}:{}},imageStyle:function(){var t=this.img;if(!t||"loaded"!==t.status)return{};var e=t.getCoverProps(this.size||this.domSize),n=e.size,i=e.position;if(this.offset)for(var r=0,o=["top","left"];r<o.length;r++){var s=o[r];i[s]-=this.offset[s]||0}return{backgroundImage:"url(".concat(this.img.src,")"),backgroundSize:"".concat(n.width,"px ").concat(n.height,"px"),backgroundPosition:"".concat(i.left,"px ").concat(i.top,"px"),backgroundRepeat:"no-repeat"}}}},_=I,j=f(_,S,T,!1,null,null,null),$=j.exports,F={x:{top:"90",bottom:"-90"},y:{back:"180",backr:"180",backl:"-180",left:"-90",right:"90"}},P={x:{left:"-50",right:"50"},y:{top:"-50",bottom:"50"}},R={name:"FluxCube",components:{FluxImage:$},mixins:[D],props:{depth:{type:Number,default:0},sidesCss:{type:Object,default:function(){return{}}}},data:function(){return{sideNames:["front","back","top","bottom","left","right"],baseStyle:{transformStyle:"preserve-3d"}}},computed:{sides:function(){var t,e,n={},i=w(this.definedSides);try{for(i.s();!(e=i.n()).done;){var r=e.value;t={name:r,img:this.imgs[r],color:this.colors[r]||this.color,offset:this.offsets[r]||this.offset},t.size=y({},this.size),t.viewSize=y({},this.viewSize),["left","right"].includes(r)&&(t.viewSize.width=this.depth,t.size.width=this.depth),["top","bottom"].includes(r)&&(t.viewSize.height=this.depth,t.size.height=this.depth),t.style=y(y({},this.sidesCss[r]),{},{position:"absolute",transform:this.getTransform(r),backfaceVisibility:"hidden"}),n[r]=t}}catch(o){i.e(o)}finally{i.f()}return n},definedSides:function(){var t=this;return this.sideNames.filter((function(e){return t.sideDefined(e)}))},translateZ:function(){var t=this.size,e=t.width,n=t.height,i=this.viewSize,r=i.width,o=i.height,s=this.depth,a=s/2;return{top:a,bottom:o?o-a:n-a,left:a,right:r?r-a:e-a,back:s}}},methods:{sideDefined:function(t){return!(!this.images[t]&&!this.colors[t])},getSide:function(t){return this.$refs[t]},getTransform:function(t){var e=F.x[t]||0,n=F.y[t]||0,i=P.x[t]||0,r=P.y[t]||0,o=this.translateZ[t]||0;return"rotateX(".concat(e,"deg) rotateY(").concat(n,"deg) translate3d(").concat(i,"%, ").concat(r,"%, ").concat(o,"px)")},turn:function(t){this.transform({transform:this.getTransform(t)})},turnTop:function(){this.turn("top")},turnBack:function(){this.turn("back")},turnBottom:function(){this.turn("bottom")},turnLeft:function(){this.turn("left")},turnRight:function(){this.turn("right")}}},N=R,M=f(N,p,g,!1,null,null,null),L=M.exports,A=function(){var t=this,e=t.$createElement,n=t._self._c||e;return n("div",{ref:"grid",style:t.style},t._l(t.tiles,(function(e,i){return n(t.component,{key:i,ref:"tiles",refInFor:!0,tag:"component",attrs:{size:t.size,"view-size":e.viewSize,color:t.color,colors:t.colors,image:t.img,images:t.imgs,offset:e.offset,depth:t.depth,css:e.css,"sides-css":e.sidesCss}})})),1)},B=[],G={name:"FluxGrid",components:{FluxCube:L,FluxImage:$},mixins:[D],props:{rows:{type:Number,default:1},cols:{type:Number,default:1},depth:{type:Number,default:0},tileCss:Object},data:function(){return{baseStyle:{position:"relative"}}},computed:{component:function(){return this.images?"FluxCube":"FluxImage"},numRows:function(){return Math.ceil(parseFloat(this.rows))},numCols:function(){return Math.ceil(parseFloat(this.cols))},numTiles:function(){return this.numRows*this.numCols},tileSize:function(){return{width:Math.floor(this.size.width/this.numCols),height:Math.floor(this.size.height/this.numRows)}},tiles:function(){for(var t,e=[],n=0;n<this.numTiles;n++){t={row:this.getRowNumber(n),col:this.getColNumber(n)};var i=this.tileSize,r=i.width,o=i.height;t.row+1===this.numRows&&(o=this.size.height-t.row*o),t.col+1===this.numCols&&(r=this.size.width-t.col*r),t.viewSize={width:r,height:o},t.offset={top:t.row*this.tileSize.height,left:t.col*this.tileSize.width},t.css=y(y({},this.tileCss),{},{position:"absolute",left:t.offset.left+"px",top:t.offset.top+"px",zIndex:n+1<this.numTiles/2?n+1:this.numTiles-n}),e.push(t)}return e}},methods:{getRowNumber:function(t){return Math.floor(t/this.numCols)},getColNumber:function(t){return t%this.numCols},transform:function(t){this.$refs.tiles.forEach((function(e,n){return t(e,n)}))}}},W=G,Y=f(W,A,B,!1,null,null,null),U=Y.exports,X=function(){var t=this,e=t.$createElement,n=t._self._c||e;return n("div",{ref:"parallax",style:t.style},["fixed"!==t.type||t.ios?t._e():n("div",{style:t.fixedParentStyle},[n("div",{staticClass:"image",style:t.fixedChildStyle})]),t._t("default")],2)},H=[],V=(n("b680"),{name:"FluxParallax",props:{src:{type:String,required:!0},holder:{default:function(){return window}},type:{default:"relative"},offset:{type:[Number,String],default:"100%"}},data:function(){return{ios:!1,loaded:!1,view:{width:void 0,height:void 0},parallax:{top:void 0,width:void 0,height:void 0},background:{top:void 0,left:void 0,width:void 0,height:void 0},image:{src:void 0,width:void 0,height:void 0},style:{position:"relative"},fixedParentStyle:{position:"absolute",top:0,left:0,bottom:0,right:0,clip:"rect(auto auto auto auto)"}}},computed:{parallaxSize:function(){return{width:this.$refs.parallax.clientWidth,height:this.$refs.parallax.clientHeight}},offsetHeight:function(){var t;return/^[0-9]+px$/.test(this.offset)?t={px:parseFloat(this.offset),pct:100*t.px/this.background.height}:/^[0-9]+%$/.test(this.offset)&&(t={px:Math.ceil(this.parallaxSize.height*parseFloat(this.offset)/100),pct:parseFloat(parseFloat(this.offset))}),t},backgroundHeight:function(){return this.ios?this.view.height:this.parallaxSize.height+this.offsetHeight.px},remainderHeight:function(){return this.background.height-this.backgroundHeight},fixedChildStyle:function(){return{position:"absolute",top:0,bottom:0,left:0,right:0,background:'url("'.concat(this.src,'") no-repeat center center fixed'),backgroundSize:"".concat(this.background.width,"px ").concat(this.background.height,"px")}},handle:function(){return{visible:this.handleVisible,relative:this.handleRelative,fixed:this.handleFixed}}},created:function(){this.ios=(/iPad|iPhone|iPod/.test(navigator.platform)||"MacIntel"===navigator.platform&&navigator.maxTouchPoints>1)&&!window.MSStream,this.setProperties()},mounted:function(){var t=this;this.setCss({background:'url("'.concat(this.src,'") no-repeat')}),window.addEventListener("resize",this.resize,{passive:!0}),("fixed"!==this.type||this.ios)&&setTimeout((function(){t.holder.addEventListener("scroll",t.handleScroll,{passive:!0})}))},beforeDestroy:function(){window.removeEventListener("resize",this.resize),this.holder.removeEventListener("scroll",this.handleScroll)},methods:{setProperties:function(){var t=this,e=new Image;e.onload=function(){t.image=y(y({},t.image),{},{src:e.src,width:e.naturalWidth||e.width,height:e.naturalHeight||e.height}),t.loaded=!0,t.resize()},e.onerror=function(){console.warn("Image ".concat(t.src," could not be loaded"))},e.src=this.src},resize:function(){this.view.width=this.holder.scrollWidth||this.holder.innerWidth,this.view.height=this.holder.scrollHeight||this.holder.innerHeight,this.parallax=y(y(y({},this.parallax),this.parallaxSize),{},{top:this.$refs.parallax.offsetTop});var t=this.image.height/this.image.width,e=this.view.height/this.view.width;t>=e&&!this.ios?(this.background.width=this.view.width,this.background.height=Math.floor(this.view.width*this.image.height/this.image.width)):(this.background.height=this.view.height,this.background.width=Math.floor(this.background.height*this.image.width/this.image.height)),this.setCss({backgroundSize:"".concat(this.background.width,"px ").concat(this.background.height,"px"),backgroundPosition:"center 0"}),this.handleScroll()},setCss:function(t){this.style=y(y({},this.style),t)},moveBackgroundByPct:function(t){this.remainderHeight>0&&(t=t*this.offsetHeight.pct/100+50-this.offsetHeight.pct/2),this.setCss({backgroundPositionY:t.toFixed(2)+"%"})},handleScroll:function(){if(!1!==this.loaded&&(this.ios||"fixed"!==this.type)){var t=this.holder.scrollY||this.holder.scrollTop||this.holder.pageYOffset||0;if(this.holder!==window)return this.handleRelative(t);if(!(t+this.view.height<this.parallax.top)&&!(t>this.parallax.top+this.parallax.height)){var e=t-this.parallax.top+this.view.height;this.handle[this.type](e)}}},handleVisible:function(t){var e=0;e=t<this.parallax.height?0:t>this.view.height?100:100*(t-this.parallax.height)/(this.view.height-this.parallax.height),this.moveBackgroundByPct(e)},handleRelative:function(t){var e;e=this.holder===window?100*t/(this.view.height+this.parallax.height):100*t/(this.view.height-this.holder.clientHeight),this.moveBackgroundByPct(e)},handleFixed:function(t){this.setCss({backgroundPositionY:t-this.view.height+"px"})}}}),q=V,K=(n("281b"),f(q,X,H,!1,null,null,null)),J=K.exports,Z=function(){var t=this,e=t.$createElement,n=t._self._c||e;return n("div",{ref:"mask",staticClass:"flux-transition",style:t.style},[t.componentName?n(t.componentName,{ref:"transition",tag:"component",attrs:{size:t.size,from:t.from,to:t.to,current:t.current,options:t.options,images:t.images}}):t._e()],1)},Q=[],tt=function(){var t=this,e=t.$createElement,n=t._self._c||e;return n("flux-image",{ref:"from",attrs:{image:t.from,size:t.size,css:t.imageCss}})},et=[],nt=(n("cca6"),{data:function(){return{totalDuration:1}},props:{size:Object,from:{type:[String,Object],required:!0},to:[String,Object],current:Object,options:{type:Object,default:function(){return{}}}},computed:{mask:function(){return this.$parent.baseStyle}},created:function(){Object.assign(this,{direction:"next"},this.options);var t=this.direction,e={prev:this.setupPrev,next:this.setupNext};e[t]&&e[t]()},played:function(){var t=this.direction,e={prev:this.playPrev,next:this.playNext};e[t]&&e[t]()},methods:{getDelay:function(t){var e=this.direction,n={prev:this.getDelayPrev,next:this.getDelayNext};return n[e](t)},getReadyness:function(){var t=80,e=function t(e){var n,i=e.$children.length,r=w(e.$children);try{for(r.s();!(n=r.n()).done;){var o=n.value;i+=t(o)}}catch(s){r.e(s)}finally{r.f()}return i},n=3*e(this);return n<t?t:n}}}),it={name:"TransitionFade",components:{FluxImage:$},mixins:[nt],data:function(){return{totalDuration:1200,easing:"ease-in",imageCss:{zIndex:1}}},played:function(){this.$refs.from.transform({transition:"opacity ".concat(this.totalDuration,"ms ").concat(this.easing),opacity:0})}},rt=it,ot=f(rt,tt,et,!1,null,null,null),st=ot.exports,at=function(){var t=this,e=t.$createElement,n=t._self._c||e;return n("flux-image",{ref:"image",attrs:{image:t.from,size:t.size,css:t.css}})},ct=[],ut={name:"TransitionKenburn",components:{FluxImage:$},mixins:[nt],data:function(){return{totalDuration:1500,easing:"linear",transform:{},css:{}}},created:function(){this.transform=this.getTransform(),this.css.transformOrigin=this.transform.originX+" "+this.transform.originY},played:function(){this.$refs.image.transform({transition:"all ".concat(this.totalDuration,"ms ").concat(this.easing),transform:"scale(".concat(this.transform.scale,") translate(").concat(this.transform.translateX,", ").concat(this.transform.translateY,")"),opacity:0})},methods:{getTransform:function(){var t=Math.floor(4*Math.random()+1);return 1===t?{scale:"1.7",translateX:"-35%",translateY:"-35%",originX:"top",originY:"left"}:2===t?{scale:"1.7",translateX:"35%",translateY:"-35%",originX:"top",originY:"right"}:3===t?{scale:"1.7",translateX:"-35%",translateY:"35%",originX:"bottom",originY:"left"}:{scale:"1.7",translateX:"35%",translateY:"35%",originX:"bottom",originY:"right"}}}},lt=ut,ft=f(lt,at,ct,!1,null,null,null),ht=ft.exports,dt=function(){var t=this,e=t.$createElement,n=t._self._c||e;return n("flux-wrapper",{ref:"wrapper",attrs:{size:t.size,css:t.wrapperCss}},[n("flux-image",{ref:"image",attrs:{image:t.from,size:t.size,css:t.imageCss}})],1)},pt=[],gt=function(){var t=this,e=t.$createElement,n=t._self._c||e;return n("div",{ref:"wrapper",style:t.style},[t._t("default")],2)},vt=[],mt={name:"FluxWrapper",mixins:[D],data:function(){return{baseStyle:{overflow:"hidden"}}}},yt=mt,xt=f(yt,gt,vt,!1,null,null,null),bt=xt.exports,wt={name:"TransitionSwipe",components:{FluxWrapper:bt,FluxImage:$},mixins:[nt],data:function(){return{totalDuration:1400,easing:"ease-in-out",wrapperCss:{position:"absolute",top:0,display:"flex",flexWrap:"nowrap"},imageCss:{flex:"0 0 auto"}}},played:function(){this.$refs.wrapper.transform({transition:"width ".concat(this.totalDuration,"ms ").concat(this.easing),width:0})},methods:{setupPrev:function(){this.wrapperCss=y(y({},this.wrapperCss),{},{right:0,justifyContent:"flex-end"})},setupNext:function(){this.wrapperCss=y(y({},this.wrapperCss),{},{left:0,justifyContent:"flex-start"})}}},St=wt,Tt=f(St,dt,pt,!1,null,null,null),zt=Tt.exports,kt=function(){var t=this,e=t.$createElement,n=t._self._c||e;return n("flux-wrapper",{ref:"wrapper",attrs:{size:t.wrapperSize,css:t.wrapperCss}},[n("flux-image",{ref:"left",attrs:{image:t.left,size:t.size}}),n("flux-image",{ref:"right",attrs:{image:t.right,size:t.size}})],1)},Ct=[],Et={name:"TransitionSlide",components:{FluxWrapper:bt,FluxImage:$},mixins:[nt],data:function(){return{totalDuration:1400,easing:"ease-in-out",left:void 0,right:void 0,wrapperSize:{},wrapperCss:{display:"flex",flexWrap:"nowrap"}}},computed:{transition:function(){return"transform ".concat(this.totalDuration,"ms ").concat(this.easing)}},created:function(){this.wrapperSize={width:2*this.size.width,height:this.size.height}},methods:{setupPrev:function(){this.left=this.to,this.right=this.from,this.wrapperCss.transform="translateX(-50%)"},setupNext:function(){this.left=this.from,this.right=this.to},playPrev:function(){this.$refs.wrapper.transform({transition:this.transition,transform:"translateX(0)"})},playNext:function(){this.$refs.wrapper.transform({transition:this.transition,transform:"translateX(-50%)"})}}},Ot=Et,Dt=f(Ot,kt,Ct,!1,null,null,null),It=Dt.exports,_t=function(){var t=this,e=t.$createElement,n=t._self._c||e;return n("flux-grid",{ref:"grid",attrs:{rows:t.rows,cols:t.cols,size:t.size,image:t.from}})},jt=[],$t={name:"TransitionWaterfall",components:{FluxGrid:U},mixins:[nt],data:function(){return{rows:1,cols:10,tileDuration:600,totalDuration:0,easing:"cubic-bezier(0.55, 0.055, 0.675, 0.19)",tileDelay:90}},created:function(){this.totalDuration=this.tileDelay*this.cols+this.tileDuration},played:function(){var t=this;this.$refs.grid.transform((function(e,n){e.transform({transition:"all ".concat(t.tileDuration,"ms ").concat(t.easing," ").concat(t.getDelay(n),"ms"),opacity:"0.1",transform:"translateY(100%)"})}))},methods:{getDelayPrev:function(t){return(this.cols-t-1)*this.tileDelay},getDelayNext:function(t){return t*this.tileDelay}}},Ft=$t,Pt=f(Ft,_t,jt,!1,null,null,null),Rt=Pt.exports,Nt=function(){var t=this,e=t.$createElement,n=t._self._c||e;return n("flux-grid",{ref:"grid",attrs:{rows:t.rows,cols:t.cols,size:t.size,image:t.from}})},Mt=[],Lt={name:"TransitionZip",components:{FluxGrid:U},mixins:[nt],data:function(){return{rows:1,cols:10,tileDuration:600,totalDuration:0,easing:"ease-in",tileDelay:80}},created:function(){this.totalDuration=this.tileDelay*this.cols+this.tileDuration},played:function(){var t=this;this.$refs.grid.transform((function(e,n){e.transform({transition:"all ".concat(t.tileDuration,"ms ").concat(t.easing," ").concat(t.getDelay(n),"ms"),opacity:"0.1",transform:"translateY(".concat(n%2?"-":"","100%)")})}))},methods:{getDelayPrev:function(t){return(this.cols-t-1)*this.tileDelay},getDelayNext:function(t){return t*this.tileDelay}}},At=Lt,Bt=f(At,Nt,Mt,!1,null,null,null),Gt=Bt.exports,Wt=function(){var t=this,e=t.$createElement,n=t._self._c||e;return n("flux-grid",{ref:"grid",attrs:{rows:t.rows,cols:t.cols,size:t.size,image:t.from}})},Yt=[],Ut={name:"TransitionBlinds2d",components:{FluxGrid:U},mixins:[nt],data:function(){return{rows:1,cols:10,tileDuration:800,totalDuration:0,easing:"linear",tileDelay:100}},created:function(){this.totalDuration=this.tileDelay*this.cols+this.tileDuration},played:function(){var t=this;this.$refs.grid.transform((function(e,n){e.transform({transition:"all ".concat(t.tileDuration,"ms ").concat(t.easing," ").concat(t.getDelay(n),"ms"),opacity:"0.1",transform:"scaleX(0)"})}))},methods:{getDelayPrev:function(t){return(this.cols-t-1)*this.tileDelay},getDelayNext:function(t){return t*this.tileDelay}}},Xt=Ut,Ht=f(Xt,Wt,Yt,!1,null,null,null),Vt=Ht.exports,qt=function(){var t=this,e=t.$createElement,n=t._self._c||e;return n("flux-grid",{ref:"grid",attrs:{rows:t.rows,cols:t.cols,size:t.size,image:t.from}})},Kt=[],Jt={name:"TransitionBlocks1",components:{FluxGrid:U},mixins:[nt],data:function(){return{rows:8,cols:8,tileDuration:300,totalDuration:0,easing:"linear",tileDelay:1e3}},created:function(){if(!this.options.rows){var t=this.size.width/this.cols;this.rows=Math.floor(this.size.height/t)}this.totalDuration=this.tileDelay+this.tileDuration},played:function(){var t=this;this.$refs.grid.transform((function(e,n){e.transform({transition:"all ".concat(t.tileDuration,"ms ").concat(t.easing," ").concat(t.getDelay(n),"ms"),opacity:"0",transform:"scale(0.3, 0.3)"})}))},methods:{getDelay:function(){var t=Math.random()*this.tileDelay;return Math.floor(t)}}},Zt=Jt,Qt=f(Zt,qt,Kt,!1,null,null,null),te=Qt.exports,ee=function(){var t=this,e=t.$createElement,n=t._self._c||e;return n("div",[n("flux-grid",{ref:"grid",attrs:{rows:t.rows,cols:t.cols,size:t.size,image:t.gridImage,"tile-css":t.tileCss,css:t.gridCss}}),t.backgroundImage?n("flux-image",{ref:"background",attrs:{size:t.size,image:t.backgroundImage,css:t.backgroundCss}}):t._e()],1)},ne=[],ie={name:"TransitionBlocks2",components:{FluxGrid:U,FluxImage:$},mixins:[nt],data:function(){return{rows:8,cols:8,tileDuration:800,totalDuration:0,easing:"ease",tileDelay:80,gridImage:void 0,tileCss:{},gridCss:{position:"absolute",top:0,left:0,zIndex:2},backgroundImage:void 0,backgroundCss:{position:"absolute",top:0,left:0,zIndex:1}}},created:function(){if(!this.options.rows){var t=this.size.width/this.cols;this.rows=Math.floor(this.size.height/t)}this.totalDuration=this.tileDelay*(this.rows+this.cols)+this.tileDuration},methods:{setupPrev:function(){this.gridImage=this.to,this.backgroundImage=this.from,this.tileCss={opacity:0,transform:"scale(0.3)"}},setupNext:function(){this.gridImage=this.from},playPrev:function(){var t=this;this.$refs.grid.transform((function(e,n){e.transform({transition:"all ".concat(t.tileDuration,"ms ").concat(t.easing," ").concat(t.getDelay(n,"prev"),"ms"),opacity:1,transform:"scale(1)"})}))},playNext:function(){var t=this;this.$refs.grid.transform((function(e,n){e.transform({transition:"all ".concat(t.tileDuration,"ms ").concat(t.easing," ").concat(t.getDelay(n,"next"),"ms"),opacity:0,transform:"scale(0.3)"})}))},getDelay:function(t,e){var n=this.$refs.grid.getRowNumber(t),i=this.$refs.grid.getColNumber(t),r=i+n;return"prev"===e&&(r=this.rows+this.cols-r-1),r*this.tileDelay}}},re=ie,oe=f(re,ee,ne,!1,null,null,null),se=oe.exports,ae=function(){var t=this,e=t.$createElement,n=t._self._c||e;return n("flux-vortex",{ref:"vortex",attrs:{size:t.size,circles:t.circles,image:t.from}})},ce=[],ue=function(){var t=this,e=t.$createElement,n=t._self._c||e;return n("div",{ref:"vortex",style:t.style},t._l(t.tiles,(function(e,i){return n("flux-image",{key:i,ref:"tiles",refInFor:!0,attrs:{size:t.size,image:t.img,offset:e.offset,css:e.css}})})),1)},le=[],fe={name:"FluxVortex",components:{FluxImage:$},mixins:[D],props:{circles:{type:Number,default:1},tileCss:Object},data:function(){return{baseStyle:{position:"relative",overflow:"hidden"}}},computed:{numCircles:function(){return Math.round(parseFloat(this.circles))},diag:function(){var t=this.size,e=t.width,n=t.height;return Math.ceil(Math.sqrt(e*e+n*n))},radius:function(){return Math.ceil(this.diag/2/this.numCircles)},topGap:function(){return Math.ceil(this.size.height/2-this.radius*this.numCircles)},leftGap:function(){return Math.ceil(this.size.width/2-this.radius*this.numCircles)},tiles:function(){for(var t,e=[],n=0;n<this.numCircles;n++){var i=(this.numCircles-n)*this.radius*2,r=this.radius*n;t={offset:{top:this.topGap+r,left:this.leftGap+r}},t.css=y(y({},this.tileCss),{},{position:"absolute",left:t.offset.left+"px",top:t.offset.top+"px",width:i+"px",height:i+"px",backgroundRepeat:"repeat",borderRadius:"50%",zIndex:n}),e.push(t)}return e}},methods:{transform:function(t){this.$refs.tiles.forEach((function(e,n){return t(e,n)}))}}},he=fe,de=f(he,ue,le,!1,null,null,null),pe=de.exports,ge={name:"TransitionConcentric",components:{FluxVortex:pe},mixins:[nt],data:function(){return{circles:7,tileDuration:800,totalDuration:0,easing:"linear",tileDelay:150}},created:function(){this.totalDuration=this.tileDelay*this.circles+this.tileDuration},played:function(){var t=this,e="next"===this.direction?"90":"-90";this.$refs.vortex.transform((function(n,i){n.transform({transition:"all ".concat(t.tileDuration,"ms ").concat(t.easing," ").concat(t.getDelay(i),"ms"),opacity:"0",transform:"rotateZ(".concat(e,"deg)")})}))},methods:{getDelay:function(t){return t*this.tileDelay}}},ve=ge,me=f(ve,ae,ce,!1,null,null,null),ye=me.exports,xe=function(){var t=this,e=t.$createElement,n=t._self._c||e;return n("flux-vortex",{ref:"vortex",attrs:{size:t.size,circles:t.circles,image:t.from}})},be=[],we={name:"TransitionWarp",components:{FluxVortex:pe},mixins:[nt],data:function(){return{circles:7,tileDuration:800,totalDuration:0,easing:"linear",tileDelay:150}},created:function(){this.totalDuration=this.tileDelay*this.circles+this.tileDuration},played:function(){var t=this;this.$refs.vortex.transform((function(e,n){e.transform({transition:"all ".concat(t.tileDuration,"ms ").concat(t.easing," ").concat(t.getDelay(n),"ms"),opacity:"0",transform:"rotateZ(".concat(t.getDeg(n),"deg)")})}))},methods:{getDelayPrev:function(t){return(this.circles-t-1)*this.tileDelay},getDelayNext:function(t){return t*this.tileDelay},getDeg:function(t){return t%2===0?"-90":"90"}}},Se=we,Te=f(Se,xe,be,!1,null,null,null),ze=Te.exports,ke=function(){var t=this,e=t.$createElement,n=t._self._c||e;return n("flux-wrapper",{ref:"wrapper",attrs:{size:t.wrapperSize,css:t.wrapperCss}},[n("flux-image",{ref:"image",attrs:{image:t.image,size:t.size,css:t.imageCss}})],1)},Ce=[],Ee={name:"TransitionCamera",components:{FluxWrapper:bt,FluxImage:$},mixins:[nt],data:function(){return{circles:2,totalDuration:900,easing:"cubic-bezier(0.385, 0, 0.795, 0.560)",backgroundColor:"#111",image:void 0,diag:void 0,wrapperSize:{},wrapperCss:{boxSizing:"border-box",position:"absolute",display:"flex",justifyContent:"center",overflow:"hidden",borderRadius:"50%"},imageCss:{alignSelf:"center",flex:"none"}}},created:function(){this.image=this.from;var t=this.size,e=t.width,n=t.height,i=this.diag=Math.ceil(Math.sqrt(e*e+n*n));this.wrapperSize={width:i,height:i},this.wrapperCss=y(y({},this.wrapperCss),{},{border:"0 solid "+this.backgroundColor,top:(n-i)/2+"px",left:(e-i)/2+"px"})},played:function(){var t=this;this.$refs.wrapper.transform({transition:"all ".concat(this.totalDuration/2-50,"ms ").concat(this.easing," 0ms"),borderWidth:this.diag/2+"px"}),setTimeout((function(){t.$refs.image.hide(),t.$refs.wrapper.transform({transition:"all ".concat(t.totalDuration/2-50,"ms ").concat(t.easing," 0ms"),borderWidth:0})}),this.totalDuration/2+50)}},Oe=Ee,De=f(Oe,ke,Ce,!1,null,null,null),Ie=De.exports,_e=function(){var t=this,e=t.$createElement,n=t._self._c||e;return n("flux-cube",{ref:"cube",attrs:{images:t.images,size:t.size,depth:t.size.width,css:t.cubeCss}})},je=[],$e={name:"TransitionCube",components:{FluxCube:L},mixins:[nt],data:function(){return{totalDuration:1400,easing:"ease-out",images:void 0,cubeCss:{}}},created:function(){Object.assign(this.mask,{perspective:"1600px",overflow:"visible"}),this.cubeCss.transition="all ".concat(this.totalDuration,"ms ").concat(this.easing),this.images={front:this.from,left:this.to,right:this.to}},played:function(){this.current&&this.current.hide();var t={next:"left",prev:"right"};this.$refs.cube.turn(t[this.direction])},beforeDestroy:function(){this.current&&this.current.show()}},Fe=$e,Pe=f(Fe,_e,je,!1,null,null,null),Re=Pe.exports,Ne=function(){var t=this,e=t.$createElement,n=t._self._c||e;return n("div",[n("flux-image",{ref:"from",attrs:{image:t.from,size:t.size,"view-size":t.viewSize,offset:t.image.offset,css:t.image.css}}),n("flux-cube",{ref:"cube",attrs:{images:t.cube.images,size:t.size,"view-size":t.viewSize,offsets:t.cube.offsets,"sides-css":t.cube.sidesCss,css:t.cube.css}})],1)},Me=[],Le={name:"TransitionBook",components:{FluxCube:L,FluxImage:$},mixins:[nt],data:function(){return{totalDuration:1200,easing:"ease-out",viewSize:{},image:{offset:{},css:{position:"absolute",top:0,left:0}},cube:{images:{},offsets:{},css:{position:"absolute",top:0,left:0}}}},computed:{halfWidth:function(){return Math.ceil(this.size.width/2)},halfWidthPx:function(){return this.halfWidth+"px"}},created:function(){Object.assign(this.mask,{perspective:"1600px",overflow:"visible"}),this.viewSize={width:Math.ceil(this.size.width/2),height:this.size.height},this.cube.images={front:this.from,back:this.to}},played:function(){this.$refs.cube.transform({transition:"transform ".concat(this.totalDuration,"ms ").concat(this.easing),transform:"rotateY(".concat(this.getDeg(),"deg)")})},methods:{setupPrev:function(){this.image.offset.left=this.halfWidth,this.image.css.left=this.halfWidthPx,this.cube.offsets.back={left:this.halfWidth},this.cube.css=y(y({},this.cube.css),{},{transformOrigin:"right center"})},setupNext:function(){this.cube.offsets.front={left:this.halfWidth},this.cube.css=y(y({},this.cube.css),{},{left:this.halfWidthPx,transformOrigin:"left center"})},getDeg:function(){var t={next:"-180",prev:"180"};return t[this.direction]}}},Ae=Le,Be=f(Ae,Ne,Me,!1,null,null,null),Ge=Be.exports,We=function(){var t=this,e=t.$createElement,n=t._self._c||e;return n("flux-image",{ref:"image",style:t.style,attrs:{image:t.from,size:t.size}})},Ye=[],Ue={name:"TransitionFall",components:{FluxImage:$},mixins:[nt],data:function(){return{totalDuration:1600,easing:"ease-in",style:{transformOrigin:"center bottom"}}},created:function(){Object.assign(this.mask,{perspective:"1600px",overflow:"visible"})},played:function(){this.$refs.image.transform({transition:"transform ".concat(this.totalDuration,"ms ").concat(this.easing),transform:"rotateX(-83deg)"})}},Xe=Ue,He=f(Xe,We,Ye,!1,null,null,null),Ve=He.exports,qe=function(){var t=this,e=t.$createElement,n=t._self._c||e;return n("flux-grid",{ref:"grid",attrs:{rows:t.rows,cols:t.cols,size:t.size,images:t.images,colors:t.colors,depth:t.size.height,css:t.gridCss}})},Ke=[],Je={name:"TransitionWave",components:{FluxGrid:U},mixins:[nt],data:function(){return{rows:1,cols:8,tileDuration:900,totalDuration:0,easing:"cubic-bezier(0.3, -0.3, 0.735, 0.285)",tileDelay:110,sideColor:"#333",gridCss:{overflow:"visible",perspective:"1200px"},images:{},colors:{}}},created:function(){this.mask.overflow="visible",this.totalDuration=this.tileDelay*this.cols+this.tileDuration,this.images={front:this.from,top:this.to}},played:function(){var t=this;this.current&&this.current.hide(),this.colors={left:this.sideColor,right:this.sideColor},this.$refs.grid.transform((function(e,n){e.setCss({transition:"all ".concat(t.tileDuration,"ms ").concat(t.easing," ").concat(t.getDelay(n),"ms")}),e.turnBottom()}))},beforeDestroy:function(){this.current&&this.current.show()},methods:{getDelayPrev:function(t){return(this.cols-t-1)*this.tileDelay},getDelayNext:function(t){return t*this.tileDelay}}},Ze=Je,Qe=f(Ze,qe,Ke,!1,null,null,null),tn=Qe.exports,en=function(){var t=this,e=t.$createElement,n=t._self._c||e;return n("flux-grid",{ref:"grid",attrs:{rows:t.rows,cols:t.cols,size:t.size,images:t.images,css:t.gridCss}})},nn=[],rn={name:"TransitionBlinds3d",components:{FluxGrid:U},mixins:[nt],data:function(){return{rows:1,cols:6,tileDuration:800,totalDuration:0,easing:"ease-out",tileDelay:150,gridCss:{perspective:"800px"},images:void 0}},created:function(){this.mask.overflow="visible",this.totalDuration=this.tileDelay*this.cols+this.tileDuration,this.images={front:this.from,back:this.to}},played:function(){var t=this;this.current&&this.current.hide();var e={prev:"backl",next:"backr"};this.$refs.grid.transform((function(n,i){n.setCss({transition:"all ".concat(t.tileDuration,"ms ").concat(t.easing," ").concat(t.getDelay(i),"ms")}),n.turn(e[t.direction])}))},beforeDestroy:function(){this.current&&this.current.show()},methods:{getDelayPrev:function(t){return(this.cols-t-1)*this.tileDelay},getDelayNext:function(t){return t*this.tileDelay}}},on=rn,sn=f(on,en,nn,!1,null,null,null),an=sn.exports,cn=function(){var t=this,e=t.$createElement,n=t._self._c||e;return n("flux-grid",{ref:"grid",attrs:{rows:t.rows,cols:t.cols,size:t.size,images:t.images,css:t.gridCss}})},un=[],ln={name:"TransitionRound1",components:{FluxGrid:U},mixins:[nt],data:function(){return{rows:8,cols:8,tileDuration:800,totalDuration:0,easing:"ease-out",tileDelay:150,images:void 0,gridCss:{perspective:"800px"}}},created:function(){if(this.mask.overflow="visible",!this.options.rows){var t=this.size.width/this.cols;this.rows=Math.floor(this.size.height/t)}var e=this.rows>this.cols?this.rows:this.cols;this.totalDuration=this.tileDelay*e*2,this.images={front:this.from,back:this.to}},played:function(){var t=this;this.current&&this.current.hide();var e={prev:"backl",next:"backr"};this.$refs.grid.transform((function(n,i){n.setCss({transition:"all ".concat(t.tileDuration,"ms ").concat(t.easing," ").concat(t.getDelay(i),"ms")}),n.turn(e[t.direction])}))},beforeDestroy:function(){this.current&&this.current.show()},methods:{getDelay:function(t){var e=this.$refs.grid,n=e.getRowNumber(t),i=e.getColNumber(t),r=i+n;return"prev"===this.direction&&(r=this.rows+this.cols-r-1),r*this.tileDelay}}},fn=ln,hn=f(fn,cn,un,!1,null,null,null),dn=hn.exports,pn=function(){var t=this,e=t.$createElement,n=t._self._c||e;return n("flux-grid",{ref:"grid",attrs:{rows:t.rows,cols:t.cols,size:t.size,depth:0,image:t.from,css:t.gridCss,"tile-css":t.tileCss}})},gn=[],vn={name:"TransitionRound2",components:{FluxGrid:U},mixins:[nt],data:function(){return{rows:9,cols:9,tileDuration:800,totalDuration:0,rotateX:"-540",easing:"linear",tileDelay:100,gridCss:{perspective:"1200px"},tileCss:{backfaceVisibility:"hidden"}}},created:function(){if(this.mask.overflow="visible",!this.options.rows){var t=this.size.width/this.cols;this.rows=Math.floor(this.size.height/t)}this.totalDuration=(this.cols/2+this.rows)*(2*this.tileDelay)},played:function(){var t=this;this.$refs.grid.transform((function(e,n){e.transform({transition:"all ".concat(t.tileDuration,"ms ").concat(t.easing," ").concat(t.getDelay(n),"ms"),opacity:"0",transform:"rotateY(".concat(t.rotateX,"deg)")})}))},methods:{getDelay:function(t){var e,n,i=this.$refs.grid,r=i.getRowNumber(t),o=i.getColNumber(t);"prev"===this.direction?(e=Math.abs(this.rows/2-.5-r),n=Math.abs(this.cols-o)):(e=Math.abs(this.rows/2-.5-r),n=Math.abs(o));var s=e+n-1;return s*this.tileDelay}}},mn=vn,yn=f(mn,pn,gn,!1,null,null,null),xn=yn.exports,bn=function(){var t=this,e=t.$createElement,n=t._self._c||e;return n("flux-grid",{ref:"grid",attrs:{rows:t.rows,cols:t.cols,size:t.size,image:t.from,css:t.cssGrid}})},wn=[],Sn={name:"TransitionExplode",components:{FluxGrid:U},mixins:[nt],data:function(){return{rows:9,cols:9,tileDuration:300,totalDuration:0,easing:"linear",tileDelay:100,cssGrid:{overflow:"visible"}}},created:function(){if(this.mask.overflow="visible",!this.options.rows){var t=this.size.width/this.cols;this.rows=Math.floor(this.size.height/t)}this.totalDuration=(this.cols/2+this.rows/2)*(2*this.tileDelay)},played:function(){var t=this;this.$refs.grid.transform((function(e,n){e.transform({transition:"all ".concat(t.tileDuration,"ms ").concat(t.easing," ").concat(t.getDelay(n),"ms"),borderRadius:"100%",opacity:"0",transform:"scale(1.6, 1.6)"})}))},methods:{getDelay:function(t){var e=this.$refs.grid,n=e.getRowNumber(t),i=e.getColNumber(t),r=Math.abs(this.rows/2-.5-n),o=Math.abs(this.cols/2-.5-i),s=r+o-1;return s*this.tileDelay}}},Tn=Sn,zn=f(Tn,bn,wn,!1,null,null,null),kn=zn.exports,Cn={name:"FluxTransition",components:y({},i),props:{size:{type:Object,required:!0},transition:{type:[String,Object],required:!0},from:{type:[String,Object],required:!0},to:{type:[String,Object],required:!0},current:Object,options:Object,images:Array},data:function(){return{baseStyle:{overflow:"hidden",perspective:"none",zIndex:3}}},computed:{style:function(){var t=this.size,e=t.width,n=t.height;return y(y({},this.baseStyle),{},{width:e+"px",height:n+"px"})},componentName:function(){if(this.transition.component){if(this.transition.name)return this.transition.name;var t="https://ragnarlotus.github.com/vue-flux-docs/documentation-6/Components/VueFlux";throw new ReferenceError("Transition undefined, check ".concat(t))}var e=this.transition.name||this.transition;if(e="Transition"+e[0].toUpperCase()+e.slice(1),e in i===!1)throw e=this.transition.name||this.transition,new ReferenceError("Transition ".concat(e," does not exist"));return e}},created:function(){this.transition.component&&(this.$options.components[this.componentName]=this.transition.component)},mounted:function(){var t=this;setTimeout((function(){t.$emit("ready")}),this.$refs.transition.getReadyness())},methods:{start:function(){var t=this;this.$refs.transition.$options.played.call(this.$refs.transition),this.$emit("start",{transition:this.transition,from:this.from,to:this.to,options:this.options}),setTimeout((function(){t.end()}),this.getDuration())},end:function(){this.$emit("end",{transition:this.transition,from:this.from,to:this.to,options:this.options})},getDuration:function(){return this.$refs.transition?this.$refs.transition.totalDuration:1}}},En=Cn,On=(n("e671"),f(En,Z,Q,!1,null,null,null)),Dn=On.exports,In=function(){var t=this,e=t.$createElement,n=t._self._c||e;return n("div",{ref:"container",staticClass:"vue-flux",style:t.style,on:{mousemove:function(e){return t.toggleMouseOver(!0)},mouseleave:function(e){return t.toggleMouseOver(!1)},dblclick:function(e){return t.Display.toggleFullScreen()},touchstart:function(e){return t.Touches.start(e)},touchend:function(e){return t.Touches.end(e)}}},[t.Transitions.current?n("flux-transition",{ref:"transition",attrs:{transition:t.Transitions.current,size:t.size,from:t.Transitions.from,to:t.Transitions.to,current:t.$refs.image,options:t.Transitions.current.options,images:t.Images.imgs},on:{ready:function(e){return t.Transitions.ready()},start:function(e){return t.Transitions.start()},end:function(e){return t.Transitions.end()}}}):t._e(),t.Images.current?n("flux-image",{ref:"image",attrs:{size:t.size,image:t.Images.current}}):t._e(),t.size?n("div",{staticClass:"complements"},[t._t("preloader"),t._t("caption"),n("div",{staticClass:"remainder upper"}),t._t("controls"),n("div",{staticClass:"remainder lower"}),t._t("index"),t.loaded?t._t("pagination"):t._e(),t._t("description")],2):t._e()],1)},_n=[];n("ac1f"),n("1276");function jn(t){if(Array.isArray(t))return t}function $n(t,e){if("undefined"!==typeof Symbol&&Symbol.iterator in Object(t)){var n=[],i=!0,r=!1,o=void 0;try{for(var s,a=t[Symbol.iterator]();!(i=(s=a.next()).done);i=!0)if(n.push(s.value),e&&n.length===e)break}catch(c){r=!0,o=c}finally{try{i||null==a["return"]||a["return"]()}finally{if(r)throw o}}return n}}function Fn(){throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}function Pn(t,e){return jn(t)||$n(t,e)||b(t,e)||Fn()}n("96cf");function Rn(t,e,n,i,r,o,s){try{var a=t[o](s),c=a.value}catch(u){return void n(u)}a.done?e(c):Promise.resolve(c).then(i,r)}function Nn(t){return function(){var e=this,n=arguments;return new Promise((function(i,r){var o=t.apply(e,n);function s(t){Rn(o,i,r,s,a,"next",t)}function a(t){Rn(o,i,r,s,a,"throw",t)}s(void 0)}))}}n("7db0");var Mn=function(){function t(e){z(this,t),this.vf=e}return C(t,[{key:"toggleFullScreen",value:function(){this.inFullScreen?this.exitFullScreen():this.enterFullScreen()}},{key:"enterFullScreen",value:function(){var t=Nn(regeneratorRuntime.mark((function t(){var e,n,i;return regeneratorRuntime.wrap((function(t){while(1)switch(t.prev=t.next){case 0:if(e=this.vf,this.vf.config.allowFullscreen){t.next=3;break}return t.abrupt("return");case 3:n=["requestFullscreen","mozRequestFullScreen","webkitRequestFullscreen","msRequestFullscreen"],i=e.$refs.container,n.find((function(t){return t in i&&(i[t]()||!0)})),e.$emit("fullscreen-enter");case 7:case"end":return t.stop()}}),t,this)})));function e(){return t.apply(this,arguments)}return e}()},{key:"exitFullScreen",value:function(){var t=Nn(regeneratorRuntime.mark((function t(){var e,n;return regeneratorRuntime.wrap((function(t){while(1)switch(t.prev=t.next){case 0:e=this.vf,n=["exitFullscreen","mozCancelFullScreen","webkitExitFullscreen","msExitFullscreen"],n.find((function(t){return t in document&&(document[t]()||!0)})),e.$emit("fullscreen-exit");case 4:case"end":return t.stop()}}),t,this)})));function e(){return t.apply(this,arguments)}return e}()},{key:"inFullScreen",get:function(){var t=["fullscreenElement","webkitFullscreenElement","mozFullScreenElement","msFullscreenElement"];return!!document[t.find((function(t){return t in document}))]}}]),t}(),Ln=function(){function t(){z(this,t),this.timers={}}return C(t,[{key:"set",value:function(t,e,n){this.clear(t),this.timers[t]=setTimeout(n,e)}},{key:"clear",value:function(t){var e=this,n=t?[t]:Object.keys(this.timers);n.forEach((function(t){clearTimeout(e.timers[t]),e.timers[t]=void 0}))}}]),t}(),An=(n("d81d"),function(){function t(e){z(this,t),this.vf=e,this.reset(!0)}return C(t,[{key:"reset",value:function(){var t=arguments.length>0&&void 0!==arguments[0]&&arguments[0];t&&(this.last=void 0,this.transitions=[]),this.current=void 0,this.from=void 0,this.to=void 0}},{key:"update",value:function(t){this.reset(!0),this.transitions=t.map((function(t,e){return{index:e,name:t.name||t,options:t.options||{}}})),this.last=this.transitions[this.transitions.length-1],this.vf.$emit("transitions-updated")}},{key:"run",value:function(t,e,n,i){if(this.vf.Timers.clear("transition"),t){var r=t.name||t,o=this.transitions.find((function(t){return t.name===r}));if(!o)throw new ReferenceError("Transition ".concat(t," not found"));t=JSON.parse(JSON.stringify(o))}else t=JSON.parse(JSON.stringify(this.next));t.options.direction||(i||(i=e.index<n.index?"next":"prev"),t.options.direction=i),this.from=e,this.to=n,this.current=t}},{key:"ready",value:function(){this.vf.$refs.transition.start()}},{key:"start",value:function(){this.vf.Images.current=this.to,this.vf.$emit("transition-start",{transition:this.current,from:this.from,to:this.to})}},{key:"end",value:function(){var t=this,e=arguments.length>0&&void 0!==arguments[0]&&arguments[0],n=this.vf;this.last=this.current,this.reset(),n.$nextTick((function(){n.Images.last=n.Images.current,n.config.infinite||0!==n.Images.next.index?(n.config.autoplay&&n.Timers.set("transition",n.config.delay,(function(){n.show()})),n.$emit(e?"transition-cancel":"transition-end",{transition:t.current,from:t.from,to:t.to})):n.stop()}))}},{key:"current",get:function(){return this.$current},set:function(t){this.current&&(this.last=this.current),this.$current=t}},{key:"next",get:function(){var t=this.last.index+1;return t>=this.transitions.length&&(t=0),this.transitions[t]}}]),t}());n("a79d");function Bn(t){if(Array.isArray(t))return x(t)}function Gn(t){if("undefined"!==typeof Symbol&&Symbol.iterator in Object(t))return Array.from(t)}function Wn(){throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}function Yn(t){return Bn(t)||Gn(t)||b(t)||Wn()}var Un=function(){function t(e){z(this,t),v(this,"$current",void 0),v(this,"$last",void 0),this.vf=e,this.reset(!0)}return C(t,[{key:"reset",value:function(){var t=arguments.length>0&&void 0!==arguments[0]&&arguments[0];t&&(this.$last=void 0),this.srcs=[],this.imgs=[],this.loading=[],this.loaded={current:0,success:0,error:0,total:0},this.progress=0,this.toPreload=0,this.toLazyload=0,this.preloading=!1,this.lazyloading=!1,this.$current=void 0}},{key:"update",value:function(t){this.reset(),this.srcs=Yn(t);var e=this.vf.config;this.toPreload=e.lazyLoad?e.lazyLoadAfter:this.srcs.length,this.toPreload>=this.srcs.length?this.toPreload=this.srcs.length:this.toLazyload=this.srcs.length-this.toPreload,this.preloadStart()}},{key:"preloadStart",value:function(){var t=this,e=this.vf,n=this.loaded;this.preloading=!0,e.$emit("images-preload-start");var i=this.toPreload-n.success;this.loading=this.srcs.slice(n.total,n.total+i),this.loaded.current=0,this.loading.forEach((function(e,i){return t.addImg(e,i,n.total)}))}},{key:"preloadEnd",value:function(){var t=this.vf;if(this.addLoadedSuccessfully(),this.loaded.success<this.toPreload&&this.loaded.total<this.toPreload)return this.preloadStart();this.updateIndexes(),this.preloading=!1,t.$emit("images-preload-end"),this.loaded.total<this.srcs.length&&this.lazyLoadStart(),t.init()}},{key:"lazyLoadStart",value:function(){var t=this,e=this.vf,n=this.loaded;this.lazyloading=!0,e.$emit("images-lazy-load-start"),this.loading=this.srcs.slice(n.total),this.loaded.current=0,this.loading.forEach((function(e,i){return t.addImg(e,i,n.total)}))}},{key:"lazyLoadEnd",value:function(){this.addLoadedSuccessfully(),this.updateIndexes(),this.lazyloading=!1,this.vf.$emit("images-lazy-load-end")}},{key:"addImg",value:function(t,e,n){var i=this,r=this.vf.config,o=this.loading[e]=new O(r.path+t,e+n);return o.load().then((function(){i.loadSuccess(o)})).catch((function(t){i.loadError(t)})).finally((function(){i.loaded.current++,i.loaded.total++,i.preloading&&i.updateProgress(),i.loaded.current===i.loading.length&&(i.preloading?i.preloadEnd():i.lazyLoadEnd())}))}},{key:"loadSuccess",value:function(){if(this.loaded.success++,this.preloading&&!this.current){var t,e=w(this.loading);try{for(e.s();!(t=e.n()).done;){var n=t.value;if("error"!==n.status){"loaded"===n.status&&(this.current=n);break}}}catch(i){e.e(i)}finally{e.f()}}}},{key:"loadError",value:function(t){this.loaded.error++,console.warn(t)}},{key:"updateProgress",value:function(){this.progress=Math.ceil(100*this.loaded.success/this.toPreload)||0}},{key:"addLoadedSuccessfully",value:function(){var t,e=this.loading.filter((function(t){return"loaded"===t.status}));(t=this.imgs).push.apply(t,Yn(e)),this.loading=[],this.loaded.current=0}},{key:"updateIndexes",value:function(){this.imgs.forEach((function(t,e){return t.index=e}))}},{key:"getByIndex",value:function(t){if("next"===t)return this.next;if("prev"===t)return this.prev;if(!this.imgs[t])throw new ReferenceError("Image ".concat(t," not found"));return this.imgs[t]}},{key:"prev",get:function(){var t=this.$current.index-1;return t<0&&(t=this.imgs.length-1),this.imgs[t]}},{key:"last",get:function(){return this.$last},set:function(t){this.$last=t}},{key:"current",get:function(){return this.$current},set:function(t){this.$current&&(this.last=this.$current),this.$current=t}},{key:"next",get:function(){var t=this.$current.index+1;return t>=this.imgs.length&&(t=0),this.imgs[t]}}]),t}(),Xn=function(){function t(e){z(this,t),this.vf=e,this.startX=0,this.startY=0,this.startTime=0,this.endTime=0,this.prevTouchTime=0,this.tapThreshold=5,this.doubleTapThreshold=200,this.slideTrigger=.3}return C(t,[{key:"start",value:function(t){this.vf.config.enableGestures&&(this.startTime=Date.now(),this.startX=t.touches[0].clientX,this.startY=t.touches[0].clientY)}},{key:"end",value:function(t){var e=this.vf;this.prevTouchTime=this.endTime,this.endTime=Date.now();var n=t.changedTouches[0].clientX-this.startX,i=t.changedTouches[0].clientY-this.startY;this.tap(n,i)?e.toggleMouseOver(!0):e.config.enableGestures&&(this.slideRight(n)?e.show("prev"):this.slideLeft(n)&&e.show("next"))}},{key:"tap",value:function(t,e){return Math.abs(t)<this.tapThreshold&&Math.abs(e)<this.tapThreshold}},{key:"doubleTap",value:function(){return this.endTime-this.prevTouchTime<this.doubleTapThreshold}},{key:"slideLeft",value:function(t){return t<0&&t<-this.vf.size.width*this.slideTrigger}},{key:"slideRight",value:function(t){return t>0&&t>this.vf.size.width*this.slideTrigger}},{key:"slideUp",value:function(t){return t<0&&t<-this.vf.size.height*this.slideTrigger}},{key:"slideDown",value:function(t){return t>0&&t>this.vf.size.height*this.slideTrigger}}]),t}(),Hn={name:"VueFlux",components:{FluxImage:$,FluxTransition:Dn},props:{options:{type:Object,default:function(){return{}}},transitions:{type:Array,required:!0},images:{type:Array,default:function(){return[]}},captions:{type:Array,default:function(){return[]}}},data:function(){return{config:{allowFullscreen:!1,allowToSkipTransition:!0,aspectRatio:"16:9",autohideTime:2500,autoplay:!1,bindKeys:!1,delay:5e3,enableGestures:!1,infinite:!0,lazyLoad:!0,lazyLoadAfter:3,path:""},size:void 0,loaded:!1,mouseOver:!1,Display:void 0,Timers:void 0,Transitions:void 0,Touches:void 0,Images:void 0}},computed:{style:function(){if(!this.size)return{};if(this.Display.inFullScreen)return{width:"100% !important",height:"100% !important"};var t=this.size,e=t.width,n=t.height;return{width:e?e+"px":"auto",height:n?n+"px":"auto"}}},watch:{options:{handler:function(){this.updateOptions()},deep:!0},transitions:function(){var t=this.config.autoplay;this.stop(!0),this.Transitions.update(this.transitions),t&&this.play()},images:function(){var t=this.config.autoplay;this.stop(!0),this.loaded=!1,this.Images.update(this.images),t&&this.play()}},created:function(){this.Display=new Mn(this),this.Timers=new Ln(this),this.Images=new Un(this),this.Touches=new Xn(this),this.Transitions=new An(this),this.updateOptions(),this.$emit("created")},mounted:function(){this.resize(),this.Images.update(this.images),this.Transitions.update(this.transitions),this.$emit("mounted")},beforeDestroy:function(){this.removeListeners(),this.Timers.clear(),this.$emit("destroyed")},methods:{updateOptions:function(){Object.assign(this.config,this.options),0===this.config.autohideTime&&(this.mouseOver=!0),this.removeListeners(),window.addEventListener("resize",this.resize,{passive:!0}),this.config.bindKeys&&window.addEventListener("keydown",this.keydown,{passive:!0}),this.$emit("options-updated")},resize:function(){var t=this;return Nn(regeneratorRuntime.mark((function e(){var n,i,r,o,s;return regeneratorRuntime.wrap((function(e){while(1)switch(e.prev=e.next){case 0:if(t.$refs.container){e.next=2;break}return e.abrupt("return");case 2:return t.Transitions.current&&t.Transitions.end(!0),t.size=void 0,e.next=6,t.$nextTick();case 6:n=E.sizeFrom(t.$refs.container),n.height||(i=t.config.aspectRatio.split(":"),r=Pn(i,2),o=r[0],s=r[1],n.height=n.width/o*s),t.size=n;case 9:case"end":return e.stop()}}),e)})))()},init:function(){this.loaded=!0,!0===this.config.autoplay&&this.play(),this.$emit("ready")},toggleMouseOver:function(t){var e=this;0!==this.config.autohideTime&&(this.Timers.clear("mouseOver"),this.mouseOver=t,this.mouseOver?this.Timers.set("mouseOver",this.config.autohideTime,(function(){e.mouseOver=!1})):(this.mouseOver=!1,this.Timers.clear("mouseOver")))},toggleFullScreen:function(){this.Display.toggleFullScreen()},play:function(){var t=this,e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:"next",n=arguments.length>1?arguments[1]:void 0;this.config.autoplay=!0,this.Transitions.current||this.Timers.set("transition",n||this.config.delay,(function(){t.show(e)})),this.$emit("play",{index:e})},stop:function(t){this.config.autoplay=!1,this.Timers.clear("transition"),this.Transitions.current&&t&&this.Transitions.end(!0),this.$emit("stop")},show:function(){var t=this,e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:"next",n=arguments.length>1?arguments[1]:void 0;if(this.loaded&&this.$refs.image)if(this.Transitions.current)this.config.allowToSkipTransition&&(this.Transitions.end(!0),this.$nextTick((function(){t.show(e,n)})));else{var i=this.Images.current,r=this.Images.getByIndex(e),o=["prev","next"].includes(e)?e:void 0;this.Transitions.run(n,i,r,o),this.$emit("show",{transition:n,from:i,to:r,direction:o})}},keydown:function(t){/ArrowLeft|Left/.test(t.key)?this.show("prev"):/ArrowRight|Right/.test(t.key)&&this.show("next")},removeListeners:function(){window.removeEventListener("resize",this.resize),window.removeEventListener("keydown",this.keydown)}}},Vn=Hn,qn=(n("1d36"),f(Vn,In,_n,!1,null,null,null)),Kn=qn.exports,Jn=function(){var t=this,e=t.$createElement,n=t._self._c||e;return t.caption?n("div",{class:t.htmlClass},[t._t("default",[t._v(" "+t._s(t.getCaptionText())+" ")],{caption:t.caption,text:t.getCaptionText()})],2):t._e()},Zn=[],Qn={props:{slider:Object},computed:{vf:function(){if(this.slider)return this.slider;if("VueFlux"===this.$parent.$options.name)return this.$parent;throw new ReferenceError("slider not referenced, check https://ragnarlotus.github.com/vue-flux-docs/ for help")},captions:function(){return this.vf&&this.vf.captions?this.vf.captions:{}},Transitions:function(){return this.vf.Transitions},Images:function(){return this.vf.Images}},methods:{getCaption:function(t){return void 0===t&&(t=this.Images.current?this.Images.current.initIndex:""),this.captions[t]||""},getCaptionText:function(t){var e=this.getCaption(t);return e.text||e||""}}},ti={name:"FluxCaption",mixins:[Qn],computed:{caption:function(){return this.vf&&this.vf.loaded?this.getCaption():""},htmlClass:function(){var t=["flux-caption"];return this.Transitions.current||t.push("visible"),t}}},ei=ti,ni=(n("87af"),f(ei,Jn,Zn,!1,null,null,null)),ii=ni.exports,ri=function(){var t=this,e=t.$createElement,n=t._self._c||e;return n("transition",{attrs:{name:"fade"}},[t.display?n("div",{staticClass:"flux-controls"},[n("flux-button",{staticClass:"prev top left",on:{click:function(e){return t.vf.show("prev")}}},[n("polyline",{attrs:{points:"64,18 22,50 64,82"}})]),t.vf.config.autoplay?t._e():n("flux-button",{staticClass:"play",on:{click:function(e){return t.vf.play("next",1)}}},[n("polygon",{attrs:{points:"32,12 82,50 32,88"}})]),t.vf.config.autoplay?n("flux-button",{staticClass:"pause",on:{click:function(e){return t.vf.stop()}}},[n("line",{attrs:{x1:"32",y1:"22",x2:"32",y2:"78"}}),n("line",{attrs:{x1:"68",y1:"22",x2:"68",y2:"78"}})]):t._e(),n("flux-button",{staticClass:"next top right",on:{click:function(e){return t.vf.show("next")}}},[n("polyline",{attrs:{points:"36,18 78,50 36,82"}})])],1):t._e()])},oi=[],si={name:"FluxControls",components:{FluxButton:d},mixins:[Qn],computed:{display:function(){return!!this.vf&&(!!this.vf.loaded&&!!this.vf.mouseOver)}}},ai=si,ci=(n("f83b"),f(ai,ri,oi,!1,null,null,null)),ui=ci.exports,li=function(){var t=this,e=t.$createElement,n=t._self._c||e;return t.display?n("div",{staticClass:"flux-index"},[n("transition",{attrs:{name:"fade"}},[t.displayButton?n("flux-button",{staticClass:"toggle bottom left",on:{click:function(e){return t.showIndex(e)}}},t._l(t.coords,(function(e,i){return n("rect",{key:i,attrs:{x:e.x,y:e.y,width:t.buttonRectSize+"px",height:t.buttonRectSize+"px"}})})),0):t._e()],1),n("nav",{class:t.listClass,on:{click:function(e){return t.hideIndex()}}},[n("ul",{ref:"index"},t._l(t.images,(function(e,i){return n("li",{key:i,class:t.thumbClass(i),on:{click:function(e){return t.showImage(i)}}},[n("flux-image",{ref:"thumbs",refInFor:!0,attrs:{image:t.images[i],size:t.thumbSize,title:t.getCaptionText(e.initIndex)}})],1)})),0)])],1):t._e()},fi=[],hi={name:"FluxIndex",components:{FluxButton:d,FluxImage:$},mixins:[Qn],props:{buttonRows:{type:Number,default:3},buttonCols:{type:Number,default:3},buttonRectSize:{type:Number,default:12},buttonPadding:{type:Number,default:6}},data:function(){return{visible:!1,rectSize:14,delay:500,coords:[]}},computed:{images:function(){return this.vf?this.Images.imgs:[]},display:function(){return this.vf&&this.vf.loaded},displayButton:function(){return this.vf.mouseOver},listClass:function(){var t="";return this.visible&&(t+="visible"),this.vf.mouseOver&&(t+=" mouse-over"),t},thumbSize:function(){var t=this.vf.size,e=t.width,n=t.height;if(e/=4.2,n/=4.2,e>160){var i=this.vf.config.aspectRatio.split(":"),r=Pn(i,2),o=r[0],s=r[1];e=160,n=e*s/o}return{width:e,height:n}}},created:function(){for(var t=(100-2*this.buttonPadding-this.rectSize*this.buttonRows)/(this.buttonRows+1),e=(100-2*this.buttonPadding-this.rectSize*this.buttonCols)/(this.buttonCols+1),n=0;n<this.buttonRows;n++)for(var i=0;i<this.buttonCols;i++)this.coords.push({x:this.buttonPadding+t+t*n+this.rectSize*n,y:this.buttonPadding+e+e*i+this.rectSize*i})},methods:{showIndex:function(){this.vf.stop(),this.visible=!0;var t=this.$refs.index;this.$nextTick((function(){t.clientHeight,t.style.marginTop=0}))},hideIndex:function(t){var e=this,n=this.$refs.index;n.clientHeight,n.style.marginTop="100%",setTimeout((function(){e.visible=!1,void 0!==t&&e.showImage(t)}),this.delay)},thumbClass:function(t){return this.Images.current&&this.Images.current.index===t?"current":""},showImage:function(t){this.visible?this.hideIndex(t):this.Images.current.index!==t&&this.vf.show(t)}}},di=hi,pi=(n("5a88"),f(di,li,fi,!1,null,null,null)),gi=pi.exports,vi=function(){var t=this,e=t.$createElement,n=t._self._c||e;return t.display?n("nav",{staticClass:"flux-pagination"},[n("ul",t._l(t.Images.imgs,(function(e,i){return n("li",{key:i},[t._t("default",[n("span",{staticClass:"pagination-item",class:t.getClass(i),attrs:{title:t.getCaptionText(e.initIndex)},on:{click:function(e){return t.show(i)}}})],{item:t.getItem(e,i)})],2)})),0)]):t._e()},mi=[],yi={name:"FluxPagination",mixins:[Qn],computed:{display:function(){return!!this.vf}},methods:{getItem:function(t,e){return{index:e,title:this.getCaptionText(t.initIndex),onClick:this.show,active:"active"===this.getClass(e)}},getClass:function(t){return void 0!==this.Transitions.current&&this.Transitions.from.index===t||this.Images.current&&void 0===this.Transitions.current&&this.Images.current.index===t?"active":""},show:function(t,e){this.vf.show(t),e&&e.preventDefault()}}},xi=yi,bi=(n("6fc2"),f(xi,vi,mi,!1,null,null,null)),wi=bi.exports,Si=function(){var t=this,e=t.$createElement,n=t._self._c||e;return n("div",{staticClass:"preloader"},[t._t("spinner",[t.displaySpinner?n("div",{staticClass:"spinner"},[n("div",{staticClass:"pct"},[t._v(" "+t._s(t.Images.progress)+"% ")]),n("div",{staticClass:"border"})]):t._e()])],2)},Ti=[],zi={name:"FluxPreloader",mixins:[Qn],props:{spinner:{type:Boolean,default:!0}},data:function(){return{transitionName:void 0,imageCss:{zIndex:13}}},computed:{displaySpinner:function(){return this.spinner&&this.vf.Images.preloading}},watch:{"vf.images":function(){var t=this.Images,e=this.Transitions;t.last&&!e.current&&(t.current=t.last)},"vf.Images.preloading":function(t){var e=this.Images;e.last&&!t&&e.current===e.last&&this.transitionStart()}},methods:{transitionStart:function(){var t=this.Images,e=this.Transitions;e.current&&e.end(!0),e.run(void 0,t.current,t.imgs[0],"next")}}},ki=zi,Ci=(n("1dec"),f(ki,Si,Ti,!1,null,null,null)),Ei=Ci.exports},fb6a:function(t,e,n){"use strict";var i=n("23e7"),r=n("861d"),o=n("e8b5"),s=n("23cb"),a=n("50c4"),c=n("fc6a"),u=n("8418"),l=n("b622"),f=n("1dde"),h=n("ae40"),d=f("slice"),p=h("slice",{ACCESSORS:!0,0:0,1:2}),g=l("species"),v=[].slice,m=Math.max;i({target:"Array",proto:!0,forced:!d||!p},{slice:function(t,e){var n,i,l,f=c(this),h=a(f.length),d=s(t,h),p=s(void 0===e?h:e,h);if(o(f)&&(n=f.constructor,"function"!=typeof n||n!==Array&&!o(n.prototype)?r(n)&&(n=n[g],null===n&&(n=void 0)):n=void 0,n===Array||void 0===n))return v.call(f,d,p);for(i=new(void 0===n?Array:n)(m(p-d,0)),l=0;d<p;d++,l++)d in f&&u(i,l,f[d]);return i.length=l,i}})},fc6a:function(t,e,n){var i=n("44ad"),r=n("1d80");t.exports=function(t){return i(r(t))}},fdbc:function(t,e){t.exports={CSSRuleList:0,CSSStyleDeclaration:0,CSSValueList:0,ClientRectList:0,DOMRectList:0,DOMStringList:0,DOMTokenList:1,DataTransferItemList:0,FileList:0,HTMLAllCollection:0,HTMLCollection:0,HTMLFormElement:0,HTMLSelectElement:0,MediaList:0,MimeTypeArray:0,NamedNodeMap:0,NodeList:1,PaintRequestList:0,Plugin:0,PluginArray:0,SVGLengthList:0,SVGNumberList:0,SVGPathSegList:0,SVGPointList:0,SVGStringList:0,SVGTransformList:0,SourceBufferList:0,StyleSheetList:0,TextTrackCueList:0,TextTrackList:0,TouchList:0}},fdbf:function(t,e,n){var i=n("4930");t.exports=i&&!Symbol.sham&&"symbol"==typeof Symbol.iterator},fea9:function(t,e,n){var i=n("da84");t.exports=i.Promise}})}));
//# sourceMappingURL=vue-flux.umd.min.js.map

/***/ }),

/***/ "./resources/js/components/global/ChatComponent.vue":
/*!**********************************************************!*\
  !*** ./resources/js/components/global/ChatComponent.vue ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _ChatComponent_vue_vue_type_template_id_299eb344___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ChatComponent.vue?vue&type=template&id=299eb344& */ "./resources/js/components/global/ChatComponent.vue?vue&type=template&id=299eb344&");
/* harmony import */ var _ChatComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ChatComponent.vue?vue&type=script&lang=js& */ "./resources/js/components/global/ChatComponent.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ChatComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _ChatComponent_vue_vue_type_template_id_299eb344___WEBPACK_IMPORTED_MODULE_0__.render,
  _ChatComponent_vue_vue_type_template_id_299eb344___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/global/ChatComponent.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/global/FooterGlobal.vue":
/*!*********************************************************!*\
  !*** ./resources/js/components/global/FooterGlobal.vue ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _FooterGlobal_vue_vue_type_template_id_44aae92f___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FooterGlobal.vue?vue&type=template&id=44aae92f& */ "./resources/js/components/global/FooterGlobal.vue?vue&type=template&id=44aae92f&");
/* harmony import */ var _FooterGlobal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./FooterGlobal.vue?vue&type=script&lang=js& */ "./resources/js/components/global/FooterGlobal.vue?vue&type=script&lang=js&");
/* harmony import */ var _FooterGlobal_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./FooterGlobal.vue?vue&type=style&index=0&lang=css& */ "./resources/js/components/global/FooterGlobal.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _FooterGlobal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _FooterGlobal_vue_vue_type_template_id_44aae92f___WEBPACK_IMPORTED_MODULE_0__.render,
  _FooterGlobal_vue_vue_type_template_id_44aae92f___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/global/FooterGlobal.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/home/Index.vue":
/*!*******************************************!*\
  !*** ./resources/js/pages/home/Index.vue ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Index_vue_vue_type_template_id_9329f6aa___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Index.vue?vue&type=template&id=9329f6aa& */ "./resources/js/pages/home/Index.vue?vue&type=template&id=9329f6aa&");
/* harmony import */ var _Index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Index.vue?vue&type=script&lang=js& */ "./resources/js/pages/home/Index.vue?vue&type=script&lang=js&");
/* harmony import */ var _Index_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Index.vue?vue&type=style&index=0&lang=css& */ "./resources/js/pages/home/Index.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Index_vue_vue_type_template_id_9329f6aa___WEBPACK_IMPORTED_MODULE_0__.render,
  _Index_vue_vue_type_template_id_9329f6aa___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/home/Index.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/pages/home/utils/Comilla.vue":
/*!***************************************************!*\
  !*** ./resources/js/pages/home/utils/Comilla.vue ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Comilla_vue_vue_type_template_id_d7f18c58___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Comilla.vue?vue&type=template&id=d7f18c58& */ "./resources/js/pages/home/utils/Comilla.vue?vue&type=template&id=d7f18c58&");
/* harmony import */ var _Comilla_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Comilla.vue?vue&type=script&lang=js& */ "./resources/js/pages/home/utils/Comilla.vue?vue&type=script&lang=js&");
/* harmony import */ var _Comilla_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Comilla.vue?vue&type=style&index=0&lang=css& */ "./resources/js/pages/home/utils/Comilla.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Comilla_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Comilla_vue_vue_type_template_id_d7f18c58___WEBPACK_IMPORTED_MODULE_0__.render,
  _Comilla_vue_vue_type_template_id_d7f18c58___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/home/utils/Comilla.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/global/ChatComponent.vue?vue&type=script&lang=js&":
/*!***********************************************************************************!*\
  !*** ./resources/js/components/global/ChatComponent.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ChatComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./ChatComponent.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/global/ChatComponent.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ChatComponent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/global/FooterGlobal.vue?vue&type=script&lang=js&":
/*!**********************************************************************************!*\
  !*** ./resources/js/components/global/FooterGlobal.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FooterGlobal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./FooterGlobal.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/global/FooterGlobal.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FooterGlobal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/home/Index.vue?vue&type=script&lang=js&":
/*!********************************************************************!*\
  !*** ./resources/js/pages/home/Index.vue?vue&type=script&lang=js& ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Index.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/home/Index.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/home/utils/Comilla.vue?vue&type=script&lang=js&":
/*!****************************************************************************!*\
  !*** ./resources/js/pages/home/utils/Comilla.vue?vue&type=script&lang=js& ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Comilla_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Comilla.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/home/utils/Comilla.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Comilla_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/global/FooterGlobal.vue?vue&type=style&index=0&lang=css&":
/*!******************************************************************************************!*\
  !*** ./resources/js/components/global/FooterGlobal.vue?vue&type=style&index=0&lang=css& ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_FooterGlobal_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./FooterGlobal.vue?vue&type=style&index=0&lang=css& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/global/FooterGlobal.vue?vue&type=style&index=0&lang=css&");


/***/ }),

/***/ "./resources/js/pages/home/Index.vue?vue&type=style&index=0&lang=css&":
/*!****************************************************************************!*\
  !*** ./resources/js/pages/home/Index.vue?vue&type=style&index=0&lang=css& ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Index.vue?vue&type=style&index=0&lang=css& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/home/Index.vue?vue&type=style&index=0&lang=css&");


/***/ }),

/***/ "./resources/js/pages/home/utils/Comilla.vue?vue&type=style&index=0&lang=css&":
/*!************************************************************************************!*\
  !*** ./resources/js/pages/home/utils/Comilla.vue?vue&type=style&index=0&lang=css& ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_9_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Comilla_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/style-loader/dist/cjs.js!../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Comilla.vue?vue&type=style&index=0&lang=css& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-9[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/home/utils/Comilla.vue?vue&type=style&index=0&lang=css&");


/***/ }),

/***/ "./resources/js/components/global/ChatComponent.vue?vue&type=template&id=299eb344&":
/*!*****************************************************************************************!*\
  !*** ./resources/js/components/global/ChatComponent.vue?vue&type=template&id=299eb344& ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ChatComponent_vue_vue_type_template_id_299eb344___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ChatComponent_vue_vue_type_template_id_299eb344___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ChatComponent_vue_vue_type_template_id_299eb344___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./ChatComponent.vue?vue&type=template&id=299eb344& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/global/ChatComponent.vue?vue&type=template&id=299eb344&");


/***/ }),

/***/ "./resources/js/components/global/FooterGlobal.vue?vue&type=template&id=44aae92f&":
/*!****************************************************************************************!*\
  !*** ./resources/js/components/global/FooterGlobal.vue?vue&type=template&id=44aae92f& ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FooterGlobal_vue_vue_type_template_id_44aae92f___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FooterGlobal_vue_vue_type_template_id_44aae92f___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FooterGlobal_vue_vue_type_template_id_44aae92f___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./FooterGlobal.vue?vue&type=template&id=44aae92f& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/global/FooterGlobal.vue?vue&type=template&id=44aae92f&");


/***/ }),

/***/ "./resources/js/pages/home/Index.vue?vue&type=template&id=9329f6aa&":
/*!**************************************************************************!*\
  !*** ./resources/js/pages/home/Index.vue?vue&type=template&id=9329f6aa& ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_template_id_9329f6aa___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_template_id_9329f6aa___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_template_id_9329f6aa___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Index.vue?vue&type=template&id=9329f6aa& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/home/Index.vue?vue&type=template&id=9329f6aa&");


/***/ }),

/***/ "./resources/js/pages/home/utils/Comilla.vue?vue&type=template&id=d7f18c58&":
/*!**********************************************************************************!*\
  !*** ./resources/js/pages/home/utils/Comilla.vue?vue&type=template&id=d7f18c58& ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Comilla_vue_vue_type_template_id_d7f18c58___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Comilla_vue_vue_type_template_id_d7f18c58___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Comilla_vue_vue_type_template_id_d7f18c58___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Comilla.vue?vue&type=template&id=d7f18c58& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/home/utils/Comilla.vue?vue&type=template&id=d7f18c58&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/global/ChatComponent.vue?vue&type=template&id=299eb344&":
/*!********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/global/ChatComponent.vue?vue&type=template&id=299eb344& ***!
  \********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "v-btn",
        {
          attrs: {
            link: "",
            href: _vm.wame,
            target: "_blank",
            fab: "",
            dark: "",
            large: "",
            color: "primary",
            fixed: "",
            right: "",
            bottom: "",
          },
        },
        [
          _c("v-icon", { attrs: { large: "", dark: "" } }, [
            _vm._v("mdi-whatsapp "),
          ]),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/global/FooterGlobal.vue?vue&type=template&id=44aae92f&":
/*!*******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/global/FooterGlobal.vue?vue&type=template&id=44aae92f& ***!
  \*******************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "v-row",
        { staticClass: "pa-0 ma-0 content-wrap-2 mx-auto footer-container" },
        [
          _c(
            "v-col",
            { staticClass: "col-12 pa-0 ma-0 rotate-180 container-bandwith" },
            [_c("v-img", { attrs: { src: "/app/bandwith.png " } })],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "v-row",
        { staticClass: "primary pa-0 ma-0 content-wrap-2 mx-auto" },
        [
          _c(
            "v-col",
            {
              staticClass:
                "col-12 col-md-6 d-flex flex-wrap justify-center align-center",
            },
            [
              _c(
                "div",
                { staticClass: "footer-logo" },
                [
                  _c("v-img", {
                    staticClass: "footer-logo",
                    attrs: { src: "/app/white_logo.png", contain: "" },
                  }),
                ],
                1
              ),
              _vm._v(" "),
              _c("span", { staticClass: "white--text as-footer_text px-4" }, [
                _vm._v(
                  "\n                Copyright ©" +
                    _vm._s(_vm.yearActual) +
                    " by A&S Consulting Group.\n            "
                ),
              ]),
            ]
          ),
          _vm._v(" "),
          _c(
            "v-col",
            { staticClass: "col-12 col-md-6 text-center text-md-left " },
            [
              _c("v-col", [
                _c(
                  "span",
                  {
                    staticClass:
                      "white--text d-block d-md-inline-flex align-center justify-center",
                  },
                  [
                    _c(
                      "v-btn",
                      {
                        staticClass: "white--text",
                        attrs: {
                          fab: "",
                          text: "",
                          small: "",
                          link: "",
                          href: _vm.phone_send,
                        },
                      },
                      [
                        _c("v-icon", { attrs: { color: "white" } }, [
                          _vm._v("mdi-phone-message"),
                        ]),
                      ],
                      1
                    ),
                    _vm._v(
                      "\n                    " +
                        _vm._s(_vm.phone_contact) +
                        "\n                "
                    ),
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "span",
                  {
                    staticClass:
                      "white--text d-block d-md-inline-flex align-center justify-center",
                  },
                  [
                    _c(
                      "v-btn",
                      {
                        staticClass: "white--text",
                        attrs: { fab: "", text: "", small: "", link: "" },
                        on: {
                          click: function ($event) {
                            $event.preventDefault()
                            return _vm.openEmail()
                          },
                        },
                      },
                      [
                        _c("v-icon", { attrs: { color: "white" } }, [
                          _vm._v("mdi-email-open"),
                        ]),
                      ],
                      1
                    ),
                    _vm._v(
                      "\n                    " +
                        _vm._s(_vm.email) +
                        "\n                "
                    ),
                  ],
                  1
                ),
              ]),
              _vm._v(" "),
              _c("v-col", [
                _c(
                  "span",
                  {
                    staticClass:
                      "white--text d-block d-md-inline-flex align-center justify-center",
                  },
                  [
                    _c(
                      "v-btn",
                      {
                        staticClass: "white--text",
                        attrs: {
                          fab: "",
                          text: "",
                          small: "",
                          href: _vm.wame,
                          target: "_blank",
                        },
                      },
                      [
                        _c("v-icon", { attrs: { color: "white" } }, [
                          _vm._v("mdi-whatsapp"),
                        ]),
                      ],
                      1
                    ),
                    _vm._v(
                      "\n                    " +
                        _vm._s(_vm.phone_contact) +
                        "\n                "
                    ),
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "span",
                  {
                    staticClass:
                      "white--text d-block d-md-inline-flex align-center justify-center",
                  },
                  [
                    _c(
                      "v-btn",
                      {
                        staticClass: "white--text",
                        attrs: { fab: "", text: "", small: "", link: "" },
                        on: {
                          click: function ($event) {
                            $event.preventDefault()
                            return _vm.goToLocation()
                          },
                        },
                      },
                      [
                        _c("v-icon", { attrs: { color: "white" } }, [
                          _vm._v("mdi-map-marker"),
                        ]),
                      ],
                      1
                    ),
                    _vm._v(
                      "\n                    " +
                        _vm._s(_vm.address) +
                        "\n                "
                    ),
                  ],
                  1
                ),
              ]),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/home/Index.vue?vue&type=template&id=9329f6aa&":
/*!*****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/home/Index.vue?vue&type=template&id=9329f6aa& ***!
  \*****************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {},
    [
      _c(
        "v-container",
        { staticClass: "fixed-top pa-0", attrs: { fluid: "" } },
        [
          _c(
            "v-row",
            { staticClass: "pa-0 ma-0" },
            [
              _c(
                "v-col",
                { staticClass: "col-12 pa-0 ma-0" },
                [
                  _c("div", { staticClass: "flux-overlap" }),
                  _vm._v(" "),
                  _c("vue-flux", {
                    ref: "slider",
                    staticClass: "flux-container",
                    attrs: {
                      options: _vm.vfOptions,
                      images: _vm.vfImages,
                      transitions: _vm.vfTransitions,
                      captions: _vm.vfCaptions,
                    },
                    scopedSlots: _vm._u([
                      {
                        key: "caption",
                        fn: function () {
                          return [
                            _c("flux-caption", {
                              scopedSlots: _vm._u([
                                {
                                  key: "default",
                                  fn: function (captionProps) {
                                    return [
                                      _c(
                                        "div",
                                        { staticClass: "flux-content" },
                                        [
                                          captionProps.text.image != null
                                            ? _c("v-img", {
                                                staticClass:
                                                  "mx-auto image-as pa-0 my-0",
                                                attrs: {
                                                  src: captionProps.text.image,
                                                },
                                              })
                                            : _vm._e(),
                                          _vm._v(" "),
                                          captionProps.text.title != null
                                            ? _c(
                                                "div",
                                                { staticClass: "pa-0 ma-0" },
                                                [
                                                  _c(
                                                    "div",
                                                    {
                                                      staticClass:
                                                        "content-desc-title mx-auto",
                                                    },
                                                    _vm._l(
                                                      captionProps.text.title,
                                                      function (element, i) {
                                                        return _c(
                                                          "span",
                                                          { key: i },
                                                          [
                                                            element.type ==
                                                            "normal"
                                                              ? _c(
                                                                  "p",
                                                                  {
                                                                    staticClass:
                                                                      "as-text_large ma-0",
                                                                  },
                                                                  [
                                                                    _c("span", [
                                                                      _vm._v(
                                                                        _vm._s(
                                                                          element.text
                                                                        )
                                                                      ),
                                                                    ]),
                                                                  ]
                                                                )
                                                              : _c(
                                                                  "strong",
                                                                  {
                                                                    staticClass:
                                                                      "as-text_underline font-weight-bold",
                                                                  },
                                                                  [
                                                                    _vm._v(
                                                                      _vm._s(
                                                                        element.text
                                                                      )
                                                                    ),
                                                                  ]
                                                                ),
                                                          ]
                                                        )
                                                      }
                                                    ),
                                                    0
                                                  ),
                                                ]
                                              )
                                            : _vm._e(),
                                          _vm._v(" "),
                                          captionProps.text.subtitle_image !=
                                          null
                                            ? _c(
                                                "p",
                                                { staticClass: "pa-0 ma-0" },
                                                [
                                                  _c(
                                                    "span",
                                                    {
                                                      staticClass:
                                                        "as-title_large",
                                                    },
                                                    [
                                                      _vm._v(
                                                        "\n                                        " +
                                                          _vm._s(
                                                            captionProps.text
                                                              .subtitle_image
                                                          ) +
                                                          "\n                                    "
                                                      ),
                                                    ]
                                                  ),
                                                ]
                                              )
                                            : _vm._e(),
                                          _vm._v(" "),
                                          captionProps.text.subtitle != null
                                            ? _c(
                                                "div",
                                                {
                                                  staticClass: "pa-0 ma-0 my-5",
                                                },
                                                [
                                                  _c(
                                                    "div",
                                                    {
                                                      staticClass:
                                                        "content-desc-subtitle mx-auto",
                                                    },
                                                    _vm._l(
                                                      captionProps.text
                                                        .subtitle,
                                                      function (element, i) {
                                                        return _c(
                                                          "span",
                                                          { key: i },
                                                          [
                                                            element.type ==
                                                            "normal"
                                                              ? _c(
                                                                  "span",
                                                                  {
                                                                    staticClass:
                                                                      "as-text_normal",
                                                                  },
                                                                  [
                                                                    _vm._v(
                                                                      _vm._s(
                                                                        element.text
                                                                      )
                                                                    ),
                                                                  ]
                                                                )
                                                              : element.type ==
                                                                "strong"
                                                              ? _c(
                                                                  "strong",
                                                                  {
                                                                    staticClass:
                                                                      "as-text_normal",
                                                                  },
                                                                  [
                                                                    _vm._v(
                                                                      _vm._s(
                                                                        element.text
                                                                      )
                                                                    ),
                                                                  ]
                                                                )
                                                              : _c(
                                                                  "p",
                                                                  {
                                                                    staticClass:
                                                                      "as-text_normal ma-0",
                                                                  },
                                                                  [
                                                                    _c("span", [
                                                                      _vm._v(
                                                                        _vm._s(
                                                                          element.text
                                                                        )
                                                                      ),
                                                                    ]),
                                                                  ]
                                                                ),
                                                          ]
                                                        )
                                                      }
                                                    ),
                                                    0
                                                  ),
                                                ]
                                              )
                                            : _vm._e(),
                                          _vm._v(" "),
                                          captionProps.text.actions != null
                                            ? _c("div", [
                                                _c(
                                                  "div",
                                                  {
                                                    staticClass:
                                                      "content-desc-title mx-auto d-flex justify-space-between my-6",
                                                  },
                                                  _vm._l(
                                                    captionProps.text.actions,
                                                    function (action, i) {
                                                      return _c(
                                                        "span",
                                                        {
                                                          key: i,
                                                          staticClass:
                                                            "mx-auto",
                                                        },
                                                        [
                                                          _c("v-hover", {
                                                            scopedSlots: _vm._u(
                                                              [
                                                                {
                                                                  key: "default",
                                                                  fn: function (
                                                                    ref
                                                                  ) {
                                                                    var hover =
                                                                      ref.hover
                                                                    return [
                                                                      _c(
                                                                        "v-btn",
                                                                        {
                                                                          staticClass:
                                                                            "white--text font-weight-bold btn-actions",
                                                                          class:
                                                                            {
                                                                              "primary--text white":
                                                                                hover,
                                                                            },
                                                                          attrs:
                                                                            {
                                                                              outlined:
                                                                                "",
                                                                              color:
                                                                                "white",
                                                                              rounded:
                                                                                "",
                                                                            },
                                                                          on: {
                                                                            click:
                                                                              function (
                                                                                $event
                                                                              ) {
                                                                                return _vm.OnClickActions()
                                                                              },
                                                                          },
                                                                        },
                                                                        [
                                                                          _vm._v(
                                                                            _vm._s(
                                                                              action.title
                                                                            )
                                                                          ),
                                                                        ]
                                                                      ),
                                                                    ]
                                                                  },
                                                                },
                                                              ],
                                                              null,
                                                              true
                                                            ),
                                                          }),
                                                        ],
                                                        1
                                                      )
                                                    }
                                                  ),
                                                  0
                                                ),
                                              ])
                                            : _vm._e(),
                                        ],
                                        1
                                      ),
                                      _vm._v(" "),
                                      _c(
                                        "div",
                                        { staticClass: "mt-12" },
                                        [
                                          _c(
                                            "v-btn",
                                            {
                                              attrs: {
                                                fab: "",
                                                outlined: "",
                                                color: "white",
                                                href: "#ayudanos",
                                              },
                                            },
                                            [
                                              _c(
                                                "v-icon",
                                                {
                                                  staticClass: "white--text",
                                                  attrs: { large: "" },
                                                },
                                                [_vm._v("mdi-chevron-down")]
                                              ),
                                            ],
                                            1
                                          ),
                                        ],
                                        1
                                      ),
                                    ]
                                  },
                                },
                              ]),
                            }),
                          ]
                        },
                        proxy: true,
                      },
                      {
                        key: "pagination",
                        fn: function () {
                          return [_c("flux-pagination")]
                        },
                        proxy: true,
                      },
                    ]),
                  }),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "v-container",
        { staticClass: "pa-0 ma-0 main-content", attrs: { fluid: "" } },
        [
          _c(
            "v-row",
            {
              staticClass:
                "pa-0 ma-0 content-wrap-2 mx-auto container-bandwith",
              attrs: { id: "ayudanos" },
            },
            [
              _c(
                "v-col",
                { staticClass: "col-12 pa-0 ma-0" },
                [_c("v-img", { attrs: { src: "/app/bandwith.png" } })],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "v-row",
            {
              staticClass:
                "ma-0 pa-0 my-5 d-flex justify-center content-wrap-2 mx-auto container-different",
            },
            [
              _c(
                "v-col",
                { staticClass: "col-10 col-xs-6 col-md-5 pa-5" },
                [
                  _c("comilla"),
                  _vm._v(" "),
                  _c(
                    "v-card",
                    {
                      staticClass:
                        "rounded-0 elevation-2 container-card mx-auto",
                    },
                    [
                      _c(
                        "v-card-text",
                        { staticClass: "pa-6 text-line-card text-center" },
                        [
                          _c(
                            "span",
                            { staticClass: "as-title_large alternative--text" },
                            [
                              _vm._v(
                                "\n                            Ayudamos a\n                            "
                              ),
                              _c("strong", [_vm._v("cumplir los objetivos")]),
                              _vm._v(
                                " de nuestros\n                            clientes,\n                            "
                              ),
                              _c("strong", [
                                _vm._v("promoviendo su crecimiento"),
                              ]),
                              _vm._v(
                                ",\n                            rentabilidad y la gestión de sus riesgos.\n                        "
                              ),
                            ]
                          ),
                        ]
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "v-row",
            {
              staticClass:
                "ma-0 my-5 pa-0 d-flex justify-center content-wrap-2 mx-auto",
            },
            [
              _c(
                "v-col",
                {
                  staticClass:
                    "col-12 col-md-6 pa-5 d-flex align-center justify-md-end justify-center",
                },
                [
                  _c(
                    "v-card",
                    {
                      staticClass: "rounded-circle d-flex align-center",
                      attrs: { color: "primary", height: "102", width: "102" },
                    },
                    [
                      _c(
                        "v-card-text",
                        { staticClass: "pa-0" },
                        [
                          _c("v-img", {
                            staticClass: "mx-auto",
                            attrs: {
                              src: "/app/focus_light.png",
                              height: "86",
                              width: "103",
                            },
                          }),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "v-card",
                    { staticClass: "elevation-0 d-flex align-center px-4" },
                    [
                      _c("div", { staticClass: "d-block" }, [
                        _c(
                          "span",
                          { staticClass: "as-text_extraLarge primary--text" },
                          [_vm._v("¿Qué nos")]
                        ),
                        _vm._v(" "),
                        _c("br"),
                        _vm._v(" "),
                        _c(
                          "span",
                          {
                            staticClass:
                              "as-text_extraLarge pl-7 font-weight-bold text-uppercase primary--text",
                          },
                          [_vm._v("diferencia?")]
                        ),
                      ]),
                    ]
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("v-col", { staticClass: "col-12 col-md-6 pa-5" }, [
                _c("ul", [
                  _c("li", { staticClass: "as-li_normal primary--text" }, [
                    _vm._v(
                      "\n                        Asesores con más de\n                        "
                    ),
                    _c("strong", [_vm._v("20 años de experiencia.")]),
                  ]),
                  _vm._v(" "),
                  _c("li", { staticClass: "as-li_normal primary--text" }, [
                    _vm._v("Visión estratégica."),
                  ]),
                  _vm._v(" "),
                  _c("li", { staticClass: "as-li_normal primary--text" }, [
                    _vm._v("Metodología ágil y colaborativa."),
                  ]),
                  _vm._v(" "),
                  _c("li", { staticClass: "as-li_normal primary--text" }, [
                    _vm._v("Conocimiento del mercado."),
                  ]),
                  _vm._v(" "),
                  _c("li", { staticClass: "as-li_normal primary--text" }, [
                    _vm._v("Enfoque digital y de experiencia al usuario (UX)."),
                  ]),
                ]),
              ]),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "v-row",
            { staticClass: "pa-0 ma-0 content-wrap-2 mx-auto" },
            [
              _c(
                "v-col",
                {
                  staticClass: "col-12 pa-0 ma-0 rotate-180 container-bandwith",
                },
                [_c("v-img", { attrs: { src: "/app/bandwith.png " } })],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "v-row",
            { staticClass: "pa-0 ma-0 primary content-wrap-2 mx-auto" },
            [
              _c(
                "v-col",
                { staticClass: "col-12 pa-0" },
                [
                  _c(
                    "v-card-text",
                    { staticClass: "text-uppercase white--text text-center" },
                    [
                      _c("span", { staticClass: "as-text_extraLarge" }, [
                        _vm._v("Nuestros"),
                      ]),
                      _vm._v(" "),
                      _c("br"),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          staticClass:
                            "as-text_extraLarge pl-16 font-weight-bold",
                        },
                        [_vm._v("Servicios")]
                      ),
                    ]
                  ),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "v-row",
            { staticClass: "pa-0 ma-0 content-wrap-2 mx-auto" },
            [
              _c(
                "v-col",
                { staticClass: "col-12 pa-0 ma-0" },
                [
                  _c("div", { staticClass: "flux-overlap-servicios" }),
                  _vm._v(" "),
                  _c("vue-flux", {
                    ref: "slider_services",
                    staticClass: "flux-servicios",
                    attrs: {
                      options: _vm.vfOptions_services,
                      images: _vm.vfImages_services,
                      transitions: _vm.vfTransitions_services,
                      captions: _vm.vfCaptions_services,
                    },
                    scopedSlots: _vm._u([
                      {
                        key: "controls",
                        fn: function () {
                          return [_c("flux-controls")]
                        },
                        proxy: true,
                      },
                      {
                        key: "caption",
                        fn: function () {
                          return [
                            _c("flux-caption", {
                              staticStyle: { position: "absolute", top: "10%" },
                              scopedSlots: _vm._u([
                                {
                                  key: "default",
                                  fn: function (captionProps) {
                                    return [
                                      _c(
                                        "p",
                                        {
                                          staticClass:
                                            "white--text as-text_extraLarge mb-0 font-weight-bold mx-auto",
                                          staticStyle: {
                                            width: "350px",
                                            "line-height": "1",
                                          },
                                        },
                                        [
                                          _vm._v(
                                            _vm._s(captionProps.text.title)
                                          ),
                                        ]
                                      ),
                                      _vm._v(" "),
                                      _c(
                                        "p",
                                        {
                                          staticClass:
                                            "white--text as-text_normal my-4",
                                        },
                                        [
                                          _vm._v(
                                            _vm._s(captionProps.text.subtitle)
                                          ),
                                        ]
                                      ),
                                      _vm._v(" "),
                                      _c(
                                        "ul",
                                        {
                                          staticClass:
                                            "white--text text-start mx-auto",
                                          staticStyle: { "max-width": "350px" },
                                        },
                                        _vm._l(
                                          captionProps.text.detalles,
                                          function (element, i) {
                                            return _c(
                                              "li",
                                              {
                                                key: "data" + i,
                                                staticClass:
                                                  "white--text text-subtitle-1",
                                              },
                                              [_vm._v(_vm._s(element))]
                                            )
                                          }
                                        ),
                                        0
                                      ),
                                      _vm._v(" "),
                                      _c("v-hover", {
                                        scopedSlots: _vm._u(
                                          [
                                            {
                                              key: "default",
                                              fn: function (ref) {
                                                var hover = ref.hover
                                                return [
                                                  _c(
                                                    "v-btn",
                                                    {
                                                      staticClass:
                                                        "white--text font-weight-bold text-normal my-10 px-10",
                                                      class: {
                                                        "primary--text white":
                                                          hover,
                                                      },
                                                      attrs: {
                                                        to: captionProps.text
                                                          .link,
                                                        outlined: "",
                                                        rounded: "",
                                                        color: "white",
                                                      },
                                                    },
                                                    [_vm._v("Ver más")]
                                                  ),
                                                ]
                                              },
                                            },
                                          ],
                                          null,
                                          true
                                        ),
                                      }),
                                    ]
                                  },
                                },
                              ]),
                            }),
                          ]
                        },
                        proxy: true,
                      },
                      {
                        key: "pagination",
                        fn: function () {
                          return [_c("flux-pagination")]
                        },
                        proxy: true,
                      },
                    ]),
                  }),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "v-row",
            {
              staticClass:
                "pa-0 ma-0 content-wrap-2 mx-auto container-bandwith",
            },
            [
              _c(
                "v-col",
                { staticClass: "col-12 pa-0 ma-0" },
                [_c("v-img", { attrs: { src: "/app/bandwith.png" } })],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "v-row",
            { staticClass: "pa-0 ma-0 content-wrap-2 mx-auto" },
            [
              _c(
                "v-col",
                {
                  staticClass:
                    "col-12 col-md-5 d-flex align-center justify-md-end justify-center",
                },
                [
                  _c("div", { staticClass: "d-block" }, [
                    _c(
                      "span",
                      { staticClass: "as-text_extraLarge primary--text" },
                      [_vm._v("Solicita tu")]
                    ),
                    _vm._v(" "),
                    _c("br"),
                    _vm._v(" "),
                    _c(
                      "span",
                      {
                        staticClass:
                          "as-text_extraLarge pl-7 font-weight-bold text-uppercase primary--text",
                      },
                      [_vm._v("asesoría")]
                    ),
                  ]),
                ]
              ),
              _vm._v(" "),
              _c(
                "v-col",
                { staticClass: "col-12 col-md-6" },
                [
                  _c(
                    "v-container",
                    { staticClass: "pa-0 ma-0" },
                    [
                      _c(
                        "v-row",
                        { staticClass: "pa-0 ma-0" },
                        [
                          _c(
                            "v-col",
                            { staticClass: "col-12 col-md-6" },
                            [
                              _c("v-text-field", {
                                staticClass: "rounded-0",
                                attrs: {
                                  color: "primary",
                                  label: "Nombres y apellidos",
                                  outlined: "",
                                  "hide-details": "auto",
                                },
                                model: {
                                  value: _vm.form.nombres,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.form, "nombres", $$v)
                                  },
                                  expression: "form.nombres",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-col",
                            { staticClass: "col-12 col-md-6" },
                            [
                              _c("v-text-field", {
                                staticClass: "rounded-0",
                                attrs: {
                                  color: "primary",
                                  label: "Email",
                                  outlined: "",
                                  "hide-details": "auto",
                                },
                                model: {
                                  value: _vm.form.email,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.form, "email", $$v)
                                  },
                                  expression: "form.email",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-col",
                            { staticClass: "col-12 col-md-6" },
                            [
                              _c("v-text-field", {
                                staticClass: "rounded-0",
                                attrs: {
                                  color: "primary",
                                  label: "Teléfono",
                                  outlined: "",
                                  "hide-details": "auto",
                                },
                                model: {
                                  value: _vm.form.telefono,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.form, "telefono", $$v)
                                  },
                                  expression: "form.telefono",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-col",
                            { staticClass: "col-12 col-md-6" },
                            [
                              _c("v-select", {
                                staticClass: "rounded-0",
                                attrs: {
                                  items: _vm.servicios,
                                  label: "Selecciona un servicio",
                                  "item-text": "nombre",
                                  outlined: "",
                                  "return-object": "",
                                  "hide-details": "auto",
                                },
                                model: {
                                  value: _vm.servicio,
                                  callback: function ($$v) {
                                    _vm.servicio = $$v
                                  },
                                  expression: "servicio",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-col",
                            { staticClass: "col-12" },
                            [
                              _c("v-textarea", {
                                staticClass: "rounded-0",
                                attrs: {
                                  outlined: "",
                                  height: "100",
                                  label: "Comentarios",
                                  "hide-details": "auto",
                                },
                                model: {
                                  value: _vm.form.comentario,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.form, "comentario", $$v)
                                  },
                                  expression: "form.comentario",
                                },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "v-row",
            { staticClass: "content-wrap-2 mx-auto ma-0 mb-4" },
            [
              _c(
                "v-col",
                { staticClass: "pa-0 pb-4 col-12 offset-md-5 col-md-6" },
                [
                  _c(
                    "v-container",
                    { staticClass: "pa-0" },
                    [
                      _c(
                        "v-row",
                        { staticClass: "pa-0 ma-0" },
                        [
                          _c(
                            "v-col",
                            { staticClass: "pa-0 col-12 text-center" },
                            [
                              _c(
                                "v-btn",
                                {
                                  staticClass: "text-normal px-10 rounded-0",
                                  attrs: {
                                    loading: _vm.loadAsesoria,
                                    color: "primary",
                                    "x-large": "",
                                  },
                                  on: {
                                    click: function ($event) {
                                      $event.preventDefault()
                                      return _vm.sendRequest()
                                    },
                                  },
                                },
                                [_c("h4", [_vm._v("Enviar solicitud")])]
                              ),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c("FooterGlobal"),
        ],
        1
      ),
      _vm._v(" "),
      _c("ChatComponent"),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/home/utils/Comilla.vue?vue&type=template&id=d7f18c58&":
/*!*************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/pages/home/utils/Comilla.vue?vue&type=template&id=d7f18c58& ***!
  \*************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "container-comillas" }, [
    _c(
      "div",
      {
        staticClass: "content-comillas",
        attrs: { "data-testid": "svgRoot-comp-kc6e3mfw" },
      },
      [
        _c(
          "svg",
          {
            staticClass: "align-comillas",
            attrs: {
              "data-bbox": "0 19.7 200 161.209",
              xmlns: "http://www.w3.org/2000/svg",
              viewBox: "0 19.7 200 161.209",
              role: "presentation",
              "aria-hidden": "true",
            },
          },
          [
            _c("g", [
              _c("path", {
                attrs: {
                  fill: "#000068",
                  d: "M78.2 19.8L85.7 33c.8 1.4 1.7 2.9 2.7 4.5-3.9 2.3-7.7 4.7-11.5 6.9-12.7 7.3-24.2 16.2-33.4 27.8-8.9 11.2-13 24.1-14.3 38.5 4.4 0 8.6-.4 12.8.1 6.8.7 13.9 1.1 20.3 3.3 13.1 4.4 19.5 14.3 20.7 27.9.6 7.4-.5 14.4-4.2 20.9-7.8 13.6-20.5 19.7-37.3 17.5-21.8-2.6-33.5-13.5-38.7-36.3-1.2-5.3-1.9-10.7-2.8-16v-15.4c.2-.6.5-1.2.6-1.9 1-10 4-19.3 8.8-28.1 11.1-20.4 27-36.3 46.3-48.9 7.2-4.7 14.5-9.4 21.8-14.1.2.1.4.1.7.1z",
                },
              }),
              _vm._v(" "),
              _c("path", {
                attrs: {
                  fill: "#000068",
                  d: "M189.4 19.8c3.5 5.8 6.9 11.6 10.6 17.8-1.7 1-3.4 2.1-5.1 3-13.4 7.8-26.3 16.1-36.8 27.9-10.7 12-15.9 26-17.4 42.3 1.4 0 2.8-.1 4.2 0 8.3.6 16.8.2 24.8 2.1 18.9 4.4 26.1 18.9 24.8 36.6-1.3 16.9-15.3 30.5-31.9 31.3-12.2.6-23.9-1.1-33.5-9.5-8.7-7.6-12.6-17.9-15.1-28.8-7.2-32.2 2.1-59.7 23.9-83.6 11-12 23.8-21.8 37.6-30.3 4.5-2.8 8.8-5.8 13.3-8.8h.6z",
                },
              }),
            ]),
          ]
        ),
      ]
    ),
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);