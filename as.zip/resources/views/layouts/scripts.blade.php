<script src="{{ asset('js/app.js') }}" type="text/javascript"></script>
</body>

</html>