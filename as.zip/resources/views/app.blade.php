@extends('layouts.app')

@section('content')
<div id="app" v-cloak>
    <v-app app>
        <App></App>
    </v-app>
</div>
@endsection