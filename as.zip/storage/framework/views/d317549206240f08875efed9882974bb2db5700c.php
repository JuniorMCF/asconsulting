<?php $__env->startSection('content'); ?>
<div id="app" v-cloak>
    <v-app app>
        <App></App>
    </v-app>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROYECTOS_DESARROLLO\ASCONSULTING_WEB\as\resources\views/app.blade.php ENDPATH**/ ?>