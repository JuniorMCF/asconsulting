<script src="<?php echo e(asset('js/app.js')); ?>" type="text/javascript"></script>
</body>

</html><?php /**PATH D:\PROYECTOS_DESARROLLO\ASCONSULTING_WEB\as\resources\views/layouts/scripts.blade.php ENDPATH**/ ?>