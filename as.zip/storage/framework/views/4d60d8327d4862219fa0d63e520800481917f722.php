<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <link rel="icon" sizes="192x192" href="<?php echo e(asset('app/logo.ico')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('app/logo_facebook.png')); ?>" type="image/png">
    <link rel="apple-touch-icon" href="<?php echo e(asset('app/logo_facebook.png')); ?>" type="image/png">
    <title></title>
    <link href="<?php echo e(asset('css/app.css')); ?>" type="text/css" rel="stylesheet" />

</head>


<body>
<?php /**PATH D:\PROYECTOS_DESARROLLO\ASCONSULTING_WEB\as\resources\views/layouts/styles.blade.php ENDPATH**/ ?>