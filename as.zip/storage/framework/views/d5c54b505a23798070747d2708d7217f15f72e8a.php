<script src="<?php echo e(asset('js/app.js')); ?>" type="text/javascript"></script>
</body>

</html><?php /**PATH D:\PROYECTOS_DESARROLLO\SPAs\edutilocos\resources\views/layouts/scripts.blade.php ENDPATH**/ ?>