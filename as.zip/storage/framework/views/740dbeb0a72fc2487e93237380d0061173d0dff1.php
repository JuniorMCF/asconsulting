
<style>
    [v-cloak] {
        display: block;
        padding: 50px 0;
    }

    [v-cloak]>* {
        display: none;
    }
</style>


<?php echo $__env->yieldContent('content'); ?>




<?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROYECTOS_DESARROLLO\ASCONSULTING_WEB\as\resources\views/layouts/app.blade.php ENDPATH**/ ?>